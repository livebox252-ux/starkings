import express from "express";
import path from "path";
import dotenv from "dotenv";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { playlists } from "./src/config/playlists.js";

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

// Enable JSON middleware
app.use(express.json());

function getDynamicTmdbKey(req?: express.Request): string | undefined {
  if (req) {
    const headerKey = req.headers["x-tmdb-api-key"];
    if (headerKey && typeof headerKey === "string" && headerKey.trim()) {
      return headerKey.trim();
    }
  }
  return (
    process.env.VITE_TMDB_API_KEY || 
    process.env.TMDB_API_KEY || 
    process.env.tmdb_api_key || 
    process.env.Vite_Tmdb_Api_Key || 
    process.env.VITE_TMDB_KEY || 
    process.env.TMDB_KEY
  )?.trim();
}

// IPTV Channel Types
interface Channel {
  id: string;
  name: string;
  logo: string;
  group: string;
  url: string;
  playlistId: string;
  country: string;
  language: string;
  category: string;
  tvgId?: string;
  tvgName?: string;
}

let cachedChannels: Channel[] = [];
let cachedGroups: string[] = [];
let cachedCategories: string[] = [];
let cachedCountries: string[] = [];
let cachedLanguages: string[] = [];
let isTvLoading = false;
let tvLoadError: string | null = null;
let failedPlaylistIds: string[] = [];

// Pre-compiled regexes for high-performance M3U attribute parsing
const TVG_ID_REGEX = /tvg-id="([^"]*)"/i;
const TVG_NAME_REGEX = /tvg-name="([^"]*)"/i;
const TVG_LOGO_REGEX = /tvg-logo="([^"]*)"/i;
const LOGO_REGEX = /logo="([^"]*)"/i;
const GROUP_TITLE_REGEX = /group-title="([^"]*)"/i;
const TVG_COUNTRY_REGEX = /tvg-country="([^"]*)"/i;
const COUNTRY_REGEX = /country="([^"]*)"/i;
const TVG_LANGUAGE_REGEX = /tvg-language="([^"]*)"/i;
const LANGUAGE_REGEX = /language="([^"]*)"/i;
const CATEGORY_REGEX = /category="([^"]*)"/i;

// Helper to pre-calculate unique groups, categories, countries, and languages once on data load
function rebuildCachedFilters() {
  cachedGroups = Array.from(new Set(cachedChannels.map(c => c.group))).filter(Boolean).sort();
  cachedCategories = Array.from(new Set(cachedChannels.map(c => c.category))).filter(Boolean).sort();
  cachedCountries = Array.from(new Set(cachedChannels.map(c => c.country))).filter(Boolean).sort();
  cachedLanguages = Array.from(new Set(cachedChannels.map(c => c.language))).filter(Boolean).sort();
  console.log(`[Cache] Filter caches updated. Groups: ${cachedGroups.length}, Categories: ${cachedCategories.length}, Countries: ${cachedCountries.length}, Languages: ${cachedLanguages.length}`);
}

// Parse M3U playlist file content with full, robust metadata extraction
function parseM3u(content: string, playlist: any): Channel[] {
  const channels: Channel[] = [];
  const lines = content.split("\n");
  
  let currentInfo: { 
    name: string; 
    tvgId: string;
    tvgName: string;
    logo: string; 
    group: string; 
    country: string; 
    language: string; 
    category: string; 
  } | null = null;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (line.startsWith("#EXTINF:")) {
      // Extract channel name (usually after last comma)
      const commaIndex = line.lastIndexOf(",");
      let name = commaIndex !== -1 ? line.substring(commaIndex + 1).trim() : "";
      
      // Fast helper to extract attributes using pre-compiled regexes
      const getAttr = (regex: RegExp): string => {
        const match = line.match(regex);
        return match ? match[1].trim() : "";
      };

      const tvgId = getAttr(TVG_ID_REGEX);
      const tvgName = getAttr(TVG_NAME_REGEX);
      const tvgLogo = getAttr(TVG_LOGO_REGEX) || getAttr(LOGO_REGEX);
      const groupTitle = getAttr(GROUP_TITLE_REGEX);
      const country = getAttr(TVG_COUNTRY_REGEX) || getAttr(COUNTRY_REGEX);
      const language = getAttr(TVG_LANGUAGE_REGEX) || getAttr(LANGUAGE_REGEX);
      const category = getAttr(CATEGORY_REGEX);

      if (!name && tvgName) {
        name = tvgName;
      }
      if (!name && tvgId) {
        name = tvgId;
      }
      if (!name) {
        name = "Unknown Channel";
      }

      // Skip entries with dummy, empty, or placeholder names
      const nameLower = name.toLowerCase();
      if (
        !name ||
        nameLower.includes("local stream") || 
        nameLower.includes("undefined") || 
        nameLower.includes("placeholder") ||
        name === "Unknown Channel"
      ) {
        currentInfo = null;
        continue;
      }

      // Default language based on playlist id if not found
      let defaultLang = "English";
      if (playlist.id === "de") defaultLang = "German";
      else if (playlist.id === "fr") defaultLang = "French";
      else if (playlist.id === "br") defaultLang = "Portuguese";
      else if (playlist.id === "es") defaultLang = "Spanish";

      // Strict Categorization mapping
      // Use the playlist's defined category for absolute non-mixed categorization.
      const assignedCategory = playlist.category;
      const assignedGroup = groupTitle || playlist.name;

      currentInfo = { 
        name, 
        tvgId,
        tvgName,
        logo: tvgLogo, 
        group: assignedGroup || assignedCategory, 
        country: country || playlist.region || "Global", 
        language: language || defaultLang, 
        category: assignedCategory 
      };
    } else if (line.startsWith("http") && currentInfo) {
      const url = line;
      
      // Validate stream URL
      const isValidUrl = url.startsWith("http://") || url.startsWith("https://");
      const isBrokenStream = url.includes("example.com") || url.includes("YOUR_URL") || url.includes("broken_link") || url.includes("localhost");

      if (isValidUrl && !isBrokenStream) {
        // Create deterministic unique ID by hashing the full URL and combining with clean base64 representation
        let hash = 0;
        for (let j = 0; j < url.length; j++) {
          hash = (hash << 5) - hash + url.charCodeAt(j);
          hash |= 0;
        }
        const b64 = Buffer.from(url).toString("base64").replace(/[^a-zA-Z0-9]/g, "");
        const id = "ch" + Math.abs(hash).toString(36) + b64.substring(b64.length > 20 ? b64.length - 12 : 0);
        
        channels.push({
          id,
          name: currentInfo.name,
          logo: currentInfo.logo,
          group: currentInfo.group,
          url,
          playlistId: playlist.id,
          country: currentInfo.country,
          language: currentInfo.language,
          category: currentInfo.category,
          tvgId: currentInfo.tvgId || undefined,
          tvgName: currentInfo.tvgName || undefined
        });
      }
      currentInfo = null;
    }
  }
  return channels;
}

// In-memory per-playlist cache to prevent redundant downloads
const serverPlaylistCache = new Map<string, Channel[]>();
const TV_CACHE_FILE = path.join(process.cwd(), "iptv_cache.json");

// Helper to save unified channels to persistent file cache for near-instant client delivery
function saveTvCacheToFile() {
  try {
    fs.writeFileSync(TV_CACHE_FILE, JSON.stringify(cachedChannels, null, 2), "utf-8");
    console.log(`[Cache] Successfully wrote ${cachedChannels.length} IPTV channels to persistent file cache.`);
  } catch (err: any) {
    console.error("[Cache] Failed to write persistent TV file cache:", err.message);
  }
}

// Helper to load unified channels from persistent file cache on server starts
function loadTvCacheFromFile() {
  try {
    if (fs.existsSync(TV_CACHE_FILE)) {
      const raw = fs.readFileSync(TV_CACHE_FILE, "utf-8");
      const loaded = JSON.parse(raw);
      if (Array.isArray(loaded) && loaded.length > 0) {
        cachedChannels = loaded;
        rebuildCachedFilters();
        console.log(`[Cache] Preloaded ${cachedChannels.length} IPTV channels from persistent file cache.`);
        return true;
      }
    }
  } catch (err: any) {
    console.error("[Cache] Failed to read persistent TV file cache:", err.message);
  }
  return false;
}

// Rebuild unified channel list from cached playlists
function rebuildUnifiedServerCache() {
  const all: Channel[] = [];
  const seenUrls = new Set<string>();

  // Order playlists to maintain prioritization
  const enabledPlaylists = playlists.filter(p => p.enabled);
  for (const playlist of enabledPlaylists) {
    const listChannels = serverPlaylistCache.get(playlist.id);
    if (!listChannels) continue;

    for (const chan of listChannels) {
      // Validate logo URL
      const hasValidLogo = chan.logo && (chan.logo.startsWith("http://") || chan.logo.startsWith("https://")) && !chan.logo.includes("example.com");
      const cleanLogo = hasValidLogo ? chan.logo : "";

      if (!seenUrls.has(chan.url)) {
        seenUrls.add(chan.url);
        all.push({
          ...chan,
          logo: cleanLogo
        });
      } else if (cleanLogo) {
        // If duplicate URL and this one has a valid logo, update
        const idx = all.findIndex(c => c.url === chan.url);
        if (idx !== -1 && !all[idx].logo) {
          all[idx].logo = cleanLogo;
        }
      }
    }
  }

  cachedChannels = all;
  rebuildCachedFilters();
  // Persist to local JSON file for instant load on server restart
  saveTvCacheToFile();
}

// Load and Cache IPTV playlists concurrently and progressively
async function loadTvPlaylists(forceRefresh = false) {
  if (isTvLoading && !forceRefresh) return;
  isTvLoading = true;
  tvLoadError = null;
  failedPlaylistIds = [];

  // Try preloading from cache first to give the user immediate channel list availability
  const hasCache = loadTvCacheFromFile();
  if (hasCache && !forceRefresh) {
    console.log("[Cache] Channels available instantly via persistent file. Loading updates silently in the background...");
    // Let the user browse immediately while we silently sync updates in the background
    isTvLoading = false; 
  } else {
    console.log("Loading IPTV M3U playlists concurrently and progressively...");
  }
  
  const enabledPlaylists = playlists.filter(p => p.enabled);
  
  // Kick off concurrent fetches
  const promises = enabledPlaylists.map(async (playlist) => {
    try {
      // Return cached results immediately if session caching is active and no force refresh is requested
      if (!forceRefresh && serverPlaylistCache.has(playlist.id)) {
        console.log(`Server serving playlist from cache: ${playlist.name}`);
        return;
      }

      console.log(`Fetching playlist: ${playlist.name} from ${playlist.playlistUrl}`);
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 15000); // 15s timeout
      
      const response = await fetch(playlist.playlistUrl, { signal: controller.signal });
      clearTimeout(timeoutId);
      
      if (!response.ok) throw new Error(`HTTP Error ${response.status}`);
      const text = await response.text();
      const channels = parseM3u(text, playlist);
      
      console.log(`Successfully parsed ${channels.length} channels from ${playlist.name}`);
      
      // Store in per-playlist memory cache
      serverPlaylistCache.set(playlist.id, channels);
      
      // Progressively update unified cache to let user see pages build up
      rebuildUnifiedServerCache();
    } catch (e: any) {
      console.error(`Error loading playlist ${playlist.name}:`, e.message);
      failedPlaylistIds.push(playlist.id);
    }
  });

  // Make sure we initialize from cache on first run if anything is already cached
  if (!forceRefresh && serverPlaylistCache.size > 0) {
    rebuildUnifiedServerCache();
  }

  // Let loading continue in the background. When all settle, we mark isTvLoading = false.
  Promise.allSettled(promises).then(() => {
    isTvLoading = false;
    console.log(`IPTV Initialization progressive cycle complete. Unified cache has: ${cachedChannels.length} channels`);
  });
}

// Kick off TV playlist load in background (which is fast due to persistent JSON file backup!)
loadTvPlaylists().catch(console.error);

// Middleware to verify TMDB key existence
const checkTmdbKey = (req: express.Request, res: express.Response, next: express.NextFunction) => {
  const key = getDynamicTmdbKey(req);
  if (!key) {
    res.status(401).json({
      error: "TMDB_API_KEY_MISSING",
      message: "The VITE_TMDB_API_KEY environment variable is not set. Please add it via the AI Studio secrets panel."
    });
    return;
  }
  (req as any).tmdbApiKey = key;
  next();
};

// Generic TMDB fetch helper
async function fetchFromTmdb(endpoint: string, queryParams: Record<string, string> = {}, req?: express.Request) {
  const key = (req as any)?.tmdbApiKey || getDynamicTmdbKey(req);
  if (!key) {
    throw new Error("TMDB_API_KEY_MISSING");
  }

  const params = new URLSearchParams({
    api_key: key,
    language: "en-US",
    ...queryParams
  });

  const url = `https://api.themoviedb.org/3${endpoint}?${params.toString()}`;
  const response = await fetch(url);
  
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`TMDB API Error (${response.status}): ${errorText}`);
  }
  
  return response.json();
}

// API ROUTE: Live-TV Streams with advanced filtering, sorting, and metadata aggregation
app.get("/api/live-tv", async (req, res) => {
  const page = parseInt(req.query.page as string) || 1;
  const limit = parseInt(req.query.limit as string) || 24;
  const search = (req.query.search as string || "").trim().toLowerCase();
  const playlistId = req.query.playlistId as string;
  const group = req.query.group as string;
  const category = req.query.category as string;
  const country = req.query.country as string;
  const language = req.query.language as string;
  const sort = req.query.sort as string || "none"; // 'asc', 'desc', or 'none'

  // Refresh trigger
  if (req.query.refresh === "true") {
    await loadTvPlaylists();
  }

  let filtered = [...cachedChannels];

  // Apply strict filters
  if (playlistId) {
    filtered = filtered.filter(c => c.playlistId === playlistId);
  }

  if (category) {
    if (category === "Featured Channels") {
      filtered = filtered.filter(c => c.playlistId === "lgchannels" || c.playlistId === "samsungtvplus" || c.playlistId === "plutotv");
    } else if (category === "Trending Channels") {
      filtered = filtered.filter(c => c.playlistId === "freetv" || c.playlistId === "plutotv");
    } else if (category === "Recently Added") {
      // Just slice a segment or show Free TV
      filtered = filtered.filter(c => c.playlistId === "freetv");
    } else if (category === "Kids") {
      filtered = filtered.filter(c => 
        c.category === "Animation" || 
        c.group.toLowerCase().includes("kids") || 
        c.group.toLowerCase().includes("cartoon") || 
        c.name.toLowerCase().includes("kids") || 
        c.name.toLowerCase().includes("cartoon")
      );
    } else if (category === "Countries") {
      filtered = filtered.filter(c => c.playlistId === "ca" || c.playlistId === "br" || c.playlistId === "es" || (c.country && c.country !== "Global"));
    } else if (category === "Search") {
      // Fallback for search tab, normally filtered by search parameter
    } else {
      // Direct category or playlist matching (like Sports, Movies, Entertainment, News, Music, Animation, Documentary)
      filtered = filtered.filter(c => 
        c.category === category || 
        c.playlistId === category.toLowerCase().replace(/\s+/g, "")
      );
    }
  }

  if (group) {
    filtered = filtered.filter(c => c.group === group);
  }

  if (country) {
    filtered = filtered.filter(c => c.country === country);
  }

  if (language) {
    filtered = filtered.filter(c => c.language === language);
  }

  if (search) {
    filtered = filtered.filter(c => 
      c.name.toLowerCase().includes(search) || 
      c.group.toLowerCase().includes(search) ||
      c.country.toLowerCase().includes(search) ||
      c.language.toLowerCase().includes(search)
    );
  }

  // Alphabetical sort if specified
  if (sort === "asc") {
    filtered.sort((a, b) => a.name.localeCompare(b.name));
  } else if (sort === "desc") {
    filtered.sort((a, b) => b.name.localeCompare(a.name));
  }

  // Use pre-calculated global cached filter arrays for immediate response speed and low CPU usage
  const groups = cachedGroups;
  const categories = cachedCategories;
  const countries = cachedCountries;
  const languages = cachedLanguages;

  const total = filtered.length;
  const start = (page - 1) * limit;
  const end = page * limit;
  const items = filtered.slice(start, end);

  res.json({
    channels: items,
    pagination: {
      page,
      limit,
      total,
      totalPages: Math.ceil(total / limit)
    },
    meta: {
      isTvLoading,
      tvLoadError,
      groups,
      categories,
      countries,
      languages,
      failedPlaylistIds,
      totalLoaded: cachedChannels.length
    }
  });
});

// API ROUTE: Get single TV channel by encoded base64 URL id
app.get("/api/live-tv/channel/:id", (req, res) => {
  const channel = cachedChannels.find(c => c.id === req.params.id);
  if (!channel) {
    res.status(404).json({ error: "Channel not found" });
    return;
  }
  res.json(channel);
});

// API ROUTE: TMDB Trending
app.get("/api/tmdb/trending", checkTmdbKey, async (req, res) => {
  try {
    const type = req.query.type as string || "all"; // all, movie, tv
    const data = await fetchFromTmdb(`/trending/${type}/week`, { page: req.query.page as string || "1" }, req);
    res.json(data);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// API ROUTE: TMDB Discover
app.get("/api/tmdb/discover", checkTmdbKey, async (req, res) => {
  try {
    const type = req.query.type as string || "movie"; // movie or tv
    const params: Record<string, string> = {};
    
    // Forward relevant discovery filters
    if (req.query.with_genres) params.with_genres = req.query.with_genres as string;
    if (req.query.sort_by) params.sort_by = req.query.sort_by as string;
    if (req.query.page) params.page = req.query.page as string;
    if (req.query.with_keywords) params.with_keywords = req.query.with_keywords as string;
    if (req.query.with_original_language) params.with_original_language = req.query.with_original_language as string;
    if (req.query["primary_release_date.gte"]) params["primary_release_date.gte"] = req.query["primary_release_date.gte"] as string;
    if (req.query["primary_release_date.lte"]) params["primary_release_date.lte"] = req.query["primary_release_date.lte"] as string;
    if (req.query["first_air_date.gte"]) params["first_air_date.gte"] = req.query["first_air_date.gte"] as string;
    if (req.query["first_air_date.lte"]) params["first_air_date.lte"] = req.query["first_air_date.lte"] as string;
    if (req.query.year) params.year = req.query.year as string;
    if (req.query.first_air_date_year) params.first_air_date_year = req.query.first_air_date_year as string;

    const data = await fetchFromTmdb(`/discover/${type}`, params, req);
    res.json(data);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// API ROUTE: TMDB Search (Multi)
app.get("/api/tmdb/search", checkTmdbKey, async (req, res) => {
  try {
    const query = req.query.query as string || "";
    const page = req.query.page as string || "1";
    if (!query) {
      res.json({ results: [], page: 1, total_pages: 1, total_results: 0 });
      return;
    }
    const data = await fetchFromTmdb("/search/multi", { query, page }, req);
    res.json(data);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// API ROUTE: TMDB Anime Special Discovery
app.get("/api/tmdb/anime", checkTmdbKey, async (req, res) => {
  try {
    const page = req.query.page as string || "1";
    const type = req.query.type as string || "tv"; // tv or movie (anime is often tv shows but can be movies)
    
    // Default to latest releases (2024, 2025, 2026) for freshness
    const dateFilterParam = type === "tv" ? "first_air_date.gte" : "primary_release_date.gte";
    const animeParams: Record<string, string> = {
      with_genres: "16",
      with_original_language: "ja",
      sort_by: "popularity.desc",
      page,
      [dateFilterParam]: "2024-01-01"
    };

    const data = await fetchFromTmdb(`/discover/${type}`, animeParams, req);
    res.json(data);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// API ROUTE: TMDB Movie or TV details (with credits, videos, and recommendations in parallel)
app.get("/api/tmdb/details/:type/:id", checkTmdbKey, async (req, res) => {
  try {
    const { type, id } = req.params;
    if (type !== "movie" && type !== "tv") {
      res.status(400).json({ error: "Invalid content type" });
      return;
    }

    const details = await fetchFromTmdb(`/${type}/${id}`, { 
      append_to_response: "images,videos,credits,recommendations,similar,reviews,external_ids",
      include_image_language: "en,null"
    }, req);

    const cast = details.credits?.cast || [];
    const crew = details.credits?.crew || [];
    const videos = details.videos?.results || [];
    const recommendations = details.recommendations?.results || [];
    const similar = details.similar?.results || [];
    const reviews = details.reviews?.results || [];
    const external_ids = details.external_ids || {};
    
    // Filter trailers for backwards compatibility
    const trailers = videos.filter((v: any) => v.site === "YouTube" && v.type === "Trailer");

    res.json({
      details,
      credits: cast,
      crew,
      videos,
      recommendations,
      similar,
      reviews,
      external_ids,
      trailers
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// API ROUTE: TMDB Person (Actor) details and their credits
app.get("/api/tmdb/person/:id", checkTmdbKey, async (req, res) => {
  try {
    const { id } = req.params;
    const [details, credits] = await Promise.all([
      fetchFromTmdb(`/person/${id}`, {}, req),
      fetchFromTmdb(`/person/${id}/combined_credits`, {}, req).catch(() => ({ cast: [], crew: [] }))
    ]);
    res.json({
      details,
      credits: credits.cast || []
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// API ROUTE: TMDB Collection details
app.get("/api/tmdb/collection/:id", checkTmdbKey, async (req, res) => {
  try {
    const { id } = req.params;
    const data = await fetchFromTmdb(`/collection/${id}`, {}, req);
    res.json(data);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// API ROUTE: TMDB TV Season details
app.get("/api/tmdb/tv/:id/season/:season_number", checkTmdbKey, async (req, res) => {
  try {
    const { id, season_number } = req.params;
    const data = await fetchFromTmdb(`/tv/${id}/season/${season_number}`, {}, req);
    res.json(data);
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// API ROUTE: TMDB Genres List
app.get("/api/tmdb/genres", checkTmdbKey, async (req, res) => {
  try {
    const [movieGenres, tvGenres] = await Promise.all([
      fetchFromTmdb("/genre/movie/list", {}, req).catch(() => ({ genres: [] })),
      fetchFromTmdb("/genre/tv/list", {}, req).catch(() => ({ genres: [] }))
    ]);

    res.json({
      movie: movieGenres.genres || [],
      tv: tvGenres.genres || []
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Helper to slugify titles for premium SEO-friendly URLs
function slugify(text: string): string {
  return text
    .toString()
    .toLowerCase()
    .trim()
    .replace(/\s+/g, "-")
    .replace(/[^\w\-]+/g, "")
    .replace(/\-\-+/g, "-")
    .replace(/^-+/, "")
    .replace(/-+$/, "");
}

// Global server-side metadata renderer for pristine SEO indexing and social shares
async function handleSeoInjection(reqPath: string, rawHtml: string, host: string, protocol: string): Promise<string> {
  let title = "Star King OTT - Live TV, Movies, TV Shows & Anime Stream Hub";
  let description = "Watch Live TV, latest Movies, full TV Shows, and trending Anime in HD quality on Star King OTT. Lag-free multi-server streaming with real-time updates.";
  let keywords = "star king ott, live tv, stream movies online, watch tv shows, anime stream, high performance media hub";
  let ogType = "website";
  let ogImage = "https://img.icons8.com/color/192/television.png";
  const canonicalUrl = `${protocol}://${host}${reqPath}`;
  
  let structuredData: any = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "name": "Star King OTT",
    "url": `${protocol}://${host}/`,
    "description": "Premium High-Performance Streaming Platform for Live TV, Movies, TV Shows, and Anime.",
    "potentialAction": {
      "@type": "SearchAction",
      "target": `${protocol}://${host}/?search={search_term_string}`,
      "query-input": "required name=search_term_string"
    }
  };

  try {
    // 1. Movie details route
    if (reqPath.startsWith("/movie/")) {
      const slugAndId = reqPath.split("/movie/")[1];
      const match = slugAndId?.match(/-(\d+)$/);
      const tmdbId = match ? match[1] : slugAndId;
      if (tmdbId && /^\d+$/.test(tmdbId)) {
        const details = await fetchFromTmdb(`/movie/${tmdbId}`);
        if (details && details.title) {
          const year = details.release_date ? new Date(details.release_date).getFullYear() : "";
          const rating = details.vote_average ? details.vote_average.toFixed(1) : "0.0";
          const genres = details.genres ? details.genres.map((g: any) => g.name).join(", ") : "Entertainment";
          
          title = `${details.title} (${year}) - Watch Movie Online in HD | Star King OTT`;
          description = `Stream ${details.title} (${year}) in premium HD quality on Star King OTT. TMDB Rating: ⭐ ${rating}/10. Genre: ${genres}. Tagline: ${details.tagline || "None"}. Overview: ${details.overview ? details.overview.substring(0, 150) : "Watch full movie online now"}...`;
          keywords = `${details.title.toLowerCase()}, watch ${details.title.toLowerCase()} online, ${details.title.toLowerCase()} hd stream, star king movies`;
          ogType = "video.movie";
          if (details.poster_path) {
            ogImage = `https://image.tmdb.org/t/p/w780${details.poster_path}`;
          } else if (details.backdrop_path) {
            ogImage = `https://image.tmdb.org/t/p/w780${details.backdrop_path}`;
          }

          structuredData = {
            "@context": "https://schema.org",
            "@type": "Movie",
            "name": details.title,
            "alternativeHeadline": details.original_title,
            "description": details.overview,
            "image": ogImage,
            "datePublished": details.release_date,
            "genre": genres,
            "aggregateRating": {
              "@type": "AggregateRating",
              "ratingValue": rating,
              "bestRating": "10",
              "ratingCount": details.vote_count || "1"
            }
          };
        }
      }
    } 
    // 2. TV Show details route
    else if (reqPath.startsWith("/tv/")) {
      const slugAndId = reqPath.split("/tv/")[1];
      const match = slugAndId?.match(/-(\d+)$/);
      const tmdbId = match ? match[1] : slugAndId;
      if (tmdbId && /^\d+$/.test(tmdbId)) {
        const details = await fetchFromTmdb(`/tv/${tmdbId}`);
        if (details && details.name) {
          const year = details.first_air_date ? new Date(details.first_air_date).getFullYear() : "";
          const rating = details.vote_average ? details.vote_average.toFixed(1) : "0.0";
          const genres = details.genres ? details.genres.map((g: any) => g.name).join(", ") : "Series";
          
          title = `${details.name} (TV Series) - Full Seasons & Episodes Online | Star King OTT`;
          description = `Watch ${details.name} on Star King OTT. TMDB Rating: ⭐ ${rating}/10. Genre: ${genres}. Seasons: ${details.number_of_seasons}, Episodes: ${details.number_of_episodes}. Overview: ${details.overview ? details.overview.substring(0, 150) : "Watch full series now"}...`;
          keywords = `${details.name.toLowerCase()}, watch ${details.name.toLowerCase()} tv show, stream ${details.name.toLowerCase()}, full series episodes`;
          ogType = "video.tv_show";
          if (details.poster_path) {
            ogImage = `https://image.tmdb.org/t/p/w780${details.poster_path}`;
          } else if (details.backdrop_path) {
            ogImage = `https://image.tmdb.org/t/p/w780${details.backdrop_path}`;
          }

          structuredData = {
            "@context": "https://schema.org",
            "@type": "TVSeries",
            "name": details.name,
            "alternativeHeadline": details.original_name,
            "description": details.overview,
            "image": ogImage,
            "datePublished": details.first_air_date,
            "numberOfSeasons": details.number_of_seasons || "1",
            "numberOfEpisodes": details.number_of_episodes || "1",
            "aggregateRating": {
              "@type": "AggregateRating",
              "ratingValue": rating,
              "bestRating": "10",
              "ratingCount": details.vote_count || "1"
            }
          };
        }
      }
    }
    // 3. Section index pages
    else if (reqPath === "/movies") {
      title = "Latest Movies Catalog - Watch Blockbuster HD Movies | Star King OTT";
      description = "Explore our vast movie catalog on Star King OTT. Stream blockbuster films, trending action, thriller, comedy, and sci-fi movies with premium dual-language server mirrors.";
      keywords = "watch movies online, watch hd movies, free movies stream, movie catalog, action sci-fi movies, star king movies";
      structuredData = {
        "@context": "https://schema.org",
        "@type": "CollectionPage",
        "name": "Latest Movies Catalog - Star King OTT",
        "description": "Premium blockbuster movies on demand with zero buffering.",
        "url": canonicalUrl
      };
    } else if (reqPath === "/tv-shows" || reqPath === "/tv") {
      title = "TV Shows Hub - Stream Full Seasons & Network Episodes | Star King OTT";
      description = "Watch popular TV shows, full seasons, and trending series episodes online. Switch between server nodes for immediate, lag-free premium web streaming.";
      keywords = "stream tv shows, watch television online, full episodes, high quality series, binge-watch tv shows, star king tv series";
      structuredData = {
        "@context": "https://schema.org",
        "@type": "CollectionPage",
        "name": "TV Shows Hub - Star King OTT",
        "description": "Watch popular TV series and network shows with full seasons on demand.",
        "url": canonicalUrl
      };
    } else if (reqPath === "/anime") {
      title = "Anime Streaming Hub - Sub & Dub HD Anime Online | Star King OTT";
      description = "Stream your favorite anime series, ongoing seasonal episodes, and top-rated classics in premium HD. Switch mirrors for dual language audio variants.";
      keywords = "watch anime online, watch subbed anime, watch dubbed anime, stream anime hd, ongoing anime shows, star king anime";
      structuredData = {
        "@context": "https://schema.org",
        "@type": "CollectionPage",
        "name": "Anime Streaming Hub - Star King OTT",
        "description": "Browse and watch subbed and dubbed anime series in HD quality.",
        "url": canonicalUrl
      };
    } else if (reqPath === "/live-tv") {
      title = "Live TV Station - Free IPTV Channel Broadcasts | Star King OTT";
      description = "Stream over 250+ Live TV IPTV channels worldwide instantly. Categories include Movies, Sports, News, Music, and Entertainment channels with active playlist engines.";
      keywords = "free live tv, watch iptv channels, watch news online, live sports stream, world television broadcast, star king live tv";
      structuredData = {
        "@context": "https://schema.org",
        "@type": "CollectionPage",
        "name": "Live TV Station - Star King OTT",
        "description": "Live IPTV channel streams globally, completely free.",
        "url": canonicalUrl
      };
    } else if (reqPath === "/install") {
      title = "Install Star King OTT App - Progressive Web App Guide";
      description = "Get the native Star King OTT application experience. Learn how to install our secure, performance-optimized Progressive Web App (PWA) on iOS and Android devices.";
    } else if (reqPath === "/telegram") {
      title = "Official Telegram Channels & Community | Star King OTT";
      description = "Join our official Telegram community channels to receive immediate stream server alerts, backup channel URLs, new movie drop announcements, and live developer support.";
    } else if (reqPath.startsWith("/watch/tv/")) {
      const parts = reqPath.split("/watch/tv/")[1]?.split("/");
      const tmdbId = parts ? parts[0] : null;
      const seasonNum = parts ? parts[1] : null;
      const episodeNum = parts ? parts[2] : null;
      if (tmdbId && /^\d+$/.test(tmdbId)) {
        const details = await fetchFromTmdb(`/tv/${tmdbId}`).catch(() => null);
        if (details && details.name) {
          title = `Watching ${details.name} - Season ${seasonNum} Episode ${episodeNum} | Star King OTT`;
          description = `Stream ${details.name} Season ${seasonNum} Episode ${episodeNum} in premium HD online now. Star King OTT delivers instant buffering-free media streaming.`;
        }
      }
    } else if (reqPath.startsWith("/anime/")) {
      const tmdbId = reqPath.split("/anime/")[1];
      if (tmdbId && /^\d+$/.test(tmdbId)) {
        const details = await fetchFromTmdb(`/tv/${tmdbId}`).catch(() => null);
        if (details && details.name) {
          title = `${details.name} (Anime) - Watch Online in HD | Star King OTT`;
          description = `Watch ongoing anime series ${details.name} online with sub and dub server channels. Overview: ${details.overview ? details.overview.substring(0, 150) : "Watch full series now"}.`;
        }
      }
    } else if (reqPath.startsWith("/genre/")) {
      const genre = reqPath.split("/genre/")[1];
      if (genre) {
        const capitalized = genre.charAt(0).toUpperCase() + genre.slice(1);
        title = `Top ${capitalized} Movies & TV Shows - Watch Online | Star King OTT`;
        description = `Browse the ultimate collection of top ${capitalized} movies and TV series online on Star King OTT. Safe, high-speed multi-mirror web streaming.`;
      }
    } else if (reqPath.startsWith("/search/")) {
      const query = decodeURIComponent(reqPath.split("/search/")[1] || "");
      if (query) {
        title = `Search Results for "${query}" - Stream Online | Star King OTT`;
        description = `Find and stream movies, TV shows, and anime related to "${query}" instantly on Star King OTT. Free dynamic server mirrors.`;
      }
    } else if (reqPath.startsWith("/country/")) {
      const country = reqPath.split("/country/")[1];
      if (country) {
        const capitalized = country.charAt(0).toUpperCase() + country.slice(1);
        title = `Stream Popular Content from ${capitalized} - Watch Online | Star King OTT`;
        description = `Discover and stream hot trending movies and TV series broadcast from ${capitalized} in high-speed HD. Check multiple player channels.`;
      }
    } else if (reqPath.startsWith("/live-tv/")) {
      const channelSlug = reqPath.split("/live-tv/")[1];
      if (channelSlug) {
        const cleaned = channelSlug.replace(/-/g, " ").replace(/\b\w/g, c => c.toUpperCase());
        title = `Watch ${cleaned} Live TV Stream - Free Online IPTV | Star King OTT`;
        description = `Stream ${cleaned} live television channel online with high performance and zero lag on Star King OTT. Part of our free worldwide IPTV broadcast platform.`;
      }
    } else if (["/about", "/privacy", "/terms", "/dmca", "/disclaimer"].includes(reqPath)) {
      const pageName = reqPath.substring(1).toUpperCase();
      title = `${pageName} Policy & Terms Statement | Star King OTT`;
      description = `Official legal documentation regarding Star King OTT ${pageName} policies, service compliance agreements, and safe-harbor copyright disclaimers.`;
    }
  } catch (err) {
    console.error("Error generating dynamic SEO meta tags:", err);
  }

  // Perform surgical index.html replacement
  let transformed = rawHtml;
  
  // Replace Title tag
  transformed = transformed.replace(
    /<title>.*?<\/title>/gi,
    `<title>${title}</title>`
  );

  // Replace Description meta tag
  transformed = transformed.replace(
    /<meta\s+name="description"\s+content=".*?"\s*\/?>/gi,
    `<meta name="description" content="${description}" />`
  );

  // Replace Keywords meta tag
  transformed = transformed.replace(
    /<meta\s+name="keywords"\s+content=".*?"\s*\/?>/gi,
    `<meta name="keywords" content="${keywords}" />`
  );

  // Replace Canonical href
  transformed = transformed.replace(
    /<link\s+rel="canonical"\s+href=".*?"\s*\/?>/gi,
    `<link rel="canonical" href="${canonicalUrl}" />`
  );

  // Replace Open Graph metadata
  transformed = transformed.replace(
    /<meta\s+property="og:url"\s+content=".*?"\s*\/?>/gi,
    `<meta property="og:url" content="${canonicalUrl}" />`
  );
  transformed = transformed.replace(
    /<meta\s+property="og:title"\s+content=".*?"\s*\/?>/gi,
    `<meta property="og:title" content="${title}" />`
  );
  transformed = transformed.replace(
    /<meta\s+property="og:description"\s+content=".*?"\s*\/?>/gi,
    `<meta property="og:description" content="${description}" />`
  );
  transformed = transformed.replace(
    /<meta\s+property="og:image"\s+content=".*?"\s*\/?>/gi,
    `<meta property="og:image" content="${ogImage}" />`
  );
  transformed = transformed.replace(
    /<meta\s+property="og:type"\s+content=".*?"\s*\/?>/gi,
    `<meta property="og:type" content="${ogType}" />`
  );

  // Replace Twitter Card metadata
  transformed = transformed.replace(
    /<meta\s+name="twitter:url"\s+content=".*?"\s*\/?>/gi,
    `<meta name="twitter:url" content="${canonicalUrl}" />`
  );
  transformed = transformed.replace(
    /<meta\s+name="twitter:title"\s+content=".*?"\s*\/?>/gi,
    `<meta name="twitter:title" content="${title}" />`
  );
  transformed = transformed.replace(
    /<meta\s+name="twitter:description"\s+content=".*?"\s*\/?>/gi,
    `<meta name="twitter:description" content="${description}" />`
  );
  transformed = transformed.replace(
    /<meta\s+name="twitter:image"\s+content=".*?"\s*\/?>/gi,
    `<meta name="twitter:image" content="${ogImage}" />`
  );

  // Replace Structured Data script block safely
  const jsonLdRegex = /<script\s+type="application\/ld\+json"\s+id="seo-structured-data">[\s\S]*?<\/script>/gi;
  const newJsonLdBlock = `<script type="application/ld+json" id="seo-structured-data">
${JSON.stringify(structuredData, null, 2)}
</script>`;
  
  if (jsonLdRegex.test(transformed)) {
    transformed = transformed.replace(jsonLdRegex, newJsonLdBlock);
  } else {
    transformed = transformed.replace("</head>", `${newJsonLdBlock}\n</head>`);
  }

  return transformed;
}

// Global Sitemap Generator Endpoint
app.get("/sitemap.xml", async (req, res) => {
  try {
    const host = req.headers.host || "star-king-ott.com";
    const protocol = req.secure || req.headers["x-forwarded-proto"] === "https" ? "https" : "http";
    const baseUrl = `${protocol}://${host}`;
    
    // Core indexable sections
    const paths = [
      "",
      "/movies",
      "/tv-shows",
      "/anime",
      "/live-tv",
      "/telegram",
      "/install",
      "/about",
      "/privacy",
      "/terms",
      "/dmca",
      "/disclaimer"
    ];

    let xml = `<?xml version="1.0" encoding="UTF-8"?>\n`;
    xml += `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n`;

    const currentDate = new Date().toISOString().split("T")[0];

    // Build static URL entries
    for (const p of paths) {
      xml += `  <url>\n`;
      xml += `    <loc>${baseUrl}${p}</loc>\n`;
      xml += `    <lastmod>${currentDate}</lastmod>\n`;
      xml += `    <changefreq>${p === "" ? "daily" : "weekly"}</changefreq>\n`;
      xml += `    <priority>${p === "" ? "1.0" : "0.7"}</priority>\n`;
      xml += `  </url>\n`;
    }

    // Hydrate trending dynamically into sitemap to boost search indexing speeds
    try {
      const [trendingMovies, trendingTv] = await Promise.all([
        fetchFromTmdb("/trending/movie/week").catch(() => ({ results: [] })),
        fetchFromTmdb("/trending/tv/week").catch(() => ({ results: [] }))
      ]);

      const topMovies = (trendingMovies.results || []).slice(0, 30);
      const topTv = (trendingTv.results || []).slice(0, 30);

      for (const m of topMovies) {
        if (m.title && m.id) {
          const slug = slugify(m.title);
          xml += `  <url>\n`;
          xml += `    <loc>${baseUrl}/movie/${slug}-${m.id}</loc>\n`;
          xml += `    <lastmod>${currentDate}</lastmod>\n`;
          xml += `    <changefreq>weekly</changefreq>\n`;
          xml += `    <priority>0.8</priority>\n`;
          xml += `  </url>\n`;
        }
      }

      for (const t of topTv) {
        if (t.name && t.id) {
          const slug = slugify(t.name);
          xml += `  <url>\n`;
          xml += `    <loc>${baseUrl}/tv/${slug}-${t.id}</loc>\n`;
          xml += `    <lastmod>${currentDate}</lastmod>\n`;
          xml += `    <changefreq>weekly</changefreq>\n`;
          xml += `    <priority>0.8</priority>\n`;
          xml += `  </url>\n`;
        }
      }
    } catch (e) {
      console.error("Dynamic sitemap generation error:", e);
    }

    xml += `</urlset>\n`;

    res.header("Content-Type", "application/xml");
    res.status(200).send(xml);
  } catch (err: any) {
    res.status(500).send(`<error>${err.message}</error>`);
  }
});

// Global robots.txt Endpoint with proper exclusions
app.get("/robots.txt", (req, res) => {
  const host = req.headers.host || "star-king-ott.com";
  const protocol = req.secure || req.headers["x-forwarded-proto"] === "https" ? "https" : "http";
  
  let robots = `User-agent: *\n`;
  robots += `Allow: /\n`;
  robots += `Disallow: /api/\n`;
  robots += `Disallow: /private/\n`;
  robots += `Disallow: /*?search=\n`;
  robots += `\n`;
  robots += `Sitemap: ${protocol}://${host}/sitemap.xml\n`;
  
  res.header("Content-Type", "text/plain");
  res.status(200).send(robots);
});

// Start server with unified server-side hydration for React SPA routing
async function start() {
  // Vite integration
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });

    // Intercept document request paths for server-side SEO hydration in dev mode
    app.use(async (req, res, next) => {
      const url = req.originalUrl;
      const isAsset = /\.(js|css|png|jpg|jpeg|gif|svg|ico|json|woff|woff2|ttf|map)$/i.test(url) || 
                      url.startsWith("/@") || 
                      url.startsWith("/src/");
                      
      if (isAsset) {
        return next();
      }
      
      try {
        const rawHtml = fs.readFileSync(path.join(process.cwd(), "index.html"), "utf-8");
        const transformedHtml = await vite.transformIndexHtml(url, rawHtml);
        const host = req.headers.host || "localhost:3000";
        const protocol = "http";
        const seoHtml = await handleSeoInjection(req.path, transformedHtml, host, protocol);
        res.status(200).set({ "Content-Type": "text/html" }).end(seoHtml);
      } catch (e) {
        vite.middlewares(req, res, next);
      }
    });

    app.use(vite.middlewares);
    console.log("Vite middleware mounted with dev SEO injection engine.");
  } else {
    const distPath = path.join(process.cwd(), "dist");
    
    // Serve production static assets (JS, CSS, images) with caching, leaving index.html alone
    app.use(express.static(distPath, { index: false }));
    
    // Serve dynamically injected index.html for all page requests
    app.get("*", async (req, res) => {
      try {
        const indexHtmlPath = path.join(distPath, "index.html");
        if (fs.existsSync(indexHtmlPath)) {
          const rawHtml = fs.readFileSync(indexHtmlPath, "utf-8");
          const host = req.headers.host || "star-king-ott.com";
          const protocol = req.secure || req.headers["x-forwarded-proto"] === "https" ? "https" : "http";
          const seoHtml = await handleSeoInjection(req.path, rawHtml, host, protocol);
          res.setHeader("Content-Type", "text/html");
          res.send(seoHtml);
        } else {
          res.status(404).send("Index template missing.");
        }
      } catch (err) {
        console.error("Prod SEO Injection Error:", err);
        res.sendFile(path.join(distPath, "index.html"));
      }
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Star King OTT Server listening on http://localhost:${PORT}`);
  });
}

start().catch(console.error);
