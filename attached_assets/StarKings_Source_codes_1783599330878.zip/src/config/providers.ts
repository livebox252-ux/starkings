export interface Provider {
  id: string;
  name: string;
  baseUrl: string;
  movieUrl: string;
  tvUrl: string;
  priority: number;
  status: "Enabled" | "Disabled";
}

export const providers: Provider[] = [
  {
    id: "cinesrc",
    name: "CineSrc",
    baseUrl: "https://cinesrc.st",
    movieUrl: "https://cinesrc.st/embed/movie/{tmdbId}",
    tvUrl: "https://cinesrc.st/embed/tv/{tmdbId}?s={season}&e={episode}",
    priority: 1,
    status: "Enabled"
  },
  {
    id: "vidsrc-sbs",
    name: "VidSrc SBS",
    baseUrl: "https://vidsrc.sbs",
    movieUrl: "https://vidsrc.sbs/embed/movie/{tmdbId}",
    tvUrl: "https://vidsrc.sbs/embed/tv/{tmdbId}/{season}/{episode}",
    priority: 2,
    status: "Enabled"
  }
];

export function getProviderUrl(
  provider: Provider,
  type: "movie" | "tv",
  tmdbId: string,
  season?: number,
  episode?: number
): string {
  if (type === "movie") {
    return provider.movieUrl
      .replace("{tmdbId}", tmdbId)
      .replace("{id}", tmdbId);
  } else {
    return provider.tvUrl
      .replace("{tmdbId}", tmdbId)
      .replace("{id}", tmdbId)
      .replace("{season}", String(season ?? 1))
      .replace("{episode}", String(episode ?? 1));
  }
}
