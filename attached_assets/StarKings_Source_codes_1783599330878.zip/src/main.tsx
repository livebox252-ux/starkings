import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import ErrorBoundary from './components/ErrorBoundary';
import { setupClientFallback } from "./utils/clientApiFallback";
import './index.css';

// Run client-side API emulation fallback for Netlify and other static serverless platforms
setupClientFallback();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
);

