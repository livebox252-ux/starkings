import { playlists, PlaylistConfig } from "../config/playlists";

// In-memory cache for IPTV channels on client side
interface Channel {
  id: string;
  name: string;
  logo: string;
  group: string;
  url: string;
  playlistId: string;
  country: string;
  language: string;
  category: string;
  tvgId?: string;
  tvgName?: string;
}

let clientCachedChannels: Channel[] = [];
let isTvLoading = false;
let tvLoadError: string | null = null;
let failedPlaylistIds: string[] = [];

// Parse M3U playlist content on the client side
function parseM3uOnClient(content: string, playlist: PlaylistConfig): Channel[] {
  const channels: Channel[] = [];
  const lines = content.split("\n");
  
  let currentInfo: { 
    name: string; 
    tvgId: string;
    tvgName: string;
    logo: string; 
    group: string; 
    country: string; 
    language: string; 
    category: string; 
  } | null = null;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (line.startsWith("#EXTINF:")) {
      const commaIndex = line.lastIndexOf(",");
      let name = commaIndex !== -1 ? line.substring(commaIndex + 1).trim() : "";
      
      const getAttr = (key: string): string => {
        const match = line.match(new RegExp(`${key}="([^"]*)"`, "i"));
        return match ? match[1].trim() : "";
      };

      const tvgId = getAttr("tvg-id");
      const tvgName = getAttr("tvg-name");
      const tvgLogo = getAttr("tvg-logo") || getAttr("logo");
      const groupTitle = getAttr("group-title");
      const country = getAttr("tvg-country") || getAttr("country");
      const language = getAttr("tvg-language") || getAttr("language");

      if (!name && tvgName) name = tvgName;
      if (!name && tvgId) name = tvgId;
      if (!name) name = "Unknown Channel";

      const nameLower = name.toLowerCase();
      if (
        nameLower.includes("local stream") || 
        nameLower.includes("undefined") || 
        nameLower.includes("placeholder") ||
        name === "Unknown Channel"
      ) {
        currentInfo = null;
        continue;
      }

      let defaultLang = "English";
      if (playlist.id === "de") defaultLang = "German";
      else if (playlist.id === "fr") defaultLang = "French";
      else if (playlist.id === "br") defaultLang = "Portuguese";
      else if (playlist.id === "es") defaultLang = "Spanish";

      const assignedCategory = playlist.category;
      const assignedGroup = groupTitle || playlist.name;

      currentInfo = { 
        name, 
        tvgId,
        tvgName,
        logo: tvgLogo, 
        group: assignedGroup || assignedCategory, 
        country: country || playlist.region || "Global", 
        language: language || defaultLang, 
        category: assignedCategory 
      };
    } else if (line.startsWith("http") && currentInfo) {
      const url = line;
      const isValidUrl = url.startsWith("http://") || url.startsWith("https://");
      const isBrokenStream = url.includes("example.com") || url.includes("YOUR_URL") || url.includes("broken_link") || url.includes("localhost");

      if (isValidUrl && !isBrokenStream) {
        let hash = 0;
        for (let j = 0; j < url.length; j++) {
          hash = (hash << 5) - hash + url.charCodeAt(j);
          hash |= 0;
        }
        
        // Base64 ID generator
        const b64 = btoa(url).replace(/[^a-zA-Z0-9]/g, "");
        const id = "ch" + Math.abs(hash).toString(36) + b64.substring(b64.length > 20 ? b64.length - 12 : 0);
        
        channels.push({
          id,
          name: currentInfo.name,
          logo: currentInfo.logo,
          group: currentInfo.group,
          url,
          playlistId: playlist.id,
          country: currentInfo.country,
          language: currentInfo.language,
          category: currentInfo.category,
          tvgId: currentInfo.tvgId || undefined,
          tvgName: currentInfo.tvgName || undefined
        });
      }
      currentInfo = null;
    }
  }
  return channels;
}

// In-memory per-playlist cache on client side to prevent redundant downloads
const clientPlaylistCache = new Map<string, Channel[]>();

// Rebuild client unified channel list from cached playlists
function rebuildUnifiedClientCache() {
  const all: Channel[] = [];
  const seenUrls = new Set<string>();

  const enabledPlaylists = playlists.filter(p => p.enabled);
  for (const playlist of enabledPlaylists) {
    const listChannels = clientPlaylistCache.get(playlist.id);
    if (!listChannels) continue;

    for (const chan of listChannels) {
      const hasValidLogo = chan.logo && (chan.logo.startsWith("http://") || chan.logo.startsWith("https://")) && !chan.logo.includes("example.com");
      const cleanLogo = hasValidLogo ? chan.logo : "";

      if (!seenUrls.has(chan.url)) {
        seenUrls.add(chan.url);
        all.push({
          ...chan,
          logo: cleanLogo
        });
      } else if (cleanLogo) {
        const idx = all.findIndex(c => c.url === chan.url);
        if (idx !== -1 && !all[idx].logo) {
          all[idx].logo = cleanLogo;
        }
      }
    }
  }

  clientCachedChannels = all;
}

// Load playlists concurrently and progressively in the browser
async function loadTvPlaylistsOnClient(forceRefresh = false) {
  if (isTvLoading && !forceRefresh) return;
  isTvLoading = true;
  tvLoadError = null;
  failedPlaylistIds = [];
  
  const enabledPlaylists = playlists.filter(p => p.enabled);
  
  const promises = enabledPlaylists.map(async (playlist) => {
    try {
      if (!forceRefresh && clientPlaylistCache.has(playlist.id)) {
        return; // already cached
      }

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s timeout on client
      
      const response = await fetch(playlist.playlistUrl, { signal: controller.signal });
      clearTimeout(timeoutId);
      
      if (!response.ok) throw new Error(`HTTP Error ${response.status}`);
      const text = await response.text();
      const parsed = parseM3uOnClient(text, playlist);
      
      // Store in per-playlist memory cache
      clientPlaylistCache.set(playlist.id, parsed);
      
      // Progressively update unified cache to let user see channels build up
      rebuildUnifiedClientCache();
    } catch (e: any) {
      console.error(`Client fallback failed loading playlist ${playlist.name}:`, e.message);
      failedPlaylistIds.push(playlist.id);
    }
  });

  if (!forceRefresh && clientPlaylistCache.size > 0) {
    rebuildUnifiedClientCache();
  }

  Promise.allSettled(promises).then(() => {
    isTvLoading = false;
  });
}

// Helper to extract TMDB API key from various sources
const getTmdbApiKey = (): string => {
  return localStorage.getItem("STARKING_TMDB_KEY") || 
         ((import.meta as any).env?.VITE_TMDB_API_KEY as string) || 
         "";
};

// Main client-side fetch router/emulator
async function handleClientFallback(url: string, options?: RequestInit): Promise<Response> {
  const urlObj = new URL(url, window.location.origin);
  const path = urlObj.pathname;
  const searchParams = urlObj.searchParams;

  const makeJsonResponse = (data: any, status = 200) => {
    return new Response(JSON.stringify(data), {
      status,
      headers: { "Content-Type": "application/json" }
    });
  };

  // 1. LIVE TV ENDPOINTS
  if (path.startsWith("/api/live-tv")) {
    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "24");
    const search = (searchParams.get("search") || "").trim().toLowerCase();
    const playlistId = searchParams.get("playlistId");
    const group = searchParams.get("group");
    const category = searchParams.get("category");
    const country = searchParams.get("country");
    const language = searchParams.get("language");
    const sort = searchParams.get("sort") || "none";
    const refresh = searchParams.get("refresh");

    if (refresh === "true" || clientCachedChannels.length === 0) {
      await loadTvPlaylistsOnClient(refresh === "true");
    }

    let filtered = [...clientCachedChannels];

    if (playlistId) filtered = filtered.filter(c => c.playlistId === playlistId);
    
    if (category) {
      if (category === "Featured Channels") {
        filtered = filtered.filter(c => c.playlistId === "lgchannels" || c.playlistId === "samsungtvplus" || c.playlistId === "plutotv");
      } else if (category === "Trending Channels") {
        filtered = filtered.filter(c => c.playlistId === "freetv" || c.playlistId === "plutotv");
      } else if (category === "Recently Added") {
        filtered = filtered.filter(c => c.playlistId === "freetv");
      } else if (category === "Kids") {
        filtered = filtered.filter(c => 
          c.category === "Animation" || 
          c.group.toLowerCase().includes("kids") || 
          c.group.toLowerCase().includes("cartoon") || 
          c.name.toLowerCase().includes("kids") || 
          c.name.toLowerCase().includes("cartoon")
        );
      } else if (category === "Countries") {
        filtered = filtered.filter(c => c.playlistId === "ca" || c.playlistId === "br" || c.playlistId === "es" || (c.country && c.country !== "Global"));
      } else if (category === "Search") {
        // Handled below by search text
      } else {
        filtered = filtered.filter(c => 
          c.category === category || 
          c.playlistId === category.toLowerCase().replace(/\s+/g, "")
        );
      }
    }

    if (group) filtered = filtered.filter(c => c.group === group);
    if (country) filtered = filtered.filter(c => c.country === country);
    if (language) filtered = filtered.filter(c => c.language === language);

    if (search) {
      filtered = filtered.filter(c => 
        c.name.toLowerCase().includes(search) || 
        c.group.toLowerCase().includes(search) ||
        c.country.toLowerCase().includes(search) ||
        c.language.toLowerCase().includes(search)
      );
    }

    if (sort === "asc") {
      filtered.sort((a, b) => a.name.localeCompare(b.name));
    } else if (sort === "desc") {
      filtered.sort((a, b) => b.name.localeCompare(a.name));
    }

    const groups = Array.from(new Set(clientCachedChannels.map(c => c.group))).filter(Boolean).sort();
    const categories = Array.from(new Set(clientCachedChannels.map(c => c.category))).filter(Boolean).sort();
    const countries = Array.from(new Set(clientCachedChannels.map(c => c.country))).filter(Boolean).sort();
    const languages = Array.from(new Set(clientCachedChannels.map(c => c.language))).filter(Boolean).sort();

    const total = filtered.length;
    const start = (page - 1) * limit;
    const end = page * limit;
    const items = filtered.slice(start, end);

    return makeJsonResponse({
      channels: items,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      },
      meta: {
        isTvLoading,
        tvLoadError,
        groups,
        categories,
        countries,
        languages,
        failedPlaylistIds,
        totalLoaded: clientCachedChannels.length
      }
    });
  }

  // 2. TMDB ENDPOINTS
  const apiKey = getTmdbApiKey();
  if (!apiKey) {
    return makeJsonResponse({
      error: "TMDB_API_KEY_MISSING",
      message: "TMDB API key is missing. Please provide it in the settings or environment."
    }, 401);
  }

  const tmdbFetch = async (endpoint: string, queryParams: Record<string, string> = {}) => {
    const tmdbUrl = new URL(`https://api.themoviedb.org/3${endpoint}`);
    tmdbUrl.searchParams.set("api_key", apiKey);
    Object.entries(queryParams).forEach(([k, v]) => {
      tmdbUrl.searchParams.set(k, v);
    });
    const res = await fetch(tmdbUrl.toString());
    if (!res.ok) {
      throw new Error(`TMDB responded with HTTP ${res.status}`);
    }
    return res.json();
  };

  try {
    // TMDB Genres
    if (path === "/api/tmdb/genres") {
      const [movieGenres, tvGenres] = await Promise.all([
        tmdbFetch("/genre/movie/list").catch(() => ({ genres: [] })),
        tmdbFetch("/genre/tv/list").catch(() => ({ genres: [] }))
      ]);
      return makeJsonResponse({
        movie: movieGenres.genres || [],
        tv: tvGenres.genres || []
      });
    }

    // TMDB Trending
    if (path === "/api/tmdb/trending") {
      const type = searchParams.get("type") || "all";
      const page = searchParams.get("page") || "1";
      const data = await tmdbFetch(`/trending/${type}/week`, { page });
      return makeJsonResponse(data);
    }

    // TMDB Discover
    if (path === "/api/tmdb/discover") {
      const type = searchParams.get("type") || "movie";
      const params: Record<string, string> = {};
      ["with_genres", "sort_by", "page", "with_keywords", "with_original_language"].forEach(param => {
        const val = searchParams.get(param);
        if (val) params[param] = val;
      });
      const data = await tmdbFetch(`/discover/${type}`, params);
      return makeJsonResponse(data);
    }

    // TMDB Search
    if (path === "/api/tmdb/search") {
      const query = searchParams.get("query") || "";
      const page = searchParams.get("page") || "1";
      if (!query) {
        return makeJsonResponse({ results: [], page: 1, total_pages: 1, total_results: 0 });
      }
      const data = await tmdbFetch("/search/multi", { query, page });
      return makeJsonResponse(data);
    }

    // TMDB Anime
    if (path === "/api/tmdb/anime") {
      const page = searchParams.get("page") || "1";
      const type = searchParams.get("type") || "tv";
      const data = await tmdbFetch(`/discover/${type}`, {
        with_genres: "16",
        with_original_language: "ja",
        sort_by: "popularity.desc",
        page
      });
      return makeJsonResponse(data);
    }

    // TMDB Collection
    if (path.startsWith("/api/tmdb/collection/")) {
      const collectionId = path.split("/").pop() || "";
      const data = await tmdbFetch(`/collection/${collectionId}`);
      return makeJsonResponse(data);
    }

    // TMDB TV Season
    const seasonMatch = path.match(/^\/api\/tmdb\/tv\/([^/]+)\/season\/([^/]+)$/);
    if (seasonMatch) {
      const tvId = seasonMatch[1];
      const seasonNum = seasonMatch[2];
      const data = await tmdbFetch(`/tv/${tvId}/season/${seasonNum}`);
      return makeJsonResponse(data);
    }

    // TMDB Person details
    const personMatch = path.match(/^\/api\/tmdb\/person\/([^/]+)$/);
    if (personMatch) {
      const personId = personMatch[1];
      const [details, credits] = await Promise.all([
        tmdbFetch(`/person/${personId}`),
        tmdbFetch(`/person/${personId}/combined_credits`).catch(() => ({ cast: [] }))
      ]);
      return makeJsonResponse({
        details,
        credits: credits.cast || []
      });
    }

    // TMDB Details
    const detailsMatch = path.match(/^\/api\/tmdb\/details\/([^/]+)\/([^/]+)$/);
    if (detailsMatch) {
      const contentType = detailsMatch[1];
      const id = detailsMatch[2];
      const data = await tmdbFetch(`/${contentType}/${id}`, {
        append_to_response: "images,videos,credits,recommendations,similar,reviews,external_ids",
        include_image_language: "en,null"
      });

      const cast = data.credits?.cast || [];
      const crew = data.credits?.crew || [];
      const videos = data.videos?.results || [];
      const recommendations = data.recommendations?.results || [];
      const similar = data.similar?.results || [];
      const reviews = data.reviews?.results || [];
      const external_ids = data.external_ids || {};
      const trailers = videos.filter((v: any) => v.site === "YouTube" && v.type === "Trailer");

      return makeJsonResponse({
        details: data,
        credits: cast,
        crew,
        videos,
        recommendations,
        similar,
        reviews,
        external_ids,
        trailers
      });
    }
  } catch (err: any) {
    return makeJsonResponse({ error: err.message || "An error occurred fetching TMDB" }, 500);
  }

  return new Response("Not Found", { status: 404 });
}

// Hook window.fetch
export function setupClientFallback() {
  const originalFetch = window.fetch;
  
  window.fetch = async function(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
    const urlStr = typeof input === "string" ? input : input instanceof URL ? input.toString() : input.url;
    
    if (urlStr.startsWith("/api/") || urlStr.includes("/api/")) {
      // Set custom key in request headers for both real backend and emulator fallback!
      const key = localStorage.getItem("STARKING_TMDB_KEY");
      if (key) {
        init = init || {};
        const headers = new Headers(init.headers || {});
        headers.set("x-tmdb-api-key", key);
        init.headers = headers;
      }

      // Check if we are hosted on Netlify or similar static service
      const isStaticDeployment = 
        window.location.hostname.includes("netlify.app") || 
        window.location.hostname.includes("github.io") || 
        window.location.hostname.includes("web.app") ||
        window.location.hostname.includes("vercel.app");

      if (isStaticDeployment) {
        // Direct route to client-side emulation to bypass 404 networks completely
        return handleClientFallback(urlStr, init);
      }

      try {
        const response = await originalFetch(input, init);
        const contentType = response.headers.get("content-type") || "";
        
        // If it's a 404, or returns HTML page instead of JSON (which happens with Netlify SPA rewrites)
        if (response.status === 404 || contentType.includes("text/html")) {
          return await handleClientFallback(urlStr, init);
        }
        return response;
      } catch (err) {
        // Fetch failed (network drop or server is offline) -> fallback
        return await handleClientFallback(urlStr, init);
      }
    }
    
    return originalFetch(input, init);
  };
}
