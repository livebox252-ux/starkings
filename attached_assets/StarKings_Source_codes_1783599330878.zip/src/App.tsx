import { useState, useEffect } from "react";
import { ArrowUp } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import HomeView from "./components/HomeView";
import BrowseView from "./components/BrowseView";
import AnimeView from "./components/AnimeView";
import LegalDocs from "./components/LegalDocs";
import TelegramView from "./components/TelegramView";
import SearchModal from "./components/SearchModal";
import WatchPage from "./components/WatchPage";
import SplashScreen from "./components/SplashScreen";

// Helper to slugify titles on the client-side
const slugify = (text: string): string => {
  return text
    .toString()
    .toLowerCase()
    .trim()
    .replace(/\s+/g, "-")
    .replace(/[^\w\-]+/g, "")
    .replace(/\-\-+/g, "-")
    .replace(/^-+/, "")
    .replace(/-+$/, "");
};

export default function App() {
  const [currentTab, setCurrentTab] = useState<string>("home");
  const [searchOpen, setSearchOpen] = useState<boolean>(false);
  const [splashComplete, setSplashComplete] = useState<boolean>(false);
  
  // Watch states
  const [watchType, setWatchType] = useState<"movie" | "tv" | null>(null);
  const [watchId, setWatchId] = useState<string | null>(null);
  const [initialSeason, setInitialSeason] = useState<number | undefined>(undefined);
  const [initialEpisode, setInitialEpisode] = useState<number | undefined>(undefined);
  const [backTab, setBackTab] = useState<string>("home");
  const [showScrollTop, setShowScrollTop] = useState<boolean>(false);

  // Monitor page scroll height to toggle the scroll-to-top indicator
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 400) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);



  // Synchronize initial URL pathways & handle back/forward browser navigation using normal clean URLs
  useEffect(() => {
    const syncRouteWithState = () => {
      let path = window.location.pathname || "/";
      
      // Clean up trailing slash if present (except for root /)
      if (path.length > 1 && path.endsWith("/")) {
        path = path.substring(0, path.length - 1);
      }

      // Handle old hash routes gracefully for backward compatibility
      if (window.location.hash) {
        let hashPath = window.location.hash.substring(1);
        if (hashPath.startsWith("/")) {
          path = hashPath;
          window.history.replaceState(null, "", path);
        }
      }

      if (path === "/" || path === "") {
        setCurrentTab("home");
        setWatchType(null);
        setWatchId(null);
        setInitialSeason(undefined);
        setInitialEpisode(undefined);
      } else if (path === "/movie" || path === "/movies") {
        setCurrentTab("movies");
        setWatchType(null);
        setWatchId(null);
        setInitialSeason(undefined);
        setInitialEpisode(undefined);
        if (path === "/movies") {
          window.history.replaceState(null, "", "/movie");
        }
      } else if (path === "/series" || path === "/tv-shows" || path === "/tv") {
        setCurrentTab("tv");
        setWatchType(null);
        setWatchId(null);
        setInitialSeason(undefined);
        setInitialEpisode(undefined);
        if (path !== "/series") {
          window.history.replaceState(null, "", "/series");
        }
      } else if (path === "/anime") {
        setCurrentTab("anime");
        setWatchType(null);
        setWatchId(null);
        setInitialSeason(undefined);
        setInitialEpisode(undefined);
      } else if (path === "/telegram") {
        setCurrentTab("telegram");
        setWatchType(null);
        setWatchId(null);
        setInitialSeason(undefined);
        setInitialEpisode(undefined);
      } else if (["/about", "/privacy", "/terms", "/dmca", "/disclaimer"].includes(path)) {
        setCurrentTab(path.substring(1));
        setWatchType(null);
        setWatchId(null);
        setInitialSeason(undefined);
        setInitialEpisode(undefined);
      } else if (path.startsWith("/movie/")) {
        const id = path.split("/movie/")[1];
        if (id) {
          setWatchType("movie");
          setWatchId(id);
          setInitialSeason(undefined);
          setInitialEpisode(undefined);
          setCurrentTab("watch");
        }
      } else if (path.startsWith("/series/")) {
        // Format: /series/:id or /series/:id/:season/:episode
        const parts = path.split("/"); // ["", "series", "id", "season", "episode"]
        if (parts.length >= 5) {
          const id = parts[2];
          const season = parseInt(parts[3]);
          const episode = parseInt(parts[4]);
          setWatchType("tv");
          setWatchId(id);
          setInitialSeason(season);
          setInitialEpisode(episode);
          setCurrentTab("watch");
        } else {
          const id = parts[2];
          if (id) {
            setWatchType("tv");
            setWatchId(id);
            setInitialSeason(undefined);
            setInitialEpisode(undefined);
            setCurrentTab("watch");
          }
        }
      } else if (path.startsWith("/tv/")) {
        // Redirect old /tv/:id to /series/:id
        const id = path.split("/tv/")[1];
        if (id) {
          window.history.replaceState(null, "", `/series/${id}`);
          setWatchType("tv");
          setWatchId(id);
          setInitialSeason(undefined);
          setInitialEpisode(undefined);
          setCurrentTab("watch");
        }
      } else if (path.startsWith("/watch/tv/")) {
        // Format: /watch/tv/:id/:season/:episode -> /series/:id/:season/:episode
        const parts = path.split("/");
        if (parts.length >= 6) {
          const id = parts[3];
          const season = parts[4];
          const episode = parts[5];
          window.history.replaceState(null, "", `/series/${id}/${season}/${episode}`);
          setWatchType("tv");
          setWatchId(id);
          setInitialSeason(parseInt(season));
          setInitialEpisode(parseInt(episode));
          setCurrentTab("watch");
        }
      } else if (path.startsWith("/anime/")) {
        const id = path.split("/anime/")[1];
        if (id) {
          setWatchType("tv");
          setWatchId(id);
          setInitialSeason(undefined);
          setInitialEpisode(undefined);
          setCurrentTab("watch");
        }
      }
    };

    // Parse path on initial load
    syncRouteWithState();

    // Listen to pops from browser navigation history (e.g., back/forward buttons)
    window.addEventListener("popstate", syncRouteWithState);
    return () => {
      window.removeEventListener("popstate", syncRouteWithState);
    };
  }, []);

  // Dynamic SEO optimization for page titles and meta-descriptions
  useEffect(() => {
    if (currentTab === "watch") return; // Let WatchPage component handle its own dynamic SEO updates

    let titleText = "Star King OTT - Live TV, Movies, TV Shows & Anime Stream Hub";
    let descText = "Watch Live TV, latest Movies, full TV Shows, and trending Anime in HD quality on Star King OTT. Lag-free multi-server streaming with real-time updates.";

    switch (currentTab) {
      case "movies":
        titleText = "Watch HD Movies Online | Stream Latest Movie Releases - Star King OTT";
        descText = "Explore and watch your favorite Hollywood and international movies in full HD. Multiple fast streaming servers with zero delay.";
        break;
      case "tv":
        titleText = "Stream Full TV Series & Shows Online in HD | Star King OTT";
        descText = "Watch latest episodes and complete seasons of trending TV series and television shows. Direct high-speed video servers.";
        break;
      case "anime":
        titleText = "Watch Anime in HD Online | Free Anime Streaming - Star King OTT";
        descText = "Streaming a massive collection of subbed & dubbed anime series. Watch popular anime series in premium 1080p stream speed.";
        break;
      case "telegram":
        titleText = "Join Our Telegram Community for Live Updates | Star King OTT";
        descText = "Connect with the community, request content, and receive immediate support by joining the official Star King OTT Telegram channel.";
        break;
      case "about":
        titleText = "About Us | Learn More About Our Premium Index - Star King OTT";
        descText = "Learn about the high-performance media engine behind Star King OTT and how we deliver ultra-fast streaming indices.";
        break;
      case "privacy":
        titleText = "Privacy Policy - Star King OTT";
        descText = "Review how user privacy, localized cache structures, and data integrity are respected on our high-performance portal.";
        break;
      case "terms":
        titleText = "Terms of Service - Star King OTT";
        descText = "Understand the guidelines, rules of engagement, and usage policies for streaming via Star King OTT portal.";
        break;
      case "dmca":
        titleText = "DMCA Copyright Compliance Policy - Star King OTT";
        descText = "Learn about our strict copyright indexing policy and how we process verified dmca compliance notices.";
        break;
      case "disclaimer":
        titleText = "Copyright Disclaimer and Fair Use - Star King OTT";
        descText = "STAR KING OTT is an information index acting strictly as a wrapper for public media registries and API indices.";
        break;
      case "home":
      default:
        titleText = "Star King OTT - Live TV, Movies, TV Shows & Anime Stream Hub";
        descText = "Watch Live TV, latest Movies, full TV Shows, and trending Anime in HD quality on Star King OTT. Lag-free multi-server streaming with real-time updates.";
        break;
    }

    document.title = titleText;

    // Update Meta Tags
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) metaDesc.setAttribute("content", descText);

    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) ogTitle.setAttribute("content", titleText);

    const ogDesc = document.querySelector('meta[property="og:description"]');
    if (ogDesc) ogDesc.setAttribute("content", descText);

    const ogUrl = document.querySelector('meta[property="og:url"]');
    if (ogUrl) ogUrl.setAttribute("content", window.location.href);

    const twitterTitle = document.querySelector('meta[name="twitter:title"]');
    if (twitterTitle) twitterTitle.setAttribute("content", titleText);

    const twitterDesc = document.querySelector('meta[name="twitter:description"]');
    if (twitterDesc) twitterDesc.setAttribute("content", descText);

    // Reset poster to default television icon if we navigate away from a watch page
    const ogImg = document.querySelector('meta[property="og:image"]');
    if (ogImg) ogImg.setAttribute("content", "https://img.icons8.com/color/192/television.png");
    const twitterImg = document.querySelector('meta[name="twitter:image"]');
    if (twitterImg) twitterImg.setAttribute("content", "https://img.icons8.com/color/192/television.png");
  }, [currentTab]);

  const handleTabChange = (tab: string) => {
    setCurrentTab(tab);
    setWatchType(null);
    setWatchId(null);
    
    let path = "/";
    if (tab === "movies") path = "/movie";
    else if (tab === "tv") path = "/series";
    else if (tab === "anime") path = "/anime";
    else if (tab === "telegram") path = "/telegram";
    else if (["about", "privacy", "terms", "dmca", "disclaimer"].includes(tab)) path = `/${tab}`;
    
    window.history.pushState(null, "", path);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleSelectContent = (type: "movie" | "tv", id: string, _title?: string) => {
    setBackTab(currentTab);
    setWatchType(type);
    setWatchId(id);
    setCurrentTab("watch");
    
    const path = type === "movie" ? `/movie/${id}` : `/series/${id}`;
    window.history.pushState(null, "", path);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleBackToCatalog = () => {
    setCurrentTab(backTab);
    setWatchType(null);
    setWatchId(null);
    setInitialSeason(undefined);
    setInitialEpisode(undefined);
    
    let path = "/";
    if (backTab === "movies") path = "/movie";
    else if (backTab === "tv") path = "/series";
    else if (backTab === "anime") path = "/anime";
    else if (backTab === "telegram") path = "/telegram";
    else if (["about", "privacy", "terms", "dmca", "disclaimer"].includes(backTab)) path = `/${backTab}`;
    
    window.history.pushState(null, "", path);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleNavigateToContent = (type: "movie" | "tv", id: string, _title?: string) => {
    setWatchType(type);
    setWatchId(id);
    setInitialSeason(undefined);
    setInitialEpisode(undefined);
    
    const path = type === "movie" ? `/movie/${id}` : `/series/${id}`;
    window.history.pushState(null, "", path);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-[#030712] text-gray-100 flex flex-col justify-between">
      
      {!splashComplete && (
        <SplashScreen onComplete={() => setSplashComplete(true)} />
      )}

      {/* Premium Glassmorphic Header */}
      <Navbar 
        currentTab={currentTab === "watch" ? backTab : currentTab} 
        onTabChange={handleTabChange} 
        onSearchClick={() => setSearchOpen(true)}
      />

      {/* Main viewport area */}
      <main className="flex-1">
        {currentTab === "watch" && watchType && watchId ? (
          <WatchPage
            contentType={watchType}
            tmdbId={watchId}
            initialSeason={initialSeason}
            initialEpisode={initialEpisode}
            onBack={handleBackToCatalog}
            onNavigateToContent={handleNavigateToContent}
          />
        ) : currentTab === "home" ? (
          <HomeView onSelectContent={handleSelectContent} />
        ) : currentTab === "movies" ? (
          <BrowseView type="movie" onSelectContent={handleSelectContent} />
        ) : currentTab === "tv" ? (
          <BrowseView type="tv" onSelectContent={handleSelectContent} />
        ) : currentTab === "anime" ? (
          <AnimeView onSelectContent={handleSelectContent} />
        ) : currentTab === "telegram" ? (
          <TelegramView onBack={() => handleTabChange("home")} />
        ) : ["about", "privacy", "terms", "dmca", "disclaimer"].includes(currentTab) ? (
          <LegalDocs tab={currentTab} onBack={() => handleTabChange("home")} />
        ) : (
          <HomeView onSelectContent={handleSelectContent} />
        )}
      </main>

      {/* Search Overlay Panel */}
      {searchOpen && (
        <SearchModal 
          onClose={() => setSearchOpen(false)} 
          onSelectContent={handleSelectContent}
        />
      )}

      {/* Floating Scroll to Top button */}
      <AnimatePresence>
        {showScrollTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.7, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.7, y: 20 }}
            whileHover={{ scale: 1.1, translateY: -3 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="fixed bottom-6 right-6 z-50 p-3.5 rounded-2xl bg-gradient-to-br from-red-600 to-red-500 text-white shadow-xl shadow-red-600/20 border border-red-500/10 cursor-pointer flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-red-500/40"
            title="Scroll to Top"
            aria-label="Scroll to top"
          >
            <ArrowUp className="w-5 h-5 stroke-[2.5]" />
          </motion.button>
        )}
      </AnimatePresence>

      {/* Modern Footer with descriptive legal disclaimers */}
      <Footer onTabChange={handleTabChange} />

    </div>
  );
}
