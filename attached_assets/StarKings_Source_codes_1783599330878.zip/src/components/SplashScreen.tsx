import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Crown } from "lucide-react";

interface SplashScreenProps {
  onComplete: () => void;
}

export default function SplashScreen({ onComplete }: SplashScreenProps) {
  const [progress, setProgress] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    // Highly-optimized fast progress animation
    const startTime = Date.now();
    const duration = 600; // Perfect snappy loading speed

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const pct = Math.min((elapsed / duration) * 100, 100);
      setProgress(pct);

      if (pct >= 100) {
        clearInterval(interval);
        const timeout = setTimeout(() => {
          setIsVisible(false);
          const callbackTimeout = setTimeout(onComplete, 300);
          return () => clearTimeout(callbackTimeout);
        }, 100);
        return () => clearTimeout(timeout);
      }
    }, 16);

    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          id="splash-screen-container"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3, ease: "easeInOut" }}
          className="fixed inset-0 z-[9999] bg-[#030712] flex flex-col items-center justify-center p-6 select-none overflow-hidden"
        >
          {/* Subtle Ambient Radial Glow */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[350px] h-[350px] bg-red-600/5 rounded-full blur-[100px] pointer-events-none"></div>

          <div className="relative flex flex-col items-center max-w-xs w-full text-center">
            {/* Elegant, Premium Icon Badge */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.4, ease: "easeOut" }}
              className="relative w-16 h-16 rounded-2xl bg-gradient-to-tr from-red-600 to-red-500 flex items-center justify-center shadow-2xl shadow-red-500/10 border border-white/5 mb-6 text-white"
            >
              <Crown className="w-8 h-8" />
            </motion.div>

            {/* Premium Typography Brand Name */}
            <motion.div
              initial={{ y: 8, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.1, duration: 0.4, ease: "easeOut" }}
              className="flex flex-col items-center"
            >
              <h1 className="font-display font-black text-2xl tracking-widest text-white">
                STAR <span className="bg-gradient-to-r from-red-500 to-amber-500 bg-clip-text text-transparent">KING</span>
              </h1>
              <span className="text-[9px] font-mono tracking-[0.4em] text-gray-500 uppercase mt-2.5">
                PREMIUM OTT STREAM
              </span>
            </motion.div>

            {/* Minimalist Progress Meter */}
            <div className="mt-8 w-full px-8">
              <div className="h-0.5 w-full bg-white/5 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-red-600 to-red-500 transition-all duration-[16ms] ease-out"
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
