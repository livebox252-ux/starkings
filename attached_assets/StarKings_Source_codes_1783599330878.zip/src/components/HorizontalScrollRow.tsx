import { useRef, useState, useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { TMDBContent } from "../types";
import ContentCard from "./ContentCard";

interface HorizontalScrollRowProps {
  title: string;
  icon?: React.ReactNode;
  items: TMDBContent[];
  onSelect: (type: "movie" | "tv", id: string, title?: string) => void;
}

export default function HorizontalScrollRow({ title, icon, items, onSelect }: HorizontalScrollRowProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [showLeftArrow, setShowLeftArrow] = useState(false);
  const [showRightArrow, setShowRightArrow] = useState(true);

  // Check scroll position to dynamically toggle glass pagination arrows
  const checkScroll = () => {
    if (scrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
      setShowLeftArrow(scrollLeft > 5);
      setShowRightArrow(scrollLeft < scrollWidth - clientWidth - 5);
    }
  };

  useEffect(() => {
    const el = scrollRef.current;
    if (el) {
      el.addEventListener("scroll", checkScroll);
      // Run once initially
      checkScroll();
      // Handle resize
      window.addEventListener("resize", checkScroll);
    }
    return () => {
      if (el) el.removeEventListener("scroll", checkScroll);
      window.removeEventListener("resize", checkScroll);
    };
  }, [items]);

  const handleScroll = (direction: "left" | "right") => {
    if (scrollRef.current) {
      const { clientWidth } = scrollRef.current;
      const scrollAmount = direction === "left" ? -clientWidth * 0.75 : clientWidth * 0.75;
      scrollRef.current.scrollBy({ left: scrollAmount, behavior: "smooth" });
    }
  };

  if (!items || items.length === 0) return null;

  return (
    <div className="flex flex-col gap-4 relative group/row">
      <div className="flex items-center justify-between px-1">
        <h2 className="font-display font-bold text-xl md:text-2xl text-white flex items-center gap-2.5 tracking-tight">
          {icon}
          <span>{title}</span>
        </h2>
      </div>

      {/* Row Scrolling container */}
      <div className="relative w-full">
        {/* Left Arrow Button */}
        {showLeftArrow && (
          <button
            onClick={() => handleScroll("left")}
            className="absolute left-0 top-[40%] -translate-y-1/2 z-30 w-11 h-11 rounded-full bg-black/60 hover:bg-red-600/90 border border-white/10 flex items-center justify-center text-white backdrop-blur-md opacity-0 group-hover/row:opacity-100 transition-all duration-300 shadow-xl hover:scale-105 cursor-pointer -ml-4"
            aria-label="Scroll left"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
        )}

        {/* Right Arrow Button */}
        {showRightArrow && (
          <button
            onClick={() => handleScroll("right")}
            className="absolute right-0 top-[40%] -translate-y-1/2 z-30 w-11 h-11 rounded-full bg-black/60 hover:bg-red-600/90 border border-white/10 flex items-center justify-center text-white backdrop-blur-md opacity-0 group-hover/row:opacity-100 transition-all duration-300 shadow-xl hover:scale-105 cursor-pointer -mr-4"
            aria-label="Scroll right"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        )}

        {/* Content list */}
        <div
          ref={scrollRef}
          className="flex gap-5 overflow-x-auto overflow-y-hidden pb-4 pt-1 px-1 scroll-smooth no-scrollbar select-none snap-x snap-mandatory"
          style={{ WebkitOverflowScrolling: "touch" }}
        >
          {items.map((item) => {
            const isMovie = "title" in item;
            const contentTitle = isMovie ? (item as any).title : (item as any).name;
            return (
              <div 
                key={item.id} 
                className="w-36 sm:w-44 md:w-52 flex-shrink-0 snap-start"
              >
                <ContentCard
                  item={item}
                  onClick={() => onSelect(isMovie ? "movie" : "tv", String(item.id), contentTitle)}
                />
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
