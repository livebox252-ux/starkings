import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Play, Flame, ChevronLeft, ChevronRight } from "lucide-react";
import { TMDBContent } from "../types";

interface ThreeDCarouselProps {
  items: TMDBContent[];
  onSelect: (type: "movie" | "tv", id: string, title?: string) => void;
}

export default function ThreeDCarousel({ items, onSelect }: ThreeDCarouselProps) {
  const carouselItems = items.slice(0, 5); // Use 5 items for a beautiful odd-numbered setup
  const [activeIndex, setActiveIndex] = useState(2);
  const [isDragging, setIsDragging] = useState(false);
  const dragStartX = useRef(0);
  const autoPlayTimer = useRef<NodeJS.Timeout | null>(null);

  const total = carouselItems.length;

  const nextSlide = () => {
    setActiveIndex((prev) => (prev + 1) % total);
  };

  const prevSlide = () => {
    setActiveIndex((prev) => (prev - 1 + total) % total);
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft") prevSlide();
      else if (e.key === "ArrowRight") nextSlide();
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [total]);

  // Autoplay functionality - slide every 5 seconds
  const startAutoplay = () => {
    stopAutoplay();
    autoPlayTimer.current = setInterval(() => {
      nextSlide();
    }, 5000);
  };

  const stopAutoplay = () => {
    if (autoPlayTimer.current) {
      clearInterval(autoPlayTimer.current);
    }
  };

  useEffect(() => {
    if (total > 0) {
      startAutoplay();
    }
    return () => stopAutoplay();
  }, [total, activeIndex]);

  // Touch & Mouse swipe gestures
  const handleDragStart = (e: React.MouseEvent | React.TouchEvent) => {
    setIsDragging(true);
    dragStartX.current = "touches" in e ? e.touches[0].clientX : e.clientX;
  };

  const handleDragEnd = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDragging) return;
    setIsDragging(false);
    const endX = "changedTouches" in e ? e.changedTouches[0].clientX : e.clientX;
    const diff = dragStartX.current - endX;

    if (diff > 50) {
      nextSlide(); // swipe left -> next
    } else if (diff < -50) {
      prevSlide(); // swipe right -> prev
    }
  };

  if (total === 0) return null;

  return (
    <div className="flex flex-col gap-6 relative py-6 select-none group/carousel overflow-hidden">
      
      {/* Title block */}
      <div className="flex items-center justify-between px-1 max-w-7xl mx-auto w-full px-4 md:px-8">
        <h2 className="font-display font-black text-xl md:text-2xl text-white flex items-center gap-2.5 tracking-tight uppercase">
          <Flame className="w-5 h-5 text-red-500 fill-red-500 animate-pulse" />
          <span>Trending Today</span>
        </h2>
      </div>

      {/* 3D Stage Area */}
      <div 
        className="relative w-full h-[320px] sm:h-[380px] md:h-[450px] flex items-center justify-center overflow-visible px-4"
        style={{ perspective: "1200px" }}
        onMouseDown={handleDragStart}
        onMouseUp={handleDragEnd}
        onTouchStart={handleDragStart}
        onTouchEnd={handleDragEnd}
      >
        {/* Navigation Overlays */}
        <button
          onClick={(e) => { e.stopPropagation(); prevSlide(); }}
          className="absolute left-4 md:left-12 z-40 w-12 h-12 rounded-full bg-black/60 hover:bg-red-600/90 border border-white/10 flex items-center justify-center text-white backdrop-blur-md opacity-0 group-hover/carousel:opacity-100 transition-all duration-300 shadow-xl hover:scale-105 cursor-pointer"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>

        <button
          onClick={(e) => { e.stopPropagation(); nextSlide(); }}
          className="absolute right-4 md:right-12 z-40 w-12 h-12 rounded-full bg-black/60 hover:bg-red-600/90 border border-white/10 flex items-center justify-center text-white backdrop-blur-md opacity-0 group-hover/carousel:opacity-100 transition-all duration-300 shadow-xl hover:scale-105 cursor-pointer"
        >
          <ChevronRight className="w-6 h-6" />
        </button>

        {/* Carousel Render List */}
        {carouselItems.map((item, index) => {
          const isMovie = "title" in item;
          const contentTitle = isMovie ? (item as any).title : (item as any).name;
          const backdrop = item.backdrop_path 
            ? `https://image.tmdb.org/t/p/w500${item.poster_path}`
            : "https://images.unsplash.com/photo-1594909122845-11baa439b7bf?auto=format&fit=crop&q=80&w=400";

          // Calculate wrapped difference
          let offset = index - activeIndex;
          if (offset < -total / 2) offset += total;
          if (offset > total / 2) offset -= total;

          const absOffset = Math.abs(offset);
          const isActive = offset === 0;

          // Responsive calculation
          const isMobile = typeof window !== "undefined" && window.innerWidth < 640;
          const translateAmt = isMobile ? 100 : 250;

          const translateX = offset * translateAmt;
          const scale = isActive ? 1.05 : absOffset === 1 ? 0.82 : 0.65;
          const rotateY = offset * -15; // rotate sides slightly inwards
          const zIndex = 30 - absOffset;
          const opacity = absOffset === 0 ? 1 : absOffset === 1 ? 0.7 : 0.3;

          return (
            <motion.div
              key={item.id}
              className="absolute w-[180px] sm:w-[220px] md:w-[270px] aspect-[2/3] rounded-3xl overflow-hidden shadow-2xl border cursor-pointer group/card"
              style={{
                transformStyle: "preserve-3d",
                zIndex,
              }}
              animate={{
                x: translateX,
                scale,
                rotateY,
                opacity,
              }}
              transition={{
                type: "spring",
                stiffness: 260,
                damping: 24,
              }}
              onClick={() => {
                if (isActive) {
                  onSelect(isMovie ? "movie" : "tv", String(item.id), contentTitle);
                } else {
                  setActiveIndex(index);
                }
              }}
            >
              {/* Card Surface Frame */}
              <div className="relative w-full h-full bg-gray-950">
                <img
                  src={backdrop}
                  alt={contentTitle}
                  loading="lazy"
                  className="w-full h-full object-cover rounded-3xl filter brightness-[0.85] group-hover/card:brightness-100 transition-all duration-500"
                />

                {/* Ambient glow underneath active */}
                {isActive && (
                  <div className="absolute inset-[-10px] bg-red-600/25 blur-xl -z-10 animate-pulse rounded-full" />
                )}

                {/* Overlaid Title on Hover/Active */}
                <div className={`absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent flex flex-col justify-end p-5 transition-opacity duration-300 ${isActive ? "opacity-100" : "opacity-0 group-hover/card:opacity-100"}`}>
                  <span className="text-[10px] tracking-widest font-mono font-black text-red-500 mb-1 uppercase">
                    {isMovie ? "MOVIE" : "SERIES"}
                  </span>
                  <h3 className="text-white font-display font-black text-sm sm:text-base leading-tight line-clamp-1 drop-shadow-md">
                    {contentTitle}
                  </h3>
                  <div className="flex items-center gap-2 mt-2">
                    <span className="px-2 py-0.5 rounded text-[9px] bg-white/10 font-bold text-gray-300">
                      {item.vote_average ? item.vote_average.toFixed(1) : "0.0"} Rating
                    </span>
                    <span className="text-white bg-red-600 p-1.5 rounded-full shadow-lg flex items-center justify-center transform scale-90 group-hover/card:scale-100 transition-transform">
                      <Play className="w-3.5 h-3.5 fill-white" />
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Bullet Dots */}
      <div className="flex items-center justify-center gap-2 mt-4 z-20">
        {carouselItems.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setActiveIndex(idx)}
            className={`transition-all duration-300 rounded-full h-1.5 ${idx === activeIndex ? "w-6 bg-red-500" : "w-1.5 bg-white/20 hover:bg-white/40"}`}
          />
        ))}
      </div>
    </div>
  );
}
