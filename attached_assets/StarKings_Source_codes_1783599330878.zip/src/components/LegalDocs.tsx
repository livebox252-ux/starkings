import { useState } from "react";
import { Shield, BookOpen, AlertOctagon, HelpCircle, ArrowLeft, Mail, Globe, Sparkles, Scale } from "lucide-react";

interface LegalDocsProps {
  tab: string;
  onBack: () => void;
}

export default function LegalDocs({ tab: initialTab, onBack }: LegalDocsProps) {
  const [activeTab, setActiveTab] = useState<string>(initialTab);

  const tabs = [
    { id: "privacy", label: "Privacy Policy", icon: Shield },
    { id: "terms", label: "Terms & Conditions", icon: BookOpen },
    { id: "dmca", label: "DMCA Policy", icon: AlertOctagon },
    { id: "disclaimer", label: "Disclaimer", icon: HelpCircle },
  ];

  return (
    <div className="min-h-screen text-gray-100 pt-28 pb-20 px-4 md:px-8 max-w-7xl mx-auto">
      
      {/* Top Breadcrumb & Go Back Button */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-10 border-b border-white/5 pb-6">
        <div>
          <button 
            onClick={onBack}
            className="group flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 text-gray-300 hover:text-white transition-all duration-300 cursor-pointer mb-3"
          >
            <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
            <span className="text-xs font-semibold">Back to Home</span>
          </button>
          <h1 className="font-display font-black text-2xl md:text-3xl text-white tracking-tight">
            Compliance & Documentation
          </h1>
        </div>
        <div className="text-right">
          <p className="text-xs text-gray-500 font-mono">STAR KING LEGAL PORTAL</p>
          <p className="text-[10px] text-red-500 font-mono mt-0.5">Version 3.0 (Updated July 2026)</p>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-8 items-start">
        
        {/* Left sidebar nav */}
        <div className="w-full lg:w-72 flex-shrink-0 flex flex-row lg:flex-col gap-2 overflow-x-auto pb-4 lg:pb-0 scrollbar-none border-b lg:border-b-0 lg:border-r border-white/5 pr-0 lg:pr-6">
          {tabs.map((tabItem) => {
            const Icon = tabItem.icon;
            const isActive = activeTab === tabItem.id;
            return (
              <button
                key={tabItem.id}
                onClick={() => setActiveTab(tabItem.id)}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
                  isActive 
                    ? "bg-red-600 text-white shadow-lg shadow-red-600/20 font-bold" 
                    : "text-gray-400 hover:text-white hover:bg-white/5"
                }`}
              >
                <Icon className="w-4 h-4 flex-shrink-0" />
                <span>{tabItem.label}</span>
              </button>
            );
          })}
        </div>

        {/* Right pane: Document text */}
        <div className="flex-1 w-full">
          
          {/* PRIVACY POLICY */}
          {activeTab === "privacy" && (
            <div className="glass-panel p-6 md:p-10 rounded-3xl border border-white/5 flex flex-col gap-6 bg-gray-900/10 leading-relaxed text-sm text-gray-300">
              <div className="flex items-center gap-4 border-b border-white/5 pb-5">
                <div className="w-12 h-12 rounded-xl bg-red-600/10 flex items-center justify-center border border-red-500/20 text-red-500">
                  <Shield className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="font-display font-black text-xl md:text-2xl text-white">Privacy Policy</h2>
                  <p className="text-xs text-gray-500 mt-1">Information processing and telemetry protection guidelines</p>
                </div>
              </div>

              <div className="flex flex-col gap-4">
                <h3 className="font-display font-bold text-white text-base mt-2">1. Introduction</h3>
                <p>
                  Welcome to STAR KING. We respect your privacy and are committed to protecting any minimal information we handle. 
                  This Privacy Policy outlines how we manage technical details to offer you a fast, stable, and seamless streaming experience. 
                  <b> STAR KING does not sell, trade, or rent user information to any third party under any circumstances.</b>
                </p>

                <h3 className="font-display font-bold text-white text-base mt-2">2. Information We Collect</h3>
                <p>
                  Because we require no email signups, passwords, physical addresses, or subscription credit cards, we do not compile databases of user identities. 
                  To optimize performance, we may temporarily analyze minimal technical indicators:
                </p>
                <ul className="list-disc pl-5 flex flex-col gap-2 text-xs text-gray-400">
                  <li><b>Local Storage Cache:</b> User preferences, search logs, and saved bookmarks are written exclusively within your own browser's <code className="text-red-400 font-mono bg-white/5 px-1 py-0.5 rounded">localStorage</code>. This data never leaves your client device.</li>
                  <li><b>Connection Telemetry:</b> Technical characteristics like your screen width, web framework loading speeds, and server latency are parsed momentarily in memory to ensure fluid interface transitions.</li>
                </ul>

                <h3 className="font-display font-bold text-white text-base mt-2">3. Cookies & Local Storage</h3>
                <p>
                  STAR KING does not use tracking cookies to build marketing dossiers or deliver targeted advertising. 
                  We utilize HTML5 Local Storage primarily to persist your application choices, such as recently watched titles or mirror server preferences. 
                  You can purge this local data anytime via your browser's setting menu.
                </p>

                <h3 className="font-display font-bold text-white text-base mt-2">4. Performance Analytics</h3>
                <p>
                  Any standard analytics models we may employ are focused on analyzing aggregated visitor numbers and framework response limits, ensuring no personal tracking occurs. 
                  These technical statistics help us detect bottlenecks and optimize visual performance across both mobile and desktop viewers.
                </p>

                <h3 className="font-display font-bold text-white text-base mt-2">5. Third-Party Services</h3>
                <p>
                  Since STAR KING acts as a media wrapper and directory, we integrate external APIs and media pipelines. 
                  These external entities operate under their own autonomous privacy policies:
                </p>
                <ul className="list-disc pl-5 flex flex-col gap-2 text-xs text-gray-400">
                  <li><b>The Movie Database (TMDB) API:</b> For movie banners, synopsis metadata, crew files, and trending list records.</li>
                  <li><b>External Streaming Providers & Mirrors:</b> Handled securely on the client side. No personal streaming telemetry is stored on our end.</li>
                  <li><b>Live TV Sources:</b> Dynamically rendered client-side stream wrappers for publicly available broadcasting networks.</li>
                </ul>

                <h3 className="font-display font-bold text-white text-base mt-2">6. TMDB API Usage</h3>
                <p>
                  All visual posters, rating numbers, and summary details shown are dynamically requested using TMDB's public APIs. 
                  These requests are processed in compliance with the public database's terms of service, ensuring no unique user-identifying telemetry is submitted to TMDB systems.
                </p>

                <h3 className="font-display font-bold text-white text-base mt-2">7. Security</h3>
                <p>
                  We implement robust industry standard security configurations, including full HTTPS end-to-end encryption for all API proxy calls. 
                  This secures your search inputs and prevents middleman interception of your browsing sessions.
                </p>

                <h3 className="font-display font-bold text-white text-base mt-2">8. Children's Privacy</h3>
                <p>
                  Our system does not collect or request identifying metrics from anyone, including children under 13. 
                  Parents can manage browser history controls to regulate their children's access to media content catalogs.
                </p>

                <h3 className="font-display font-bold text-white text-base mt-2">9. User Rights</h3>
                <p>
                  As a user, you possess absolute sovereignty over your metadata. You have the right to clear your search records, saved items, and system cache at any moment. 
                  Since we store no server-side registries of your details, you hold all administrative access locally in your own hands.
                </p>

                <h3 className="font-display font-bold text-white text-base mt-2">10. Data Retention</h3>
                <p>
                  Because search entries are ephemeral, we do not archive history logs. 
                  Any cached assets inside your browser persist until you manually purge them or your operating system cleans up disk space automatically.
                </p>

                <h3 className="font-display font-bold text-white text-base mt-2">11. Changes to this Policy</h3>
                <p>
                  We reserve the right to revise this Privacy Policy to align with new security standards or platform features. 
                  Any updates will be immediately noted on this page with an updated modification timestamp.
                </p>

                <h3 className="font-display font-bold text-white text-base mt-2">12. Contact Information</h3>
                <p>
                  For physical privacy inquiries or general metadata compliance concerns, you can contact us via our official channel:
                </p>
                <div className="flex items-center gap-3 p-4 rounded-xl bg-white/5 border border-white/5 mt-2">
                  <Mail className="w-5 h-5 text-red-500" />
                  <span className="text-sm">Support Hub: </span>
                  <a href="https://t.me/starskings" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">@starskings</a>
                </div>
              </div>
            </div>
          )}

          {/* TERMS & CONDITIONS */}
          {activeTab === "terms" && (
            <div className="glass-panel p-6 md:p-10 rounded-3xl border border-white/5 flex flex-col gap-6 bg-gray-900/10 leading-relaxed text-sm text-gray-300">
              <div className="flex items-center gap-4 border-b border-white/5 pb-5">
                <div className="w-12 h-12 rounded-xl bg-red-600/10 flex items-center justify-center border border-red-500/20 text-red-500">
                  <BookOpen className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="font-display font-black text-xl md:text-2xl text-white">Terms & Conditions</h2>
                  <p className="text-xs text-gray-500 mt-1">Platform rules of service and compliance guidelines</p>
                </div>
              </div>

              <div className="flex flex-col gap-4">
                <h3 className="font-display font-bold text-white text-base mt-2">1. Acceptance of Terms</h3>
                <p>
                  By accessing, browsing, or interacting with STAR KING, you confirm your absolute acceptance of these Terms & Conditions. 
                  If you disagree with any section of this framework, please terminate your session immediately.
                </p>

                <h3 className="font-display font-bold text-white text-base mt-2">2. Website Usage & Content Disclaimer</h3>
                <p>
                  STAR KING provides an intellectual web frontend overlay that catalogues entertainment files, movies, series, and anime. 
                  <b> STAR KING does not host, upload, or store any copyrighted videos, digital streams, or multimedia recordings on our own servers.</b> 
                  All streaming material and media displays are referenced from publicly accessible external indexing databases and third-party media mirrors.
                </p>

                <h3 className="font-display font-bold text-white text-base mt-2">3. User Responsibilities & Local Jurisdictions</h3>
                <p>
                  As an end user, you bear sole responsibility for complying with your local regional regulations, copyright frameworks, and streaming jurisdictions. 
                  STAR KING only handles system-level metadata and does not endorse the illegal access or distribution of digital media assets.
                </p>

                <h3 className="font-display font-bold text-white text-base mt-2">4. Intellectual Property</h3>
                <p>
                  The logo marks, custom code, graphic layouts, and technical stylesheets of STAR KING belong exclusively to our software team. 
                  All third-party posters, artwork, synopses, title assets, and trademarked designations belong to their respective copyright owners.
                </p>

                <h3 className="font-display font-bold text-white text-base mt-2">5. External Streaming Providers & Live TV Sources</h3>
                <p>
                  Our server does not govern the video quality, language translations, or server speeds of third-party streaming sources or Live TV links. 
                  Streaming availability and player performance depend entirely on independent hosting networks, which may modify or remove links without warning.
                </p>

                <h3 className="font-display font-bold text-white text-base mt-2">6. Limitation of Liability</h3>
                <p>
                  To the maximum extent permitted by applicable laws, STAR KING, its maintainers, and community administrators shall not be held liable for any damages, playback disruptions, or loss of device storage resulting from the use of this interface or external players.
                </p>

                <h3 className="font-display font-bold text-white text-base mt-2">7. System Availability & Service Suspension</h3>
                <p>
                  We aim to provide a stable web interface. However, we cannot guarantee uninterrupted server uptime. 
                  We reserve the right to suspend or restrict access to our interface for critical maintenance, layout redesigns, or security patches without prior notification.
                </p>

                <h3 className="font-display font-bold text-white text-base mt-2">8. Modifications</h3>
                <p>
                  We reserve the right to modify these Terms & Conditions at our discretion. 
                  Your continued use of the platform after updates are made constitutes a binded acceptance of the modified Terms.
                </p>

                <h3 className="font-display font-bold text-white text-base mt-2">9. Governing Law</h3>
                <p>
                  These terms are governed by standard internet compliance frameworks. 
                  Any disputes arising from these guidelines shall be managed constructively via community negotiations.
                </p>

                <h3 className="font-display font-bold text-white text-base mt-2">10. Contact</h3>
                <p>
                  For clarification regarding these Terms of Service, please reach out to our community center:
                </p>
                <div className="flex items-center gap-3 p-4 rounded-xl bg-white/5 border border-white/5 mt-2">
                  <Globe className="w-5 h-5 text-red-500" />
                  <span className="text-sm">Official Community: </span>
                  <a href="https://t.me/starskings" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">t.me/starskings</a>
                </div>
              </div>
            </div>
          )}

          {/* DMCA POLICY */}
          {activeTab === "dmca" && (
            <div className="glass-panel p-6 md:p-10 rounded-3xl border border-white/5 flex flex-col gap-6 bg-gray-900/10 leading-relaxed text-sm text-gray-300">
              <div className="flex items-center gap-4 border-b border-white/5 pb-5">
                <div className="w-12 h-12 rounded-xl bg-red-600/10 flex items-center justify-center border border-red-500/20 text-red-500">
                  <AlertOctagon className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="font-display font-black text-xl md:text-2xl text-white">DMCA Copyright Policy</h2>
                  <p className="text-xs text-gray-500 mt-1">Digital Millennium Copyright Act compliance and claims procedure</p>
                </div>
              </div>

              <div className="flex flex-col gap-4">
                <h3 className="font-display font-bold text-white text-base mt-2">1. Respect of Intellectual Property</h3>
                <p>
                  STAR KING takes copyright issues very seriously. We respects the intellectual property rights of creators, producers, and distribution studios worldwide. 
                  <b> We must state explicitly: STAR KING does not host, upload, clone, or store copyrighted videos, digital streams, or media files on our own infrastructure.</b>
                </p>
                <p>
                  Our client-side platform solely indexes movie meta-listings from TMDB and references external, public-use streaming resources that are already publicly available on the internet.
                </p>

                <h3 className="font-display font-bold text-white text-base mt-2">2. Notice and Takedown Procedure</h3>
                <p>
                  Since we do not store copyrighted video records on our databases, we cannot remove content from external video hosting portals. 
                  However, if you are a copyright owner and want to request the removal of a specific catalog link inside our frontend, you can submit a formal notification. 
                  The request must include:
                </p>
                <ul className="list-decimal pl-5 flex flex-col gap-2 text-xs text-gray-400">
                  <li>A physical or electronic signature of a person authorized to act on behalf of the owner of the copyright.</li>
                  <li>Identification of the copyrighted work claimed to have been infringed.</li>
                  <li>Identification of the specific link or search index item on STAR KING that you want removed, with exact details to locate it.</li>
                  <li>Your physical address, telephone number, and email address.</li>
                  <li>A statement that you have a good faith belief that the use of the material is not authorized by the copyright owner.</li>
                  <li>A statement that the information in the notification is accurate, and under penalty of perjury, that you are authorized to act on behalf of the owner.</li>
                </ul>

                <h3 className="font-display font-bold text-white text-base mt-2">3. Submission Channel & Response Time</h3>
                <p>
                  All valid DMCA notices must be submitted directly to our compliance managers. 
                  We respond to structured takedown claims within 24 to 72 business hours.
                </p>
                <div className="flex items-center gap-3 p-4 rounded-xl bg-white/5 border border-white/5 mt-2">
                  <Scale className="w-5 h-5 text-red-500" />
                  <span className="text-sm">Compliance Desk: </span>
                  <a href="https://t.me/starskings" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline">DMCA Portal via Telegram</a>
                </div>

                <h3 className="font-display font-bold text-white text-base mt-2">4. Counter Notification</h3>
                <p>
                  If an index item has been removed because of a mistaken copyright claim, you can submit a counter-notice containing your identity, 
                  reasons for the claim error, and your signature. Upon receiving a valid counter-notice, our team may restore the link.
                </p>

                <h3 className="font-display font-bold text-white text-base mt-2">5. Repeat Infringement Policy</h3>
                <p>
                  As an information directory, we continuously filter our index inputs. 
                  If we detect that an external source consistently provides invalid or broken feeds, we will permanently block that source from our catalog queries.
                </p>
              </div>
            </div>
          )}

          {/* DISCLAIMER */}
          {activeTab === "disclaimer" && (
            <div className="glass-panel p-6 md:p-10 rounded-3xl border border-white/5 flex flex-col gap-6 bg-gray-900/10 leading-relaxed text-sm text-gray-300">
              <div className="flex items-center gap-4 border-b border-white/5 pb-5">
                <div className="w-12 h-12 rounded-xl bg-red-600/10 flex items-center justify-center border border-red-500/20 text-red-500">
                  <HelpCircle className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="font-display font-black text-xl md:text-2xl text-white">Disclaimer</h2>
                  <p className="text-xs text-gray-500 mt-1">Official platform limitations and content declarations</p>
                </div>
              </div>

              <div className="flex flex-col gap-4">
                <p className="font-display font-bold text-white text-base">
                  STAR KING is exclusively an entertainment information platform.
                </p>
                <p className="border-l-4 border-red-500 pl-4 py-1.5 text-xs text-gray-400 bg-red-500/5 my-2">
                  <b>IMPORTANT COMPLIANCE STATEMENT:</b> We do NOT host, store, stream, or redistribute any media files, movies, TV shows, anime episodes, live TV streams, video records, or stream scripts on our servers.
                </p>
                
                <h3 className="font-display font-bold text-white text-sm mt-3">Content Ownership</h3>
                <p>
                  All copyrights, trade marks, brand labels, and media titles showcased on STAR KING belong strictly to their respective owners. 
                  STAR KING does not assert any proprietary rights over original movies, broadcasting brands, or character assets.
                </p>

                <h3 className="font-display font-bold text-white text-sm mt-3">TMDB Information Usage</h3>
                <p>
                  Movie metadata, ratings, cast summaries, trending charts, and high-quality poster illustrations are pulled dynamically using TMDB APIs. 
                  STAR KING operates as an analytical frontend client to display this information beautifully. We are not endorsed or sponsored by TMDB.
                </p>

                <h3 className="font-display font-bold text-white text-sm mt-3">External Streaming Providers & Live TV Linkage</h3>
                <p>
                  The streaming mirrors, video player options, and Live TV channels are publicly available third-party services. 
                  STAR KING holds zero control over the speed, safety, uptime, language, or content of these external sites. 
                  If a stream goes offline, we recommend trying a different server or direct mirror.
                </p>

                <h3 className="font-display font-bold text-white text-sm mt-3">No Warranties</h3>
                <p>
                  All materials and catalog indexes are presented "as is" with no technical guarantees of any kind. 
                  We reserve the right to alter server indexes and visual capabilities without notice, keeping our ecosystem lightweight and agile.
                </p>
              </div>
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
