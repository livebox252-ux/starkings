import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Play, 
  Tv, 
  Film, 
  Sparkles, 
  Radio, 
  Search, 
  Send, 
  X,
  Menu,
  ChevronRight
} from "lucide-react";

export interface NavbarProps {
  currentTab: string;
  onTabChange: (tab: string) => void;
  onSearchClick: () => void;
}

export default function Navbar({ currentTab, onTabChange, onSearchClick }: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { id: "home", label: "Home", icon: Play },
    { id: "movies", label: "Movies", icon: Film },
    { id: "tv", label: "TV Shows", icon: Tv },
    { id: "anime", label: "Anime", icon: Sparkles },
    { id: "telegram", label: "Telegram", icon: Send },
  ];

  return (
    <>
      <nav 
        className={`fixed top-0 left-0 right-0 z-40 px-4 md:px-8 transition-all duration-300 flex items-center justify-between ${
          scrolled 
            ? "py-2.5 bg-gray-950/95 shadow-xl border-b border-white/10 backdrop-blur-2xl" 
            : "py-4 bg-[#030712]/45 backdrop-blur-md border-b border-transparent"
        }`}
        style={{
          transform: "translate3d(0, 0, 0)",
          WebkitTransform: "translate3d(0, 0, 0)",
          willChange: "transform, padding, background-color"
        }}
      >
        {/* Brand Logo - Premium SVG Emblem */}
        <div 
          className="flex items-center gap-3 cursor-pointer group"
          onClick={() => {
            onTabChange("home");
            window.scrollTo({ top: 0, behavior: "smooth" });
          }}
        >
          <div className="relative flex items-center justify-center">
            <svg 
              viewBox="0 0 100 100" 
              className="w-10 h-10 filter drop-shadow-[0_0_10px_rgba(239,68,68,0.4)] transform group-hover:scale-105 transition-transform duration-300"
              fill="none" 
              xmlns="http://www.w3.org/2000/svg"
            >
              <defs>
                <linearGradient id="logo-grad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#f59e0b" />
                  <stop offset="50%" stopColor="#e11d48" />
                  <stop offset="100%" stopColor="#be123c" />
                </linearGradient>
              </defs>
              <path 
                d="M50 12 L63 38 L92 40 L69 58 L77 86 L50 71 L23 86 L31 58 L8 40 L37 38 Z" 
                fill="url(#logo-grad)" 
              />
              <path 
                d="M50 32 L56 46 L71 46 L59 55 L63 69 L50 60 L37 69 L41 55 L29 46 L44 46 Z" 
                fill="#ffffff" 
                opacity="0.9"
              />
            </svg>
            <span className="absolute -bottom-0.5 -right-0.5 flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
            </span>
          </div>
          <div className="flex flex-col">
            <span className="font-display font-black text-lg tracking-wider leading-none text-white">
              STAR<span className="bg-gradient-to-r from-red-500 via-yellow-500 to-amber-500 bg-clip-text text-transparent text-glow">KING</span>
            </span>
            <span className="text-[8px] font-mono tracking-[0.3em] text-gray-400 font-bold uppercase leading-none mt-1">
              PREMIUM STREAM
            </span>
          </div>
        </div>

        {/* Inline Navigation - Desktop and Tablet */}
        <div className="hidden md:flex items-center gap-1 bg-white/[0.03] border border-white/5 rounded-full p-1 backdrop-blur-md">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onTabChange(item.id);
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
                className={`relative px-4 py-2 rounded-full text-xs font-bold tracking-wider uppercase flex items-center gap-2 transition-all duration-300 cursor-pointer ${
                  isActive 
                    ? "text-white" 
                    : "text-gray-400 hover:text-white"
                }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="active-nav-pill"
                    transition={{ type: "spring", stiffness: 380, damping: 30 }}
                    className="absolute inset-0 bg-red-600 rounded-full shadow-lg shadow-red-600/30 -z-10"
                  />
                )}
                <Icon className="w-3.5 h-3.5" />
                <span className="hidden lg:inline">{item.label}</span>
                <span className="lg:hidden">{item.label.split(" ")[0]}</span>
              </button>
            );
          })}
        </div>

        {/* Action Buttons - Search and Menu toggle for both desktop and mobile */}
        <div className="flex items-center gap-3">
          <button
            onClick={onSearchClick}
            aria-label="Search content"
            className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 text-gray-300 hover:text-white transition-all duration-300 cursor-pointer flex items-center justify-center"
          >
            <Search className="w-5 h-5" />
          </button>

          {/* Premium Burger menu toggle */}
          <button
            onClick={() => setMobileMenuOpen(true)}
            aria-label="Open navigation menu"
            className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 text-gray-300 hover:text-white transition-all duration-300 cursor-pointer flex items-center justify-center gap-2 group"
          >
            <span className="hidden md:inline text-xs font-semibold tracking-wider text-gray-400 group-hover:text-white transition-colors">MENU</span>
            <Menu className="w-5 h-5 group-hover:rotate-6 transition-transform duration-300" />
          </button>
        </div>
      </nav>

      {/* Premium Slide-in Sidebar Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <>
            {/* Backdrop Overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              onClick={() => setMobileMenuOpen(false)}
              className="fixed inset-0 bg-black/80 backdrop-blur-md z-50"
            />
            {/* Slide-out Sidebar Drawer */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 26, stiffness: 220 }}
              className="fixed top-0 right-0 bottom-0 w-80 md:w-96 bg-gray-950/95 border-l border-white/10 z-50 p-8 flex flex-col justify-between shadow-2xl backdrop-blur-xl"
            >
              <div>
                {/* Drawer Header */}
                <div className="flex items-center justify-between mb-10 border-b border-white/5 pb-6">
                  <div className="flex items-center gap-2">
                    <svg 
                      viewBox="0 0 100 100" 
                      className="w-8 h-8 filter drop-shadow-[0_0_8px_rgba(239,68,68,0.4)]"
                      fill="none" 
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path 
                        d="M50 12 L63 38 L92 40 L69 58 L77 86 L50 71 L23 86 L31 58 L8 40 L37 38 Z" 
                        fill="url(#logo-grad)" 
                      />
                    </svg>
                    <span className="font-display font-black text-base text-white tracking-widest uppercase">STAR<span className="text-red-500">KING</span></span>
                  </div>
                  <button
                    onClick={() => setMobileMenuOpen(false)}
                    className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 text-gray-300 hover:text-white transition-all duration-300 cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Navigation Items list */}
                <div className="flex flex-col gap-2">
                  {navItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = currentTab === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => {
                          onTabChange(item.id);
                          setMobileMenuOpen(false);
                        }}
                        className={`w-full px-5 py-4 rounded-xl text-left text-sm font-semibold flex items-center justify-between transition-all duration-300 cursor-pointer ${
                          isActive 
                            ? "bg-red-600 text-white shadow-lg shadow-red-600/30 font-bold" 
                            : "text-gray-400 hover:text-white hover:bg-white/5"
                        }`}
                      >
                        <div className="flex items-center gap-3.5">
                          <Icon className="w-5 h-5" />
                          <span>{item.label}</span>
                        </div>
                        <ChevronRight className={`w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity ${isActive ? 'opacity-100' : ''}`} />
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Drawer Footer info */}
              <div className="border-t border-white/5 pt-6 text-center">
                <p className="text-[10px] font-mono tracking-widest text-gray-500 uppercase">
                  STAR KING Premium
                </p>
                <p className="text-[9px] text-gray-600 mt-1">
                  Enjoy unlimited seamless streaming with direct mirrors
                </p>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
