import { useState, useEffect } from "react";
import { Film, Tv, Sparkles, SlidersHorizontal, ChevronLeft, ChevronRight, Info } from "lucide-react";
import { TMDBContent, Genre } from "../types";
import ContentCard from "./ContentCard";
import { SkeletonCard } from "./SkeletonCard";

interface BrowseViewProps {
  type: "movie" | "tv";
  onSelectContent: (type: "movie" | "tv", id: string, title?: string) => void;
}

export default function BrowseView({ type, onSelectContent }: BrowseViewProps) {
  const [items, setItems] = useState<TMDBContent[]>([]);
  const [genres, setGenres] = useState<Genre[]>([]);
  const [selectedGenre, setSelectedGenre] = useState<string>("");
  const [sortBy, setSortBy] = useState<string>("popularity.desc");
  const [page, setPage] = useState<number>(1);
  const [totalPages, setTotalPages] = useState<number>(1);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch Genres List
  useEffect(() => {
    async function loadGenres() {
      try {
        const res = await fetch("/api/tmdb/genres");
        if (res.ok) {
          const data = await res.json();
          setGenres(type === "movie" ? data.movie : data.tv);
        }
      } catch (err) {
        console.error("Failed to load genres list", err);
      }
    }
    loadGenres();
  }, [type]);

  // Fetch Dynamic discover results
  useEffect(() => {
    async function fetchDiscover() {
      try {
        setLoading(true);
        setError(null);

        const params = new URLSearchParams({
          type,
          sort_by: sortBy,
          page: String(page)
        });

        if (selectedGenre) {
          params.append("with_genres", selectedGenre);
        }

        const res = await fetch(`/api/tmdb/discover?${params.toString()}`);
        if (!res.ok) throw new Error("Catalog sync issue. Try refreshing page.");

        const data = await res.json();
        setItems(data.results || []);
        setTotalPages(Math.min(data.total_pages || 1, 100)); // cap at 100 pages to save TMDB load
      } catch (err: any) {
        setError(err.message || "An unexpected error occurred.");
      } finally {
        setLoading(false);
      }
    }
    
    fetchDiscover();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [type, selectedGenre, sortBy, page]);

  return (
    <div className="min-h-screen text-gray-100 pt-24 pb-16 px-4 md:px-8 max-w-7xl mx-auto flex flex-col gap-8">
      
      {/* Title Header */}
      <div>
        <h1 className="font-display font-bold text-3xl tracking-tight text-white flex items-center gap-2.5">
          {type === "movie" ? (
            <>
              <Film className="w-8 h-8 text-red-500 text-glow" />
              <span>Browse <span className="text-red-500 text-glow">Movies</span> Library</span>
            </>
          ) : (
            <>
              <Tv className="w-8 h-8 text-red-500 text-glow" />
              <span>Browse <span className="text-red-500 text-glow">TV Shows</span> Library</span>
            </>
          )}
        </h1>
        <p className="text-gray-400 text-sm mt-1">
          Explore top cinematic catalogs parsed live from TMDB directory lists. Add filters dynamically.
        </p>
      </div>

      {/* Discovery Filters Control Panel */}
      <div className="glass-panel p-5 rounded-2xl border border-white/5 flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Genre pills selector */}
        <div className="flex flex-wrap items-center gap-1.5 max-w-3xl">
          <button
            onClick={() => {
              setSelectedGenre("");
              setPage(1);
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
              !selectedGenre 
                ? "bg-red-500 text-white shadow-lg shadow-red-500/20" 
                : "bg-white/5 text-gray-400 hover:text-white hover:bg-white/10"
            }`}
          >
            All Genres
          </button>
          
          {genres.slice(0, 10).map((g) => (
            <button
              key={g.id}
              onClick={() => {
                setSelectedGenre(String(g.id));
                setPage(1);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                selectedGenre === String(g.id) 
                  ? "bg-red-500 text-white shadow-lg shadow-red-500/20" 
                  : "bg-white/5 text-gray-400 hover:text-white hover:bg-white/10"
              }`}
            >
              {g.name}
            </button>
          ))}
        </div>

        {/* Sort by selection */}
        <div className="flex items-center gap-2 w-full md:w-auto flex-shrink-0">
          <SlidersHorizontal className="w-4 h-4 text-red-500" />
          <select
            value={sortBy}
            onChange={(e) => {
              setSortBy(e.target.value);
              setPage(1);
            }}
            aria-label="Sort content options"
            className="w-full md:w-48 bg-gray-950 border border-white/5 hover:border-white/10 focus:border-red-500 rounded-xl px-3.5 py-2 text-xs text-gray-300 outline-none cursor-pointer transition-all"
          >
            <option value="popularity.desc">Popularity (High to Low)</option>
            <option value="vote_average.desc">Rating (High to Low)</option>
            <option value="primary_release_date.desc">Release Date (Newest)</option>
          </select>
        </div>

      </div>

      {/* Main Grid display area */}
      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
          {Array.from({ length: 12 }).map((_, i) => (
            <SkeletonCard key={i} />
          ))}
        </div>
      ) : error ? (
        <div className="text-center py-16 text-gray-400">
          <Info className="w-8 h-8 text-red-500 mx-auto mb-2" />
          <p>{error}</p>
        </div>
      ) : items.length === 0 ? (
        <div className="text-center py-16 text-gray-400">
          No matches found for active filters.
        </div>
      ) : (
        <div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
            {items.map((item) => (
              <ContentCard
                key={item.id}
                item={item}
                onClick={() => onSelectContent(type, String(item.id), (item as any).title || (item as any).name)}
              />
            ))}
          </div>

          {/* Simple virtual responsive pagination controller */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-4 mt-12 border-t border-white/5 pt-8">
              <button
                disabled={page === 1}
                onClick={() => setPage(page - 1)}
                className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 text-gray-300 hover:text-white transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              
              <span className="text-xs font-semibold text-gray-400">
                Page <span className="text-white">{page}</span> of <span className="text-white">{totalPages}</span>
              </span>

              <button
                disabled={page === totalPages}
                onClick={() => setPage(page + 1)}
                className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 text-gray-300 hover:text-white transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          )}
        </div>
      )}

    </div>
  );
}
