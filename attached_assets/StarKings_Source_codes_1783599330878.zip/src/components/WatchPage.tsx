import React, { useState, useEffect, useRef, ChangeEvent } from "react";
import { 
  Play, 
  Pause,
  Star, 
  Clock, 
  Server, 
  Layers, 
  Film, 
  ArrowLeft,
  Tv,
  ExternalLink,
  ChevronDown,
  Sparkles,
  Info,
  Globe,
  Languages,
  Calendar,
  DollarSign,
  Briefcase,
  Users,
  Image as ImageIcon,
  MessageSquare,
  Bookmark,
  ChevronLeft,
  ChevronRight,
  X,
  TrendingUp,
  Award,
  Video,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Tv2
} from "lucide-react";
import { providers, getProviderUrl } from "../config/providers";
import { ContentDetail, CastMember, Episode, TMDBContent } from "../types";
import { motion, AnimatePresence } from "motion/react";

interface WatchPageProps {
  contentType: "movie" | "tv";
  tmdbId: string;
  initialSeason?: number;
  initialEpisode?: number;
  onBack: () => void;
  onNavigateToContent: (type: "movie" | "tv", id: string, title?: string) => void;
}

export default function WatchPage({ 
  contentType, 
  tmdbId, 
  initialSeason, 
  initialEpisode, 
  onBack, 
  onNavigateToContent 
}: WatchPageProps) {
  const [details, setDetails] = useState<any | null>(null);
  const [cast, setCast] = useState<CastMember[]>([]);
  const [crew, setCrew] = useState<any[]>([]);
  const [videos, setVideos] = useState<any[]>([]);
  const [images, setImages] = useState<{ backdrops: any[]; posters: any[]; logos: any[] }>({
    backdrops: [],
    posters: [],
    logos: []
  });
  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [similar, setSimilar] = useState<any[]>([]);
  const [reviews, setReviews] = useState<any[]>([]);
  const [externalIds, setExternalIds] = useState<any>({});
  
  const [selectedProvider, setSelectedProvider] = useState(providers[0]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // TV / Anime Season & Episode states
  const [currentSeason, setCurrentSeason] = useState(initialSeason || 1);
  const [currentEpisode, setCurrentEpisode] = useState(initialEpisode || 1);
  const [isPlaying, setIsPlaying] = useState(!!(initialSeason || initialEpisode));
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  const [episodesLoading, setEpisodesLoading] = useState(false);
  const [expandedSeasonMenu, setExpandedSeasonMenu] = useState(false);
  const [bothFailed, setBothFailed] = useState(false);
  
  // Selected Episode state for displaying guest stars & details
  const [selectedEpisodeDetails, setSelectedEpisodeDetails] = useState<Episode | null>(null);

  useEffect(() => {
    if (initialSeason) setCurrentSeason(initialSeason);
    if (initialEpisode) setCurrentEpisode(initialEpisode);
    if (initialSeason || initialEpisode) setIsPlaying(true);
  }, [initialSeason, initialEpisode]);

  // Active Tab state
  const [activeTab, setActiveTab] = useState<string>("overview");

  // Collection details
  const [collectionDetails, setCollectionDetails] = useState<any | null>(null);
  const [collectionLoading, setCollectionLoading] = useState(false);

  // Actor / Person modal state
  const [selectedActorId, setSelectedActorId] = useState<number | null>(null);
  const [actorDetails, setActorDetails] = useState<any | null>(null);
  const [actorLoading, setActorLoading] = useState(false);

  // Lightbox modal state for gallery
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxImages, setLightboxImages] = useState<string[]>([]);
  const [lightboxIndex, setLightboxIndex] = useState(0);
  const [lightboxZoom, setLightboxZoom] = useState(1);

  // Interactive Video Player Modal state
  const [activeVideoKey, setActiveVideoKey] = useState<string | null>(null);

  const playerRef = useRef<HTMLIFrameElement>(null);
  const streamSectionRef = useRef<HTMLDivElement>(null);

  // Swipe gesture detection ref for Lightbox
  const touchStartX = useRef<number>(0);
  const touchEndX = useRef<number>(0);

  // Fetch Complete Details, Cast, Crew, Videos, Images, Recommendations, Similar, Reviews, and External IDs
  useEffect(() => {
    async function fetchAllDetails() {
      try {
        setLoading(true);
        setError(null);
        setCollectionDetails(null);
        setActiveTab("overview");

        const res = await fetch(`/api/tmdb/details/${contentType}/${tmdbId}`);
        if (!res.ok) throw new Error("Failed to load movie/show details from stream registry.");
        
        const data = await res.json();
        setDetails(data.details);
        setCast(data.credits || []);
        setCrew(data.crew || []);
        setVideos(data.videos || []);
        setImages(data.details?.images || { backdrops: [], posters: [], logos: [] });
        setRecommendations(data.recommendations || []);
        setSimilar(data.similar || []);
        setReviews(data.reviews || []);
        setExternalIds(data.external_ids || {});
        
        // Reset season/episode if ID or type changes
        setCurrentSeason(initialSeason || 1);
        setCurrentEpisode(initialEpisode || 1);
        setSelectedEpisodeDetails(null);
      } catch (err: any) {
        setError(err.message || "An unexpected error occurred.");
      } finally {
        setLoading(false);
      }
    }
    fetchAllDetails();
  }, [contentType, tmdbId, initialSeason, initialEpisode]);

  // Synchronize TV watch state to URL dynamically so users can share specific episodes
  useEffect(() => {
    if (contentType === "tv" && isPlaying) {
      const path = `/series/${tmdbId}/${currentSeason}/${currentEpisode}`;
      if (window.location.pathname !== path) {
        window.history.replaceState(null, "", path);
      }
    }
  }, [contentType, tmdbId, currentSeason, currentEpisode, isPlaying]);

  // Fetch Collection Details if the movie belongs to a collection
  useEffect(() => {
    if (!details?.belongs_to_collection?.id) {
      setCollectionDetails(null);
      return;
    }

    async function fetchCollection() {
      try {
        setCollectionLoading(true);
        const res = await fetch(`/api/tmdb/collection/${details.belongs_to_collection.id}`);
        if (res.ok) {
          const data = await res.json();
          setCollectionDetails(data);
        }
      } catch (err) {
        console.error("Failed to fetch collection details:", err);
      } finally {
        setCollectionLoading(false);
      }
    }
    fetchCollection();
  }, [details]);

  // Fetch TV Episodes when Season changes
  useEffect(() => {
    if (contentType !== "tv" || !tmdbId) return;

    async function fetchEpisodes() {
      try {
        setEpisodesLoading(true);
        const res = await fetch(`/api/tmdb/tv/${tmdbId}/season/${currentSeason}`);
        if (res.ok) {
          const data = await res.json();
          setEpisodes(data.episodes || []);
          if (data.episodes && data.episodes.length > 0) {
            setSelectedEpisodeDetails(data.episodes[0]);
          } else {
            setSelectedEpisodeDetails(null);
          }
        } else {
          setEpisodes([]);
          setSelectedEpisodeDetails(null);
        }
      } catch (err) {
        console.error("Failed to load season episodes", err);
        setEpisodes([]);
        setSelectedEpisodeDetails(null);
      } finally {
        setEpisodesLoading(false);
      }
    }
    fetchEpisodes();
  }, [contentType, tmdbId, currentSeason]);

  // Dynamic SEO optimization for active movie/show metadata
  useEffect(() => {
    if (!details) return;
    
    const mediaTitle = contentType === "tv"
      ? `${details.name || details.original_name || "Series"} - Season ${currentSeason}, Episode ${currentEpisode}`
      : `${details.title || details.original_title || details.name || "Movie"}`;

    const titleText = `${mediaTitle} | Watch Online in HD | Star King OTT`;
      
    const descText = details.overview 
      ? `${details.overview.slice(0, 160)}...`
      : `Stream ${contentType === "tv" ? details.name : details.title} on Star King OTT with high quality playback and seamless servers.`;

    document.title = titleText;
    
    // Update meta tags for SEO crawlers and previews
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) metaDesc.setAttribute("content", descText);

    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) ogTitle.setAttribute("content", titleText);

    const ogDesc = document.querySelector('meta[property="og:description"]');
    if (ogDesc) ogDesc.setAttribute("content", descText);

    const ogUrl = document.querySelector('meta[property="og:url"]');
    if (ogUrl) ogUrl.setAttribute("content", window.location.href);

    const twitterTitle = document.querySelector('meta[name="twitter:title"]');
    if (twitterTitle) twitterTitle.setAttribute("content", titleText);

    const twitterDesc = document.querySelector('meta[name="twitter:description"]');
    if (twitterDesc) twitterDesc.setAttribute("content", descText);
    
    if (details.poster_path) {
      const imgUrl = `https://image.tmdb.org/t/p/w500${details.poster_path}`;
      const ogImg = document.querySelector('meta[property="og:image"]');
      if (ogImg) ogImg.setAttribute("content", imgUrl);
      const twitterImg = document.querySelector('meta[name="twitter:image"]');
      if (twitterImg) twitterImg.setAttribute("content", imgUrl);
    }
  }, [details, contentType, currentSeason, currentEpisode]);

  // Fetch Actor Details when selectedActorId changes
  useEffect(() => {
    if (!selectedActorId) {
      setActorDetails(null);
      return;
    }

    async function fetchActor() {
      try {
        setActorLoading(true);
        const res = await fetch(`/api/tmdb/person/${selectedActorId}`);
        if (res.ok) {
          const data = await res.json();
          setActorDetails(data);
        }
      } catch (err) {
        console.error("Failed to fetch actor details:", err);
      } finally {
        setActorLoading(false);
      }
    }
    fetchActor();
  }, [selectedActorId]);

  // Gallery Keyboard Navigation
  useEffect(() => {
    if (!lightboxOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setLightboxOpen(false);
        setLightboxZoom(1);
      } else if (e.key === "ArrowRight") {
        setLightboxIndex((prev) => (prev + 1) % lightboxImages.length);
        setLightboxZoom(1);
      } else if (e.key === "ArrowLeft") {
        setLightboxIndex((prev) => (prev - 1 + lightboxImages.length) % lightboxImages.length);
        setLightboxZoom(1);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [lightboxOpen, lightboxImages]);

  if (loading) {
    return (
      <div className="min-h-screen pt-24 pb-12 px-4 md:px-8 flex flex-col items-center justify-center bg-[#030712]">
        <div className="w-16 h-16 border-4 border-red-500/30 border-t-red-500 rounded-full animate-spin"></div>
        <p className="mt-4 text-gray-400 font-display animate-pulse text-sm">Initializing STAR KING OTT Stream Channels...</p>
      </div>
    );
  }

  if (error || !details) {
    return (
      <div className="min-h-screen pt-24 pb-12 px-4 md:px-8 flex flex-col items-center justify-center text-center bg-[#030712]">
        <div className="w-16 h-16 rounded-full bg-red-500/10 border border-red-500/30 flex items-center justify-center mb-4 text-red-500">
          <Info className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-white mb-2">Stream Information Unavailable</h2>
        <p className="text-gray-400 max-w-md mb-6">{error || "Unable to retrieve details for this content channel."}</p>
        <button 
          onClick={onBack}
          className="px-6 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-medium transition-all"
        >
          Return to Catalog
        </button>
      </div>
    );
  }

  // Detect if content is Anime
  const isAnime = details.genres?.some((g: any) => g.id === 16) && 
    (details.original_language === "ja" || details.production_countries?.some((c: any) => c.iso_3166_1 === "JP"));

  const title = details.title || details.name || "Untitled Stream";
  const originalTitle = details.original_title || details.original_name;
  const rating = details.vote_average ? details.vote_average.toFixed(1) : "0.0";
  const voteCount = details.vote_count || 0;
  const popularity = details.popularity ? details.popularity.toFixed(1) : "0";
  
  const releaseDate = details.release_date || details.first_air_date;
  const releaseYear = releaseDate ? new Date(releaseDate).getFullYear() : "N/A";
  
  const status = details.status || "Released";
  const homepage = details.homepage;
  const imdbId = details.imdb_id || externalIds.imdb_id;

  // Budget & Revenue
  const budget = details.budget ? details.budget.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }) : null;
  const revenue = details.revenue ? details.revenue.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }) : null;

  // TV stats
  const numberOfSeasons = details.number_of_seasons;
  const numberOfEpisodes = details.number_of_episodes;

  // Studios / Production Companies & Countries
  const productionCompanies = details.production_companies || [];
  const productionCountries = details.production_countries || [];
  const spokenLanguages = details.spoken_languages || [];
  const networks = details.networks || [];

  // Backdrop, Logo & Poster
  const backdropUrl = details.backdrop_path 
    ? `https://image.tmdb.org/t/p/original${details.backdrop_path}`
    : "https://images.unsplash.com/photo-1574375927938-d5a98e8edd86?auto=format&fit=crop&q=80&w=1200";

  const posterUrl = details.poster_path
    ? `https://image.tmdb.org/t/p/w780${details.poster_path}`
    : "https://images.unsplash.com/photo-1594909122845-11baa439b7bf?auto=format&fit=crop&q=80&w=780";

  const logoObj = images.logos?.find((l: any) => l.iso_639_1 === "en" || !l.iso_639_1);
  const logoUrl = logoObj ? `https://image.tmdb.org/t/p/original${logoObj.file_path}` : null;

  // Stream URL generator
  const currentEmbedUrl = getProviderUrl(
    selectedProvider,
    contentType,
    tmdbId,
    currentSeason,
    currentEpisode
  );

  const handleServerError = () => {
    if (selectedProvider.id === "cinesrc") {
      const fallback = providers.find(p => p.id === "vidsrc-sbs");
      if (fallback) setSelectedProvider(fallback);
    } else {
      setBothFailed(true);
    }
  };

  // Crew filtering functions
  const getCrewByJob = (jobTitle: string) => {
    return crew.filter((c: any) => c.job === jobTitle).map((c: any) => c.name).join(", ");
  };

  const getCrewList = () => {
    const directors = crew.filter((c: any) => ["Director", "Series Director"].includes(c.job));
    const producers = crew.filter((c: any) => ["Producer", "Executive Producer"].includes(c.job));
    const writers = crew.filter((c: any) => ["Writer", "Screenplay", "Author", "Novel", "Story"].includes(c.job));
    const music = crew.filter((c: any) => ["Original Music Composer", "Music", "Music Director"].includes(c.job));
    const cinematography = crew.filter((c: any) => ["Director of Photography", "Cinematography"].includes(c.job));
    const editors = crew.filter((c: any) => ["Editor", "Supervising Editor"].includes(c.job));

    return {
      directors,
      producers,
      writers,
      music,
      cinematography,
      editors
    };
  };

  const crewGroups = getCrewList();

  // Scroll smoothly to player
  const scrollToPlayer = () => {
    setIsPlaying(true);
  };

  // Find Trailer to watch
  const mainTrailer = videos.find((v: any) => v.site === "YouTube" && (v.type === "Trailer" || v.type === "Teaser"));

  const triggerWatchTrailer = () => {
    if (mainTrailer) {
      setActiveVideoKey(mainTrailer.key);
    } else {
      scrollToPlayer();
    }
  };

  // Get anime season name
  const getAnimeSeason = (dateStr?: string) => {
    if (!dateStr) return "N/A";
    const date = new Date(dateStr);
    const month = date.getMonth();
    const year = date.getFullYear();
    let seasonName = "Winter";
    if (month >= 3 && month <= 5) seasonName = "Spring";
    else if (month >= 6 && month <= 8) seasonName = "Summer";
    else if (month >= 9 && month <= 11) seasonName = "Fall";
    return `${seasonName} ${year}`;
  };

  // Lightbox gesture handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.targetTouches[0].clientX;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndX.current = e.targetTouches[0].clientX;
  };

  const handleTouchEnd = () => {
    if (touchStartX.current - touchEndX.current > 50) {
      // Swipe Left -> Next
      setLightboxIndex((prev) => (prev + 1) % lightboxImages.length);
      setLightboxZoom(1);
    } else if (touchEndX.current - touchStartX.current > 50) {
      // Swipe Right -> Prev
      setLightboxIndex((prev) => (prev - 1 + lightboxImages.length) % lightboxImages.length);
      setLightboxZoom(1);
    }
  };

  // Format Reviews safely
  const formatReviewContent = (text: string) => {
    if (!text) return "";
    return text.length > 300 ? text.slice(0, 300) + "..." : text;
  };

  if (isPlaying) {
    return (
      <div className="min-h-screen bg-[#030712] text-gray-100 font-sans selection:bg-red-500 selection:text-white pb-20 pt-24 animate-fade-in">
        
        {/* Streaming Header bar */}
        <div className="max-w-7xl mx-auto px-4 md:px-8 flex flex-col gap-8">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
            <button 
              onClick={() => {
                setIsPlaying(false);
                setBothFailed(false);
              }}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-gray-300 hover:text-white font-bold transition-all cursor-pointer self-start"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back to Details Page</span>
            </button>
          </div>

          {/* Title & Episode info */}
          <div className="flex flex-col gap-2">
            <h1 className="font-display font-black text-2xl md:text-4xl text-white tracking-tight uppercase">
              {title} {contentType === "tv" && `• S${currentSeason} : EP${currentEpisode}`}
            </h1>
            {contentType === "tv" && selectedEpisodeDetails && (
              <p className="text-sm font-semibold text-red-400">
                Episode {currentEpisode}: "{selectedEpisodeDetails.name}"
              </p>
            )}
            <div className="flex flex-wrap items-center gap-3 text-xs text-gray-400 mt-1">
              <span className="px-2 py-0.5 rounded bg-white/5 border border-white/10 text-red-500 font-bold uppercase">{contentType}</span>
              <span>⭐ {rating}</span>
              <span>•</span>
              <span>{releaseYear}</span>
              <span>•</span>
              <span className="uppercase font-mono">{details.original_language}</span>
            </div>
          </div>

          {/* Core Player Frame & Side Episode Selection */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            <div className="lg:col-span-3 flex flex-col gap-4">
              
              <div className="aspect-video w-full rounded-2xl overflow-hidden bg-black border border-white/10 shadow-2xl relative group">
                {bothFailed ? (
                  <div className="absolute inset-0 bg-gray-950 flex flex-col items-center justify-center p-6 text-center z-10">
                    <Server className="w-12 h-12 text-red-500 mb-4 animate-bounce" />
                    <h3 className="font-display font-bold text-lg text-white mb-2">Mirror Stream Interrupted</h3>
                    <p className="text-gray-400 max-w-md text-xs mb-4">Servers are responding slowly or your browser blocked the connection.</p>
                    <button
                      onClick={() => { setBothFailed(false); setSelectedProvider(providers[0]); }}
                      className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-semibold transition-all shadow-lg cursor-pointer"
                    >
                      Reset & Retry
                    </button>
                  </div>
                ) : (
                  <iframe
                    id="watch-iframe-player"
                    ref={playerRef}
                    src={currentEmbedUrl}
                    className="w-full h-full border-0 absolute inset-0"
                    allowFullScreen
                    allow="autoplay; encrypted-media; picture-in-picture"
                    referrerPolicy="no-referrer"
                    title={`${title} Live OTT Feed`}
                  />
                )}
              </div>

              {/* Advice */}
              <div className="flex items-center gap-2 px-4 py-3 rounded-xl bg-red-500/5 border border-red-500/10 text-xs text-gray-400">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                </span>
                <span><b>Technical Advice:</b> Use <b>Direct Mirror</b> if your browser has aggressive ad-blocking. Toggle servers for language options.</span>
              </div>

              {/* Server Nodes Selector strip */}
              <div className="glass-panel p-4 rounded-2xl flex flex-wrap gap-4 items-center justify-between border border-white/5 bg-white/2.5">
                <div className="flex items-center gap-3">
                  <Server className="w-5 h-5 text-red-500 animate-pulse" />
                  <div>
                    <div className="text-[10px] text-gray-500 uppercase font-mono">BROADCASTER NODE</div>
                    <div className="text-xs font-bold text-white">{selectedProvider.name}</div>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  {providers.map((p, idx) => (
                    <button
                      key={p.id}
                      onClick={() => { setBothFailed(false); setSelectedProvider(p); }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
                        selectedProvider.id === p.id
                          ? "bg-red-600 text-white border-red-500 shadow-lg"
                          : "bg-white/5 border-white/5 text-gray-400 hover:text-white"
                      }`}
                    >
                      Server {idx + 1}
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-2">
                  <button onClick={handleServerError} className="px-3 py-1.5 rounded-lg bg-white/5 text-xs text-gray-400 hover:text-white cursor-pointer">Autoswitch</button>
                  <a href={currentEmbedUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-600 text-white text-xs font-bold shadow-lg cursor-pointer">
                    <span>Direct Mirror</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            </div>

            {/* Side list/spec sidebar */}
            <div className="lg:col-span-1 flex flex-col gap-4">
              {contentType === "tv" ? (
                /* Interactive Episode Selection Panel */
                <div className="glass-panel p-4 rounded-2xl border border-white/5 bg-white/2.5 flex flex-col gap-4">
                  <div className="flex justify-between items-center border-b border-white/5 pb-2">
                    <span className="text-xs text-gray-400 font-bold uppercase tracking-wider">Episodes List</span>
                    <span className="text-xs text-red-400 font-extrabold">Season {currentSeason}</span>
                  </div>

                  <div className="flex flex-col gap-2 max-h-[380px] overflow-y-auto scrollbar-thin pr-1">
                    {episodesLoading ? (
                      <div className="flex justify-center py-6">
                        <div className="w-6 h-6 border-2 border-red-500/20 border-t-red-500 rounded-full animate-spin"></div>
                      </div>
                    ) : episodes.length === 0 ? (
                      <div className="text-center py-4 text-gray-500 text-xs">No episodes.</div>
                    ) : (
                      episodes.map((ep) => {
                        const isEpActive = ep.episode_number === currentEpisode;
                        return (
                          <div
                            key={ep.id}
                            onClick={() => {
                              setCurrentEpisode(ep.episode_number);
                              setSelectedEpisodeDetails(ep);
                              setBothFailed(false);
                            }}
                            className={`p-2.5 rounded-xl border cursor-pointer text-xs transition-all flex items-center justify-between ${
                              isEpActive 
                                ? "bg-red-500/10 border-red-500/40 text-red-400 font-bold" 
                                : "bg-black/30 border-white/5 text-gray-400 hover:text-white hover:border-white/10"
                            }`}
                          >
                            <span className="truncate max-w-[80%]">Ep {ep.episode_number}. {ep.name || `Episode ${ep.episode_number}`}</span>
                            {isEpActive && <Play className="w-3 h-3 fill-red-500 text-red-500" />}
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              ) : null}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#030712] text-gray-100 font-sans selection:bg-red-500 selection:text-white pb-20">
      
      {/* 14. CINEMATIC HERO SECTION */}
      <div className="relative w-full h-auto min-h-[70vh] md:h-[85vh] flex items-end overflow-hidden pt-24 md:pt-0 pb-8 md:pb-0">
        
        {/* Backdrop Image & Blur Placeholder */}
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-[#030712]/50 backdrop-blur-[1px] z-10 pointer-events-none"></div>
          <img 
            src={backdropUrl} 
            alt={title}
            className="w-full h-full object-cover transition-transform duration-700 scale-102"
          />
          {/* Edge vignettes */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#030712] via-[#030712]/30 to-transparent z-15 pointer-events-none"></div>
          <div className="absolute inset-y-0 left-0 w-full md:w-[60%] bg-gradient-to-r from-[#030712] via-[#030712]/60 to-transparent z-15 pointer-events-none"></div>
        </div>

        {/* Hero Content Panel */}
        <div className="relative z-20 max-w-7xl mx-auto px-4 md:px-8 w-full pb-10 md:pb-16 flex flex-col md:flex-row gap-8 items-center md:items-end">
          
          {/* Left: Movie/Show Poster */}
          <div className="w-40 sm:w-48 md:w-56 shrink-0 rounded-2xl overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.8)] border border-white/10 aspect-[2/3] transform hover:scale-[1.02] transition-transform duration-300">
            <img 
              src={posterUrl} 
              alt={title} 
              loading="eager"
              className="w-full h-full object-cover"
            />
          </div>

          {/* Right: Metadata Panel */}
          <div className="flex-1 text-center md:text-left flex flex-col gap-4">
            
            {/* Anime Identifier */}
            {isAnime && (
              <span className="self-center md:self-start px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest bg-red-600 text-white shadow-lg animate-pulse">
                🎌 Official Anime Selection
              </span>
            )}

            {/* Official Logo or Fallback Title */}
            {logoUrl ? (
              <img 
                src={logoUrl} 
                alt={title} 
                className="max-h-24 md:max-h-36 object-contain mx-auto md:mx-0 filter drop-shadow-[0_10px_20px_rgba(0,0,0,0.95)] transition-all animate-fade-in"
                onError={(e) => {
                  (e.target as any).style.display = "none";
                  const fallback = document.getElementById("hero-fallback-title");
                  if (fallback) fallback.style.display = "block";
                }}
              />
            ) : null}

            <h1 
              id="hero-fallback-title"
              style={{ display: logoUrl ? "none" : "block" }}
              className="font-display font-black text-3xl md:text-5xl tracking-tight text-white uppercase drop-shadow-md"
            >
              {title}
            </h1>

            {/* Tagline */}
            {details.tagline && (
              <p className="text-gray-300 italic text-sm md:text-base font-medium max-w-2xl drop-shadow-md">
                "{details.tagline}"
              </p>
            )}

            {/* Metadata Badges */}
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 text-xs text-gray-300">
              {/* Release Year */}
              <span className="px-2.5 py-1 rounded-md bg-white/10 text-white font-bold backdrop-blur-md">
                {releaseYear}
              </span>
              
              {/* TMDB Rating */}
              <div className="flex items-center gap-1 font-bold text-yellow-500 bg-yellow-500/10 px-2.5 py-1 rounded-md border border-yellow-500/20">
                <Star className="w-3.5 h-3.5 fill-yellow-500 text-yellow-500" />
                <span>{rating} <span className="text-[10px] text-gray-400 font-normal">({voteCount.toLocaleString()})</span></span>
              </div>

              {/* IMDb Rating link (if available) */}
              {imdbId && (
                <a 
                  href={`https://www.imdb.com/title/${imdbId}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 bg-[#F5C518]/10 text-[#F5C518] hover:bg-[#F5C518]/20 px-2.5 py-1 rounded-md border border-[#F5C518]/20 font-bold transition-all"
                >
                  <Award className="w-3.5 h-3.5" />
                  <span>IMDb</span>
                  <ExternalLink className="w-3 h-3 text-[#F5C518]/70" />
                </a>
              )}

              {/* Runtime (Movie) or Seasons (TV) */}
              {contentType === "movie" && details.runtime ? (
                <div className="flex items-center gap-1.5 text-gray-300">
                  <Clock className="w-4 h-4 text-gray-500" />
                  <span>{details.runtime} min</span>
                </div>
              ) : contentType === "tv" && numberOfSeasons ? (
                <div className="flex items-center gap-1.5 text-gray-300 font-semibold">
                  <Tv className="w-4 h-4 text-gray-500" />
                  <span>{numberOfSeasons} {numberOfSeasons === 1 ? "Season" : "Seasons"}</span>
                </div>
              ) : null}

              {/* Languages */}
              <span className="px-2 py-0.5 text-[10px] rounded bg-white/5 border border-white/15 text-gray-400 font-mono uppercase">
                {details.original_language}
              </span>
            </div>

            {/* Genres */}
            <div className="flex flex-wrap gap-1.5 justify-center md:justify-start">
              {details.genres?.map((genre: any) => (
                <span 
                  key={genre.id} 
                  className="text-[11px] px-3 py-1 rounded-full bg-white/5 border border-white/5 text-gray-300 font-semibold"
                >
                  {genre.name}
                </span>
              ))}
            </div>

            {/* Interactive Control Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center md:justify-start gap-4 mt-4">
              <button 
                id="hero-play-stream"
                onClick={() => setIsPlaying(true)}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold transition-all shadow-lg shadow-red-600/30 active:scale-[0.98] cursor-pointer"
              >
                <Play className="w-5 h-5 fill-white" />
                <span>STREAM NOW</span>
              </button>

              <button 
                id="hero-watch-trailer"
                onClick={triggerWatchTrailer}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/15 text-white font-bold transition-all backdrop-blur-md active:scale-[0.98] cursor-pointer"
              >
                <Film className="w-5 h-5" />
                <span>WATCH TRAILER</span>
              </button>

              <button 
                onClick={onBack}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 text-gray-400 hover:text-white font-bold transition-all cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>BACK</span>
              </button>
            </div>

          </div>

        </div>

      </div>



      {/* 15. REDESIGNED SECTIONS TABS NAVIGATION */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 mt-12">
        
        {/* Sticky styled horizontal scroll tab list */}
        <div className="flex items-center gap-1 overflow-x-auto pb-2 border-b border-white/5 select-none scrollbar-thin">
          <button 
            onClick={() => setActiveTab("overview")}
            className={`px-5 py-3 rounded-xl text-xs font-extrabold transition-all whitespace-nowrap cursor-pointer shrink-0 ${
              activeTab === "overview" 
                ? "bg-red-600 text-white shadow-md shadow-red-600/10" 
                : "text-gray-400 hover:text-white"
            }`}
          >
            OVERVIEW
          </button>
          
          {contentType === "tv" && (
            <button 
              onClick={() => setActiveTab("episodes")}
              className={`px-5 py-3 rounded-xl text-xs font-extrabold transition-all whitespace-nowrap cursor-pointer shrink-0 ${
                activeTab === "episodes" 
                  ? "bg-red-600 text-white shadow-md shadow-red-600/10" 
                  : "text-gray-400 hover:text-white"
              }`}
            >
              EPISODES
            </button>
          )}

          <button 
            onClick={() => setActiveTab("gallery")}
            className={`px-5 py-3 rounded-xl text-xs font-extrabold transition-all whitespace-nowrap cursor-pointer shrink-0 ${
              activeTab === "gallery" 
                ? "bg-red-600 text-white shadow-md shadow-red-600/10" 
                : "text-gray-400 hover:text-white"
            }`}
          >
            SCREENSHOTS & POSTERS ({images.backdrops?.length + images.posters?.length || 0})
          </button>

          <button 
            onClick={() => setActiveTab("cast")}
            className={`px-5 py-3 rounded-xl text-xs font-extrabold transition-all whitespace-nowrap cursor-pointer shrink-0 ${
              activeTab === "cast" 
                ? "bg-red-600 text-white shadow-md shadow-red-600/10" 
                : "text-gray-400 hover:text-white"
            }`}
          >
            CAST & CREW
          </button>

          <button 
            onClick={() => setActiveTab("videos")}
            className={`px-5 py-3 rounded-xl text-xs font-extrabold transition-all whitespace-nowrap cursor-pointer shrink-0 ${
              activeTab === "videos" 
                ? "bg-red-600 text-white shadow-md shadow-red-600/10" 
                : "text-gray-400 hover:text-white"
            }`}
          >
            VIDEOS & CLIPS ({videos?.length || 0})
          </button>

          {collectionDetails && (
            <button 
              onClick={() => setActiveTab("collection")}
              className={`px-5 py-3 rounded-xl text-xs font-extrabold transition-all whitespace-nowrap cursor-pointer shrink-0 ${
                activeTab === "collection" 
                  ? "bg-red-600 text-white shadow-md shadow-red-600/10" 
                  : "text-gray-400 hover:text-white"
              }`}
            >
              COLLECTION
            </button>
          )}

          <button 
            onClick={() => setActiveTab("reviews")}
            className={`px-5 py-3 rounded-xl text-xs font-extrabold transition-all whitespace-nowrap cursor-pointer shrink-0 ${
              activeTab === "reviews" 
                ? "bg-red-600 text-white shadow-md shadow-red-600/10" 
                : "text-gray-400 hover:text-white"
            }`}
          >
            REVIEWS ({reviews?.length || 0})
          </button>

          <button 
            onClick={() => setActiveTab("tech")}
            className={`px-5 py-3 rounded-xl text-xs font-extrabold transition-all whitespace-nowrap cursor-pointer shrink-0 ${
              activeTab === "tech" 
                ? "bg-red-600 text-white shadow-md shadow-red-600/10" 
                : "text-gray-400 hover:text-white"
            }`}
          >
            TECHNICAL DETAILS
          </button>

          <button 
            onClick={() => setActiveTab("related")}
            className={`px-5 py-3 rounded-xl text-xs font-extrabold transition-all whitespace-nowrap cursor-pointer shrink-0 ${
              activeTab === "related" 
                ? "bg-red-600 text-white shadow-md shadow-red-600/10" 
                : "text-gray-400 hover:text-white"
            }`}
          >
            MORE LIKE THIS ({recommendations?.length || 0})
          </button>
        </div>

        {/* TAB CONTENTS */}
        <div className="mt-8">
          
          {/* TAB: OVERVIEW */}
          {activeTab === "overview" && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-fade-in">
              {/* Main Content Area */}
              <div className="lg:col-span-2 flex flex-col gap-6">
                <div>
                  <h3 className="font-display font-extrabold text-xl text-white mb-3 flex items-center gap-2">
                    <Info className="w-5 h-5 text-red-500" />
                    <span>Storyline Overview</span>
                  </h3>
                  <p className="text-gray-300 text-sm leading-relaxed whitespace-pre-line bg-white/2.5 p-5 rounded-2xl border border-white/5">
                    {details.overview || "This stream is currently live. No descriptive synopsis was configured by the provider."}
                  </p>
                </div>

                {/* If Anime, display Anime Special Info Panel */}
                {isAnime && (
                  <div className="bg-[#111827]/40 border border-red-500/15 rounded-2xl p-6 flex flex-col gap-4">
                    <h4 className="font-display font-extrabold text-sm text-red-400 tracking-wider uppercase flex items-center gap-2">
                      <span>🎌 ANIME SPECIAL METADATA</span>
                    </h4>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
                      <div>
                        <div className="text-gray-500">Studios</div>
                        <div className="text-white font-bold mt-1 line-clamp-1">
                          {productionCompanies.filter((p: any) => p.logo_path).slice(0, 2).map((p: any) => p.name).join(", ") || "Production Committee"}
                        </div>
                      </div>
                      
                      <div>
                        <div className="text-gray-500">Anime Season</div>
                        <div className="text-white font-bold mt-1">{getAnimeSeason(releaseDate)}</div>
                      </div>

                      <div>
                        <div className="text-gray-500">Total Episodes</div>
                        <div className="text-white font-bold mt-1">{numberOfEpisodes || "N/A"} Episodes</div>
                      </div>

                      <div>
                        <div className="text-gray-500">Original Japanese Name</div>
                        <div className="text-white font-mono font-bold mt-1 text-[11px] line-clamp-1">{originalTitle}</div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Cast Summary list */}
                {cast.length > 0 && (
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-display font-extrabold text-lg text-white">Top Billing Cast</h3>
                      <button 
                        onClick={() => setActiveTab("cast")}
                        className="text-xs text-red-400 font-bold hover:text-red-300"
                      >
                        View Full Cast & Crew →
                      </button>
                    </div>

                    <div className="grid grid-cols-3 sm:grid-cols-6 gap-4">
                      {cast.slice(0, 6).map((member) => (
                        <div 
                          key={member.id} 
                          onClick={() => setSelectedActorId(member.id)}
                          className="flex flex-col items-center text-center cursor-pointer group"
                        >
                          <div className="w-16 h-16 rounded-full overflow-hidden border border-white/5 group-hover:border-red-500 transition-colors bg-gray-950">
                            <img 
                              src={member.profile_path ? `https://image.tmdb.org/t/p/w185${member.profile_path}` : "https://img.icons8.com/color/185/test-account.png"} 
                              alt={member.name}
                              loading="lazy"
                              className="w-full h-full object-cover transition-transform group-hover:scale-105"
                            />
                          </div>
                          <span className="text-[11px] font-bold text-white mt-2 line-clamp-1 group-hover:text-red-400">
                            {member.name}
                          </span>
                          <span className="text-[9px] text-gray-500 line-clamp-1">
                            {member.character}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Director / Writer Row */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-white/5 pt-4">
                  {crewGroups.directors.length > 0 && (
                    <div className="text-xs">
                      <span className="text-gray-500 font-semibold block uppercase tracking-wider">Director</span>
                      <span className="text-gray-200 text-sm font-bold mt-1 block">
                        {crewGroups.directors.slice(0, 3).map((c: any) => c.name).join(", ")}
                      </span>
                    </div>
                  )}

                  {crewGroups.writers.length > 0 && (
                    <div className="text-xs">
                      <span className="text-gray-500 font-semibold block uppercase tracking-wider">Writer / Screenplay</span>
                      <span className="text-gray-200 text-sm font-bold mt-1 block">
                        {crewGroups.writers.slice(0, 3).map((c: any) => c.name).join(", ")}
                      </span>
                    </div>
                  )}
                </div>

              </div>

              {/* Sidebar Quick Information Card */}
              <div className="lg:col-span-1 flex flex-col gap-6">
                
                {/* Information Checklist */}
                <div className="glass-panel p-6 rounded-2xl border border-white/5 flex flex-col gap-4">
                  <h4 className="font-display font-extrabold text-sm text-white border-b border-white/5 pb-2">
                    BROADCASTER METADATA
                  </h4>
                  
                  <div className="flex flex-col gap-3 text-xs">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400">Alternative Title</span>
                      <span className="text-gray-200 text-right max-w-[60%] truncate font-medium">{originalTitle || "None"}</span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-gray-400">Content Status</span>
                      <span className="text-emerald-400 font-bold">{status}</span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-gray-400">First Stream Air</span>
                      <span className="text-gray-200 font-mono font-medium">{releaseDate ? new Date(releaseDate).toLocaleDateString() : "N/A"}</span>
                    </div>

                    {budget && (
                      <div className="flex justify-between items-center">
                        <span className="text-gray-400">Production Budget</span>
                        <span className="text-gray-200 font-mono font-semibold">{budget}</span>
                      </div>
                    )}

                    {revenue && (
                      <div className="flex justify-between items-center">
                        <span className="text-gray-400">Global Box Office</span>
                        <span className="text-gray-200 font-mono font-semibold">{revenue}</span>
                      </div>
                    )}

                    {networks.length > 0 && (
                      <div className="flex justify-between items-center">
                        <span className="text-gray-400">Network / Platform</span>
                        <span className="text-gray-200 font-bold">{networks[0].name}</span>
                      </div>
                    )}

                    {homepage && (
                      <div className="flex justify-between items-center">
                        <span className="text-gray-400">Official Homepage</span>
                        <a 
                          href={homepage} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-red-400 font-semibold hover:underline flex items-center gap-1 shrink-0"
                        >
                          <span>Visit Website</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    )}
                  </div>
                </div>

                {/* Mini trailers banner */}
                {videos.length > 0 && (
                  <div className="glass-panel p-5 rounded-2xl border border-white/5 flex flex-col gap-3">
                    <h5 className="text-xs text-gray-400 font-black uppercase tracking-wider">TRAILER SNAPSHOT</h5>
                    
                    <div className="relative aspect-video rounded-xl overflow-hidden group bg-black">
                      <img 
                        src={`https://img.youtube.com/vi/${mainTrailer?.key || videos[0]?.key}/mqdefault.jpg`} 
                        alt="Trailer thumbnail" 
                        className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-300"
                      />
                      <button 
                        onClick={triggerWatchTrailer}
                        className="absolute inset-0 flex items-center justify-center cursor-pointer"
                        aria-label="Play trailer"
                      >
                        <div className="w-10 h-10 rounded-full bg-red-600 flex items-center justify-center text-white shadow-xl">
                          <Play className="w-4 h-4 fill-white ml-0.5" />
                        </div>
                      </button>
                    </div>
                    <span className="text-[11px] text-gray-300 font-bold line-clamp-1">{mainTrailer?.name || videos[0]?.name}</span>
                  </div>
                )}

              </div>
            </div>
          )}

          {/* TAB: EPISODES (TV/ANIME ONLY) */}
          {activeTab === "episodes" && contentType === "tv" && (
            <div className="glass-panel p-6 rounded-3xl border border-white/5 animate-fade-in">
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/5 pb-4 mb-6">
                <div className="flex items-center gap-2">
                  <Tv className="w-5 h-5 text-red-500 text-glow" />
                  <h2 className="font-display font-bold text-lg text-white">Episodes Selection ({episodes.length} Episodes)</h2>
                </div>

                {/* Seasons Dropdown Selector */}
                <div className="relative">
                  <button
                    onClick={() => setExpandedSeasonMenu(!expandedSeasonMenu)}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 text-sm font-semibold text-white transition-all cursor-pointer"
                  >
                    <Layers className="w-4 h-4 text-red-400" />
                    <span>Season {currentSeason}</span>
                    <ChevronDown className="w-4 h-4" />
                  </button>

                  {expandedSeasonMenu && (
                    <div className="absolute right-0 mt-2 w-48 rounded-xl bg-[#0b0f19] border border-white/10 shadow-2xl z-30 overflow-hidden">
                      {Array.from({ length: details.number_of_seasons || 1 }, (_, i) => i + 1).map((sNum) => (
                        <button
                          key={sNum}
                          onClick={() => {
                            setCurrentSeason(sNum);
                            setCurrentEpisode(1);
                            setExpandedSeasonMenu(false);
                          }}
                          className={`w-full px-4 py-2.5 text-left text-sm transition-colors cursor-pointer hover:bg-white/5 flex items-center justify-between ${
                            currentSeason === sNum ? "text-red-400 font-bold bg-white/5" : "text-gray-300"
                          }`}
                        >
                          <span>Season {sNum}</span>
                          {currentSeason === sNum && <span className="w-1.5 h-1.5 rounded-full bg-red-500"></span>}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Season Episodes Cards & Interactive Active Episode details block */}
              {episodesLoading ? (
                <div className="flex justify-center py-12">
                  <div className="w-8 h-8 border-2 border-red-500/20 border-t-red-500 rounded-full animate-spin"></div>
                </div>
              ) : episodes.length === 0 ? (
                <div className="text-center py-12 text-gray-500 text-sm">
                  No episodes configured for Season {currentSeason}.
                </div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* Left: Interactive Ep list */}
                  <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4 max-h-[500px] overflow-y-auto pr-2 scrollbar-thin">
                    {episodes.map((ep) => {
                      const isActive = ep.episode_number === currentEpisode;
                      const thumbnail = ep.still_path 
                        ? `https://image.tmdb.org/t/p/w300${ep.still_path}`
                        : "https://images.unsplash.com/photo-1594909122845-11baa439b7bf?auto=format&fit=crop&q=80&w=300";

                      return (
                        <div
                          key={ep.id}
                          onClick={() => {
                            setCurrentEpisode(ep.episode_number);
                            setSelectedEpisodeDetails(ep);
                            setIsPlaying(true);
                          }}
                          className={`group cursor-pointer rounded-xl overflow-hidden border transition-all duration-300 flex flex-col ${
                            isActive 
                              ? "bg-red-500/10 border-red-500/50 shadow-lg scale-[0.99]" 
                              : "bg-gray-950/40 border-white/5 hover:border-white/20"
                          }`}
                        >
                          <div className="aspect-video w-full overflow-hidden relative bg-black/60">
                            <img 
                              src={thumbnail} 
                              alt={ep.name}
                              loading="lazy" 
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            />
                            <div className="absolute top-2 left-2 px-1.5 py-0.5 rounded bg-black/85 backdrop-blur-md text-[10px] font-black text-gray-300">
                              EPISODE {ep.episode_number}
                            </div>
                            
                            <div className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded bg-black/85 backdrop-blur-md text-[10px] font-bold text-yellow-500 flex items-center gap-0.5">
                              <Star className="w-2.5 h-2.5 fill-yellow-500" />
                              <span>{ep.vote_average ? ep.vote_average.toFixed(1) : "0.0"}</span>
                            </div>

                            {isActive && (
                              <div className="absolute inset-0 bg-red-600/30 flex items-center justify-center backdrop-blur-[1px]">
                                <Play className="w-8 h-8 text-white fill-white drop-shadow-md animate-pulse" />
                              </div>
                            )}
                          </div>
                          
                          <div className="p-3">
                            <h4 className="font-bold text-xs text-white line-clamp-1 group-hover:text-red-400 transition-colors">
                              {ep.name || `Episode ${ep.episode_number}`}
                            </h4>
                            {ep.air_date && (
                              <p className="text-[10px] text-gray-500 mt-1">{new Date(ep.air_date).toLocaleDateString()}</p>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Right: Active Episode details, guest stars, overview */}
                  <div className="lg:col-span-1">
                    {selectedEpisodeDetails ? (
                      <div className="glass-panel p-5 rounded-2xl border border-white/5 flex flex-col gap-4 animate-fade-in bg-white/2.5">
                        <span className="text-[10px] text-red-400 font-bold uppercase tracking-widest bg-red-500/10 self-start px-2 py-0.5 rounded border border-red-500/10">
                          Episode {selectedEpisodeDetails.episode_number} Details
                        </span>
                        
                        <h3 className="font-display font-extrabold text-white text-base">
                          {selectedEpisodeDetails.name}
                        </h3>

                        {selectedEpisodeDetails.still_path && (
                          <div className="aspect-video w-full rounded-xl overflow-hidden border border-white/5 bg-gray-950">
                            <img 
                              src={`https://image.tmdb.org/t/p/w500${selectedEpisodeDetails.still_path}`} 
                              alt={selectedEpisodeDetails.name}
                              className="w-full h-full object-cover"
                            />
                          </div>
                        )}

                        <p className="text-xs text-gray-300 leading-relaxed bg-black/20 p-4 rounded-xl border border-white/5">
                          {selectedEpisodeDetails.overview || "No specific overview was submitted for this episode."}
                        </p>

                        {/* Guest Stars List */}
                        {(selectedEpisodeDetails as any).guest_stars && (selectedEpisodeDetails as any).guest_stars.length > 0 && (
                          <div className="border-t border-white/5 pt-3">
                            <span className="text-[11px] text-gray-500 font-bold uppercase tracking-wider block mb-2">Guest Stars</span>
                            <div className="flex flex-wrap gap-1.5">
                              {(selectedEpisodeDetails as any).guest_stars.slice(0, 5).map((star: any) => (
                                <span 
                                  key={star.id} 
                                  onClick={() => setSelectedActorId(star.id)}
                                  className="text-[10px] px-2.5 py-1 bg-white/5 border border-white/5 rounded-full text-gray-300 hover:text-white hover:border-red-500/50 cursor-pointer font-medium"
                                >
                                  {star.name}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="text-center py-10 text-gray-500 text-xs">
                        Select an episode to view specific crew, description, and guest stars.
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB: GALLERY (SCREENSHOTS, POSTERS, LOGOS) */}
          {activeTab === "gallery" && (
            <div className="flex flex-col gap-8 animate-fade-in">
              
              {/* Backdrops (Screenshots / Stills) */}
              {images.backdrops?.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-display font-extrabold text-lg text-white flex items-center gap-2">
                      <ImageIcon className="w-5 h-5 text-red-500" />
                      <span>Cinematic Landscape Backdrops & Stills</span>
                    </h3>
                    <button 
                      onClick={() => {
                        const backdropUrls = images.backdrops.map((img: any) => `https://image.tmdb.org/t/p/original${img.file_path}`);
                        setLightboxImages(backdropUrls);
                        setLightboxIndex(0);
                        setLightboxOpen(true);
                      }}
                      className="text-xs font-bold text-red-400 hover:text-red-300"
                    >
                      View All in Fullscreen →
                    </button>
                  </div>

                  <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-thin select-none snap-x">
                    {images.backdrops.slice(0, 15).map((img: any, idx) => {
                      const sizeUrl = `https://image.tmdb.org/t/p/w780${img.file_path}`;
                      const fullUrl = `https://image.tmdb.org/t/p/original${img.file_path}`;

                      return (
                        <div 
                          key={idx} 
                          onClick={() => {
                            const backdropUrls = images.backdrops.map((img: any) => `https://image.tmdb.org/t/p/original${img.file_path}`);
                            setLightboxImages(backdropUrls);
                            setLightboxIndex(idx);
                            setLightboxOpen(true);
                          }}
                          className="flex-none w-72 md:w-96 aspect-video rounded-xl overflow-hidden bg-gray-950 border border-white/5 hover:border-white/20 transition-all cursor-pointer snap-start relative group"
                        >
                          <img 
                            src={sizeUrl} 
                            alt={`Backdrop screenshot ${idx + 1}`}
                            loading="lazy"
                            className="w-full h-full object-cover transition-transform group-hover:scale-103"
                          />
                          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                            <ZoomIn className="w-8 h-8 text-white drop-shadow-md" />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Posters (Official, Alternative, International) */}
              {images.posters?.length > 0 && (
                <div>
                  <h3 className="font-display font-extrabold text-lg text-white mb-4 flex items-center gap-2">
                    <ImageIcon className="w-5 h-5 text-red-500" />
                    <span>Official, Alternative & International Posters</span>
                  </h3>

                  <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-thin select-none snap-x">
                    {images.posters.slice(0, 15).map((img: any, idx) => {
                      const sizeUrl = `https://image.tmdb.org/t/p/w500${img.file_path}`;
                      const fullUrl = `https://image.tmdb.org/t/p/original${img.file_path}`;

                      return (
                        <div 
                          key={idx} 
                          onClick={() => {
                            const posterUrls = images.posters.map((img: any) => `https://image.tmdb.org/t/p/original${img.file_path}`);
                            setLightboxImages(posterUrls);
                            setLightboxIndex(idx);
                            setLightboxOpen(true);
                          }}
                          className="flex-none w-36 md:w-48 aspect-[2/3] rounded-xl overflow-hidden bg-gray-950 border border-white/5 hover:border-white/20 transition-all cursor-pointer snap-start relative group shadow-lg"
                        >
                          <img 
                            src={sizeUrl} 
                            alt={`Poster variant ${idx + 1}`}
                            loading="lazy"
                            className="w-full h-full object-cover transition-transform group-hover:scale-103"
                          />
                          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                            <ZoomIn className="w-8 h-8 text-white drop-shadow-md" />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Logos */}
              {images.logos?.length > 0 && (
                <div>
                  <h3 className="font-display font-extrabold text-lg text-white mb-4 flex items-center gap-2">
                    <ImageIcon className="w-5 h-5 text-red-500" />
                    <span>Transparent Design Logos</span>
                  </h3>

                  <div className="flex flex-wrap gap-4">
                    {images.logos.slice(0, 8).map((img: any, idx) => {
                      const sizeUrl = `https://image.tmdb.org/t/p/w500${img.file_path}`;

                      return (
                        <div 
                          key={idx} 
                          className="w-40 h-24 bg-white/2.5 border border-white/5 p-4 rounded-xl flex items-center justify-center relative group"
                        >
                          <img 
                            src={sizeUrl} 
                            alt={`Production Logo variant ${idx + 1}`}
                            loading="lazy"
                            className="max-w-full max-h-full object-contain filter drop-shadow-[0_4px_8px_rgba(0,0,0,0.5)] transition-transform group-hover:scale-105"
                          />
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

            </div>
          )}

          {/* TAB: CAST & CREW */}
          {activeTab === "cast" && (
            <div className="flex flex-col gap-10 animate-fade-in">
              
              {/* Full Cast Grid */}
              {cast.length > 0 ? (
                <div>
                  <h3 className="font-display font-extrabold text-lg text-white mb-6 flex items-center gap-2">
                    <Users className="w-5 h-5 text-red-500" />
                    <span>Actors & Performance Cast ({cast.length})</span>
                  </h3>

                  <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-5">
                    {cast.map((member) => (
                      <div 
                        key={member.id} 
                        onClick={() => setSelectedActorId(member.id)}
                        className="group flex flex-col items-center text-center cursor-pointer bg-white/2.5 hover:bg-white/5 border border-white/5 hover:border-red-500/20 p-3 rounded-2xl transition-all"
                      >
                        <div className="w-20 h-20 rounded-full overflow-hidden border border-white/10 group-hover:border-red-500 transition-colors bg-gray-950">
                          <img 
                            src={member.profile_path ? `https://image.tmdb.org/t/p/w185${member.profile_path}` : "https://img.icons8.com/color/185/test-account.png"} 
                            alt={member.name}
                            loading="lazy"
                            className="w-full h-full object-cover transition-transform group-hover:scale-105"
                          />
                        </div>
                        <span className="text-[11px] font-black text-white mt-3 line-clamp-1 group-hover:text-red-400">
                          {member.name}
                        </span>
                        <span className="text-[10px] text-gray-500 line-clamp-1 mt-0.5">
                          {member.character || "Uncredited"}
                        </span>
                        <span className="text-[9px] text-gray-600 font-mono mt-1">
                          Pop: {(member as any).popularity ? (member as any).popularity.toFixed(0) : "N/A"}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center py-10 text-gray-500 text-sm">No Cast was submitted.</div>
              )}

              {/* Full Crew breakdown list */}
              {crew.length > 0 && (
                <div className="border-t border-white/5 pt-8">
                  <h3 className="font-display font-extrabold text-lg text-white mb-6">
                    Directorial, Creative & Production Crew ({crew.length})
                  </h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {/* Directors */}
                    {crewGroups.directors.length > 0 && (
                      <div className="bg-white/2.5 p-5 rounded-2xl border border-white/5">
                        <span className="text-xs text-red-400 font-black tracking-wider uppercase block mb-3">Directors</span>
                        <ul className="text-xs text-gray-300 flex flex-col gap-2">
                          {crewGroups.directors.slice(0, 10).map((c: any, idx: number) => (
                            <li key={idx} className="flex justify-between font-semibold">
                              <span className="text-white">{c.name}</span>
                              <span className="text-gray-500">{c.job}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Writers */}
                    {crewGroups.writers.length > 0 && (
                      <div className="bg-white/2.5 p-5 rounded-2xl border border-white/5">
                        <span className="text-xs text-red-400 font-black tracking-wider uppercase block mb-3">Writers & Story creators</span>
                        <ul className="text-xs text-gray-300 flex flex-col gap-2">
                          {crewGroups.writers.slice(0, 10).map((c: any, idx: number) => (
                            <li key={idx} className="flex justify-between font-semibold">
                              <span className="text-white">{c.name}</span>
                              <span className="text-gray-500">{c.job}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Producers */}
                    {crewGroups.producers.length > 0 && (
                      <div className="bg-white/2.5 p-5 rounded-2xl border border-white/5">
                        <span className="text-xs text-red-400 font-black tracking-wider uppercase block mb-3">Producers</span>
                        <ul className="text-xs text-gray-300 flex flex-col gap-2">
                          {crewGroups.producers.slice(0, 10).map((c: any, idx: number) => (
                            <li key={idx} className="flex justify-between font-semibold">
                              <span className="text-white">{c.name}</span>
                              <span className="text-gray-500">{c.job}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Sound & Music */}
                    {crewGroups.music.length > 0 && (
                      <div className="bg-white/2.5 p-5 rounded-2xl border border-white/5">
                        <span className="text-xs text-red-400 font-black tracking-wider uppercase block mb-3">Music Composers</span>
                        <ul className="text-xs text-gray-300 flex flex-col gap-2">
                          {crewGroups.music.slice(0, 10).map((c: any, idx: number) => (
                            <li key={idx} className="flex justify-between font-semibold">
                              <span className="text-white">{c.name}</span>
                              <span className="text-gray-500">{c.job}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Cinematography */}
                    {crewGroups.cinematography.length > 0 && (
                      <div className="bg-white/2.5 p-5 rounded-2xl border border-white/5">
                        <span className="text-xs text-red-400 font-black tracking-wider uppercase block mb-3">Cinematography</span>
                        <ul className="text-xs text-gray-300 flex flex-col gap-2">
                          {crewGroups.cinematography.slice(0, 10).map((c: any, idx: number) => (
                            <li key={idx} className="flex justify-between font-semibold">
                              <span className="text-white">{c.name}</span>
                              <span className="text-gray-500">{c.job}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Editors */}
                    {crewGroups.editors.length > 0 && (
                      <div className="bg-white/2.5 p-5 rounded-2xl border border-white/5">
                        <span className="text-xs text-red-400 font-black tracking-wider uppercase block mb-3">Editors</span>
                        <ul className="text-xs text-gray-300 flex flex-col gap-2">
                          {crewGroups.editors.slice(0, 10).map((c: any, idx: number) => (
                            <li key={idx} className="flex justify-between font-semibold">
                              <span className="text-white">{c.name}</span>
                              <span className="text-gray-500">{c.job}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>
              )}

            </div>
          )}

          {/* TAB: VIDEOS & CLIPS */}
          {activeTab === "videos" && (
            <div className="animate-fade-in">
              <h3 className="font-display font-extrabold text-lg text-white mb-6 flex items-center gap-2">
                <Video className="w-5 h-5 text-red-500" />
                <span>Trailers, Featurettes, Clips & Bloopers ({videos.length})</span>
              </h3>

              {videos.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                  {videos.map((video: any) => {
                    const videoThumbnail = `https://img.youtube.com/vi/${video.key}/0.jpg`;
                    
                    return (
                      <div 
                        key={video.id} 
                        onClick={() => setActiveVideoKey(video.key)}
                        className="group bg-white/2.5 border border-white/5 hover:border-red-500/35 rounded-2xl overflow-hidden transition-all cursor-pointer"
                      >
                        <div className="aspect-video w-full overflow-hidden relative bg-black">
                          <img 
                            src={videoThumbnail} 
                            alt={video.name}
                            loading="lazy" 
                            className="w-full h-full object-cover opacity-80 group-hover:scale-103 transition-transform"
                          />
                          <div className="absolute inset-0 bg-black/10 group-hover:bg-black/30 transition-all flex items-center justify-center">
                            <div className="w-12 h-12 rounded-full bg-red-600 flex items-center justify-center text-white shadow-2xl group-hover:scale-105 transition-transform">
                              <Play className="w-5 h-5 fill-white ml-0.5" />
                            </div>
                          </div>
                          
                          <div className="absolute bottom-2 left-2 px-2 py-0.5 bg-black/80 rounded text-[9px] font-bold tracking-widest text-white uppercase border border-white/5">
                            {video.type}
                          </div>
                        </div>

                        <div className="p-4">
                          <h4 className="font-bold text-xs text-white group-hover:text-red-400 line-clamp-1">
                            {video.name}
                          </h4>
                          <p className="text-[10px] text-gray-500 mt-1">Provider: {video.site}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-12 text-gray-500 text-sm">
                  No video attachments found for this content.
                </div>
              )}
            </div>
          )}

          {/* TAB: COLLECTION */}
          {activeTab === "collection" && collectionDetails && (
            <div className="glass-panel p-6 rounded-3xl border border-white/5 animate-fade-in flex flex-col gap-6">
              
              <div className="flex flex-col md:flex-row gap-6 items-center md:items-start border-b border-white/5 pb-6">
                {collectionDetails.poster_path && (
                  <div className="w-40 md:w-48 shrink-0 rounded-2xl overflow-hidden shadow-lg border border-white/5">
                    <img 
                      src={`https://image.tmdb.org/t/p/w500${collectionDetails.poster_path}`} 
                      alt={collectionDetails.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                
                <div className="flex-1 text-center md:text-left">
                  <span className="text-[10px] text-red-400 font-bold tracking-widest uppercase bg-red-500/10 px-2 py-0.5 rounded border border-red-500/10 inline-block mb-2">
                    Movie Franchise Compilation
                  </span>
                  <h3 className="font-display font-black text-2xl text-white">{collectionDetails.name}</h3>
                  <p className="text-xs text-gray-300 mt-3 leading-relaxed max-w-4xl">
                    {collectionDetails.overview || "This franchise aggregates all corresponding sequels and story entries."}
                  </p>
                </div>
              </div>

              <div>
                <h4 className="font-display font-bold text-sm text-gray-400 mb-4">Franchise Films included ({collectionDetails.parts?.length || 0})</h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-5">
                  {collectionDetails.parts?.map((item: any) => {
                    const rating = item.vote_average ? item.vote_average.toFixed(1) : "0.0";
                    const isCurrent = String(item.id) === String(tmdbId);

                    return (
                      <div 
                        key={item.id}
                        onClick={() => {
                          if (!isCurrent) {
                            onNavigateToContent("movie", String(item.id), item.title || item.name);
                          }
                        }}
                        className={`group cursor-pointer flex flex-col gap-2 rounded-xl overflow-hidden border p-2 transition-all ${
                          isCurrent 
                            ? "bg-red-500/10 border-red-500/30 scale-[0.98] cursor-default" 
                            : "bg-gray-950/20 border-white/5 hover:border-white/20 hover:bg-gray-950/50"
                        }`}
                      >
                        <div className="aspect-[2/3] w-full rounded-lg overflow-hidden relative bg-black/60">
                          {item.poster_path ? (
                            <img 
                              src={`https://image.tmdb.org/t/p/w300${item.poster_path}`} 
                              alt={item.title} 
                              loading="lazy"
                              className="w-full h-full object-cover group-hover:scale-103 transition-transform"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-gray-600 bg-gray-950">
                              <Film className="w-8 h-8" />
                            </div>
                          )}
                          <div className="absolute top-1.5 right-1.5 px-1.5 py-0.5 rounded bg-black/80 backdrop-blur-md text-[9px] font-bold text-yellow-500 flex items-center gap-0.5 shadow-md">
                            <Star className="w-2.5 h-2.5 fill-yellow-500" />
                            <span>{rating}</span>
                          </div>

                          {isCurrent && (
                            <div className="absolute inset-0 bg-red-600/20 flex items-center justify-center backdrop-blur-[1px]">
                              <span className="text-[9px] font-black tracking-widest text-white uppercase bg-red-600 px-2 py-0.5 rounded shadow-lg">
                                WATCHING
                              </span>
                            </div>
                          )}
                        </div>

                        <div className="p-1 text-center">
                          <h5 className="font-bold text-[11px] text-white line-clamp-1 group-hover:text-red-400">
                            {item.title}
                          </h5>
                          {item.release_date && (
                            <span className="text-[9px] text-gray-500">{new Date(item.release_date).getFullYear()}</span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

            </div>
          )}

          {/* TAB: REVIEWS */}
          {activeTab === "reviews" && (
            <div className="flex flex-col gap-6 animate-fade-in">
              <h3 className="font-display font-extrabold text-lg text-white flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-red-500" />
                <span>Audience & Critical Reviews ({reviews.length})</span>
              </h3>

              {reviews.length > 0 ? (
                <div className="flex flex-col gap-5">
                  {reviews.map((rev: any) => {
                    const rating = rev.author_details?.rating;
                    const avatar = rev.author_details?.avatar_path 
                      ? rev.author_details.avatar_path.startsWith("/http") 
                        ? rev.author_details.avatar_path.slice(1) 
                        : `https://image.tmdb.org/t/p/w150${rev.author_details.avatar_path}`
                      : "https://img.icons8.com/color/150/test-account.png";

                    return (
                      <div key={rev.id} className="bg-white/2.5 border border-white/5 p-6 rounded-2xl flex flex-col md:flex-row gap-5 items-start">
                        <div className="w-12 h-12 shrink-0 rounded-full overflow-hidden bg-gray-950 border border-white/5">
                          <img 
                            src={avatar} 
                            alt={rev.author}
                            className="w-full h-full object-cover"
                          />
                        </div>

                        <div className="flex-1">
                          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/5 pb-2 mb-3">
                            <div>
                              <h4 className="font-bold text-sm text-white">{rev.author}</h4>
                              <p className="text-[10px] text-gray-500 font-mono mt-0.5">Posted on {new Date(rev.created_at).toLocaleDateString()}</p>
                            </div>

                            {rating && (
                              <div className="flex items-center gap-1 px-2 py-0.5 rounded bg-yellow-500/10 border border-yellow-500/20 text-yellow-500 text-xs font-bold">
                                <Star className="w-3 h-3 fill-yellow-500" />
                                <span>{rating}/10</span>
                              </div>
                            )}
                          </div>

                          <div className="text-gray-300 text-xs leading-relaxed max-h-[150px] overflow-y-auto pr-2 scrollbar-thin">
                            {rev.content}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-12 text-gray-500 text-sm">
                  No audience logs have been submitted to TMDB yet.
                </div>
              )}
            </div>
          )}

          {/* TAB: TECHNICAL DETAILS */}
          {activeTab === "tech" && (
            <div className="glass-panel p-6 rounded-3xl border border-white/5 animate-fade-in flex flex-col gap-6">
              <h3 className="font-display font-bold text-lg text-white">Full Technical Specs & Production Parameters</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs font-semibold">
                
                {/* Specs block 1 */}
                <div className="flex flex-col gap-4 bg-white/2.5 p-5 rounded-2xl border border-white/5">
                  <div className="flex justify-between items-center border-b border-white/5 pb-2.5">
                    <span className="text-gray-400">Official Title</span>
                    <span className="text-white">{title}</span>
                  </div>
                  <div className="flex justify-between items-center border-b border-white/5 pb-2.5">
                    <span className="text-gray-400">Original Title</span>
                    <span className="text-white">{originalTitle || "Same as release"}</span>
                  </div>
                  <div className="flex justify-between items-center border-b border-white/5 pb-2.5">
                    <span className="text-gray-400">Original Language</span>
                    <span className="text-white uppercase font-mono">{details.original_language}</span>
                  </div>
                  <div className="flex justify-between items-center border-b border-white/5 pb-2.5">
                    <span className="text-gray-400">TMDB Popularity Rating</span>
                    <span className="text-white font-mono">{popularity} Points</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Votes Metrics</span>
                    <span className="text-yellow-500 font-mono">{rating} ★ ({voteCount.toLocaleString()} Users)</span>
                  </div>
                </div>

                {/* Specs block 2 */}
                <div className="flex flex-col gap-4 bg-white/2.5 p-5 rounded-2xl border border-white/5">
                  <div className="flex justify-between items-center border-b border-white/5 pb-2.5">
                    <span className="text-gray-400">Spoken Languages</span>
                    <span className="text-white text-right">
                      {spokenLanguages.map((l: any) => l.english_name || l.name).join(", ") || "Undisclosed"}
                    </span>
                  </div>
                  <div className="flex justify-between items-center border-b border-white/5 pb-2.5">
                    <span className="text-gray-400">Production Countries</span>
                    <span className="text-white text-right">
                      {productionCountries.map((c: any) => c.name).join(", ") || "Undisclosed"}
                    </span>
                  </div>
                  <div className="flex justify-between items-center border-b border-white/5 pb-2.5">
                    <span className="text-gray-400">Production Companies</span>
                    <span className="text-white text-right max-w-[60%] truncate">
                      {productionCompanies.map((c: any) => c.name).join(", ") || "Undisclosed"}
                    </span>
                  </div>
                  {contentType === "tv" && (
                    <>
                      <div className="flex justify-between items-center border-b border-white/5 pb-2.5">
                        <span className="text-gray-400">Seasons Count</span>
                        <span className="text-white">{numberOfSeasons} Seasons</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-400">Episodes Count</span>
                        <span className="text-white">{numberOfEpisodes} Episodes</span>
                      </div>
                    </>
                  )}
                  {contentType === "movie" && (
                    <>
                      <div className="flex justify-between items-center border-b border-white/5 pb-2.5">
                        <span className="text-gray-400">Budget Limit</span>
                        <span className="text-white font-mono">{budget || "Undisclosed"}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-400">Worldwide Revenue</span>
                        <span className="text-white font-mono">{revenue || "Undisclosed"}</span>
                      </div>
                    </>
                  )}
                </div>

              </div>
            </div>
          )}

          {/* TAB: RELATED (MORE LIKE THIS) */}
          {activeTab === "related" && (
            <div className="flex flex-col gap-10 animate-fade-in">
              
              {/* Recommendations */}
              {recommendations.length > 0 && (
                <div>
                  <h3 className="font-display font-extrabold text-lg text-white mb-6 flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-red-500" />
                    <span>Recommended Channels (Binge-worthy matches)</span>
                  </h3>

                  <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-6">
                    {recommendations.slice(0, 12).map((item) => {
                      const isMovie = item.media_type ? item.media_type === "movie" : "title" in item;
                      const title = isMovie ? item.title : item.name;
                      const rating = item.vote_average ? item.vote_average.toFixed(1) : "0.0";
                      
                      return (
                        <div
                          key={item.id}
                          onClick={() => onNavigateToContent(isMovie ? "movie" : "tv", String(item.id), title)}
                          className="group cursor-pointer flex flex-col gap-2 rounded-xl overflow-hidden bg-gray-900/30 border border-white/5 hover:border-white/20 transition-all duration-300"
                        >
                          <div className="aspect-[2/3] w-full bg-gray-950 rounded-xl overflow-hidden relative shadow-md">
                            <img
                              src={item.poster_path ? `https://image.tmdb.org/t/p/w300${item.poster_path}` : backdropUrl}
                              alt={title}
                              loading="lazy"
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            />
                            <div className="absolute top-2 right-2 px-1.5 py-0.5 rounded bg-black/85 backdrop-blur-md text-[10px] font-bold text-yellow-500 flex items-center gap-0.5">
                              <Star className="w-2.5 h-2.5 fill-yellow-500" />
                              <span>{rating}</span>
                            </div>
                          </div>
                          <div className="p-1 px-2 pb-2 text-center">
                            <p className="font-bold text-xs text-gray-300 group-hover:text-red-400 line-clamp-1 transition-colors">
                              {title}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Similar */}
              {similar.length > 0 && (
                <div>
                  <h3 className="font-display font-extrabold text-lg text-white mb-6 flex items-center gap-2">
                    <Film className="w-5 h-5 text-red-500" />
                    <span>Similar Thematic Streams (Users also watched)</span>
                  </h3>

                  <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-6">
                    {similar.slice(0, 12).map((item) => {
                      const isMovie = item.media_type ? item.media_type === "movie" : "title" in item;
                      const title = isMovie ? item.title : item.name;
                      const rating = item.vote_average ? item.vote_average.toFixed(1) : "0.0";
                      
                      return (
                        <div
                          key={item.id}
                          onClick={() => onNavigateToContent(isMovie ? "movie" : "tv", String(item.id), title)}
                          className="group cursor-pointer flex flex-col gap-2 rounded-xl overflow-hidden bg-gray-900/30 border border-white/5 hover:border-white/20 transition-all duration-300"
                        >
                          <div className="aspect-[2/3] w-full bg-gray-950 rounded-xl overflow-hidden relative shadow-md">
                            <img
                              src={item.poster_path ? `https://image.tmdb.org/t/p/w300${item.poster_path}` : backdropUrl}
                              alt={title}
                              loading="lazy"
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            />
                            <div className="absolute top-2 right-2 px-1.5 py-0.5 rounded bg-black/85 backdrop-blur-md text-[10px] font-bold text-yellow-500 flex items-center gap-0.5">
                              <Star className="w-2.5 h-2.5 fill-yellow-500" />
                              <span>{rating}</span>
                            </div>
                          </div>
                          <div className="p-1 px-2 pb-2 text-center">
                            <p className="font-bold text-xs text-gray-300 group-hover:text-red-400 line-clamp-1 transition-colors">
                              {title}
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

            </div>
          )}

        </div>

      </div>

      {/* FULLSCREEN LIGHTBOX GALLERIES EXPERIENCES */}
      {lightboxOpen && lightboxImages.length > 0 && (
        <div 
          id="gallery-fullscreen-lightbox" 
          className="fixed inset-0 bg-black/95 z-50 flex flex-col items-center justify-between p-4 backdrop-blur-md animate-fade-in"
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
        >
          {/* Header controls strip */}
          <div className="w-full flex items-center justify-between text-gray-400 max-w-7xl">
            <div className="text-xs font-bold font-mono">
              Image {lightboxIndex + 1} of {lightboxImages.length}
            </div>
            
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setLightboxZoom(prev => prev === 1 ? 1.8 : prev === 1.8 ? 2.5 : 1)}
                className="p-2 bg-white/5 hover:bg-white/10 rounded-lg text-white border border-white/5 cursor-pointer flex items-center gap-1.5 text-xs font-bold"
                aria-label="Toggle Zoom level"
              >
                {lightboxZoom === 1 ? <ZoomIn className="w-4 h-4" /> : <ZoomOut className="w-4 h-4" />}
                <span>Zoom (x{lightboxZoom})</span>
              </button>

              <button 
                onClick={() => {
                  setLightboxOpen(false);
                  setLightboxZoom(1);
                }}
                className="p-2 bg-red-600 hover:bg-red-500 rounded-lg text-white cursor-pointer"
                aria-label="Close Lightbox"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Interactive core Image Stage */}
          <div className="flex-1 w-full flex items-center justify-center relative select-none">
            
            {/* Desktop Navigation Left Arrow */}
            <button
              onClick={() => {
                setLightboxIndex((prev) => (prev - 1 + lightboxImages.length) % lightboxImages.length);
                setLightboxZoom(1);
              }}
              className="absolute left-4 p-3 bg-black/50 hover:bg-black/80 rounded-full border border-white/5 text-white hover:border-red-500 cursor-pointer transition-all hidden md:block z-10"
              aria-label="Previous image"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            {/* Stage Frame */}
            <div 
              className="max-w-[90vw] max-h-[75vh] md:max-w-4xl overflow-hidden flex items-center justify-center transition-all duration-300"
              style={{ transform: `scale(${lightboxZoom})` }}
            >
              <img 
                src={lightboxImages[lightboxIndex]} 
                alt={`Lightbox image view ${lightboxIndex + 1}`}
                className="max-w-full max-h-full object-contain rounded-lg shadow-2xl transition-all"
              />
            </div>

            {/* Desktop Navigation Right Arrow */}
            <button
              onClick={() => {
                setLightboxIndex((prev) => (prev + 1) % lightboxImages.length);
                setLightboxZoom(1);
              }}
              className="absolute right-4 p-3 bg-black/50 hover:bg-black/80 rounded-full border border-white/5 text-white hover:border-red-500 cursor-pointer transition-all hidden md:block z-10"
              aria-label="Next image"
            >
              <ChevronRight className="w-6 h-6" />
            </button>

          </div>

          {/* Footer guides */}
          <div className="text-gray-500 text-[10px] text-center font-semibold tracking-wider">
            SWIPE TO FLIP • ARROW KEYS NAVIGATE • ESCAPE TO CLOSE
          </div>
        </div>
      )}

      {/* FULLSCREEN YOUTUBE VIDEO CLIPS PLAYER MODAL */}
      {activeVideoKey && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4 backdrop-blur-xs animate-fade-in">
          <div className="relative w-full max-w-4xl aspect-video rounded-2xl overflow-hidden bg-black border border-white/15 shadow-2xl">
            
            <button 
              onClick={() => setActiveVideoKey(null)}
              className="absolute top-4 right-4 p-2 bg-red-600 hover:bg-red-500 rounded-lg text-white z-10 shadow-lg cursor-pointer"
              aria-label="Close video clip player"
            >
              <X className="w-4 h-4" />
            </button>

            <iframe 
              src={`https://www.youtube.com/embed/${activeVideoKey}?autoplay=1&rel=0`}
              className="w-full h-full border-0"
              allow="autoplay; encrypted-media; picture-in-picture"
              allowFullScreen
              title="YouTube trailer player feed"
            />

          </div>
        </div>
      )}

      {/* INTERACTIVE ACTOR DETAILS MODAL SIDEBAR */}
      {selectedActorId && (
        <div className="fixed inset-0 bg-black/80 z-50 flex justify-end animate-fade-in backdrop-blur-xs">
          
          {/* Dismissing overlay click */}
          <div 
            onClick={() => setSelectedActorId(null)}
            className="absolute inset-0 z-0 cursor-pointer"
          />

          {/* Core Content Modal Drawer from right */}
          <div className="relative z-10 w-full max-w-md bg-[#090d16] border-l border-white/5 h-full overflow-y-auto p-6 md:p-8 flex flex-col gap-6 shadow-2xl">
            
            <div className="flex items-center justify-between border-b border-white/5 pb-4">
              <span className="text-xs text-red-400 font-extrabold uppercase tracking-widest">ACTOR BIO PROFILE</span>
              <button 
                onClick={() => setSelectedActorId(null)}
                className="p-1.5 bg-white/5 hover:bg-red-600/20 hover:text-red-400 rounded-lg text-gray-400 transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {actorLoading ? (
              <div className="flex-1 flex items-center justify-center">
                <div className="w-10 h-10 border-2 border-red-500/20 border-t-red-500 rounded-full animate-spin"></div>
              </div>
            ) : actorDetails ? (
              <div className="flex flex-col gap-6 animate-fade-in text-xs font-semibold">
                
                {/* Image and name */}
                <div className="flex items-center gap-4">
                  <div className="w-24 h-24 rounded-2xl overflow-hidden shrink-0 border border-white/10 bg-gray-950">
                    <img 
                      src={actorDetails.details.profile_path ? `https://image.tmdb.org/t/p/w185${actorDetails.details.profile_path}` : "https://img.icons8.com/color/185/test-account.png"} 
                      alt={actorDetails.details.name}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <div>
                    <h3 className="font-display font-black text-lg text-white">{actorDetails.details.name}</h3>
                    <p className="text-gray-500 mt-1">Known for: {actorDetails.details.known_for_department || "Acting"}</p>
                    <p className="text-yellow-500 mt-1 font-mono">Popularity Score: {actorDetails.details.popularity ? actorDetails.details.popularity.toFixed(1) : "0"} Pts</p>
                  </div>
                </div>

                {/* Technical bio facts */}
                <div className="flex flex-col gap-2.5 bg-white/2.5 p-4 rounded-xl border border-white/5">
                  <div className="flex justify-between border-b border-white/5 pb-2">
                    <span className="text-gray-500">Birthday</span>
                    <span className="text-white">
                      {actorDetails.details.birthday ? new Date(actorDetails.details.birthday).toLocaleDateString() : "Undisclosed"}
                    </span>
                  </div>
                  {actorDetails.details.deathday && (
                    <div className="flex justify-between border-b border-white/5 pb-2">
                      <span className="text-gray-500">Passed away</span>
                      <span className="text-red-400">
                        {new Date(actorDetails.details.deathday).toLocaleDateString()}
                      </span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-gray-500">Place of Birth</span>
                    <span className="text-white text-right max-w-[60%] truncate">{actorDetails.details.place_of_birth || "Undisclosed"}</span>
                  </div>
                </div>

                {/* Biography */}
                <div>
                  <h4 className="text-gray-400 font-extrabold uppercase tracking-wider mb-2 text-[10px]">BIOGRAPHY BACKGROUND</h4>
                  <p className="text-gray-300 font-medium text-xs leading-relaxed max-h-[160px] overflow-y-auto pr-1 scrollbar-thin">
                    {actorDetails.details.biography || `${actorDetails.details.name} is a renowned professional in the global cinematic field.`}
                  </p>
                </div>

                {/* Filmography links */}
                {actorDetails.credits && actorDetails.credits.length > 0 && (
                  <div className="border-t border-white/5 pt-4">
                    <h4 className="text-gray-400 font-extrabold uppercase tracking-wider mb-3 text-[10px]">
                      KNOWN CHANNELS & FILMOGRAPHY
                    </h4>

                    <div className="flex flex-col gap-2.5 max-h-[220px] overflow-y-auto pr-2 scrollbar-thin">
                      {actorDetails.credits
                        .filter((credit: any) => credit.poster_path)
                        .slice(0, 10)
                        .map((credit: any) => {
                          const isMovie = credit.media_type === "movie";
                          const creditTitle = isMovie ? credit.title : credit.name;
                          const creditYear = credit.release_date || credit.first_air_date ? new Date(credit.release_date || credit.first_air_date).getFullYear() : "N/A";

                          return (
                            <div 
                              key={`${credit.id}-${credit.character}`}
                              onClick={() => {
                                setSelectedActorId(null);
                                onNavigateToContent(isMovie ? "movie" : "tv", String(credit.id), creditTitle);
                              }}
                              className="group flex gap-3 p-2 bg-white/2.5 hover:bg-white/5 border border-white/5 hover:border-red-500/20 rounded-xl cursor-pointer transition-all items-center"
                            >
                              <div className="w-9 h-12 bg-black rounded overflow-hidden shrink-0">
                                <img 
                                  src={`https://image.tmdb.org/t/p/w92${credit.poster_path}`} 
                                  alt={creditTitle}
                                  loading="lazy"
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              <div className="flex-1 min-w-0">
                                <h5 className="font-bold text-[11px] text-white line-clamp-1 group-hover:text-red-400">
                                  {creditTitle}
                                </h5>
                                <p className="text-[9px] text-gray-500 truncate mt-0.5">As {credit.character || "Herself/Himself"} ({creditYear})</p>
                              </div>
                              <ChevronRight className="w-3.5 h-3.5 text-gray-600 group-hover:text-red-500 shrink-0" />
                            </div>
                          );
                        })}
                    </div>
                  </div>
                )}

              </div>
            ) : (
              <div className="text-center py-10 text-gray-500 text-xs">Could not load actor bio.</div>
            )}

          </div>

        </div>
      )}

    </div>
  );
}
