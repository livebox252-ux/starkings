export function SkeletonCard() {
  return (
    <div className="relative flex flex-col gap-2 rounded-2xl overflow-hidden bg-gray-900/10 border border-white/5 p-1.5 select-none transition-all duration-300">
      {/* Poster shimmer block */}
      <div className="aspect-[2/3] w-full bg-[#0c0f1d] rounded-xl relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/[0.06] to-transparent -translate-x-full animate-shimmer" />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-12 h-16 rounded-xl border border-white/5 bg-white/5 animate-pulse" />
        </div>
      </div>
      {/* Metadata shimmer lines */}
      <div className="p-1 px-2 pb-3 flex flex-col gap-2.5">
        <div className="h-4 bg-white/[0.06] rounded-lg w-4/5 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/[0.05] to-transparent -translate-x-full animate-shimmer" />
        </div>
        <div className="flex gap-2">
          <div className="h-3 bg-white/[0.04] rounded w-1/3 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/[0.05] to-transparent -translate-x-full animate-shimmer" />
          </div>
          <div className="h-3 bg-white/[0.04] rounded w-1/4 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/[0.05] to-transparent -translate-x-full animate-shimmer" />
          </div>
        </div>
      </div>
    </div>
  );
}

export function HomeSkeleton() {
  const dummyCards = Array.from({ length: 6 });

  return (
    <div className="flex flex-col gap-12 pt-28 pb-16 select-none">
      {/* Grid rows lists block wrapper */}
      <div className="max-w-7xl mx-auto w-full px-6 md:px-12 flex flex-col gap-12">
        
        {/* Row 1: Weekly Trending */}
        <div className="flex flex-col gap-4">
          <div className="h-7 w-56 bg-white/[0.06] rounded-lg relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/[0.05] to-transparent -translate-x-full animate-shimmer" />
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
            {dummyCards.map((_, i) => (
              <SkeletonCard key={i} />
            ))}
          </div>
        </div>

        {/* Row 2: Movies */}
        <div className="flex flex-col gap-4">
          <div className="h-7 w-48 bg-white/[0.06] rounded-lg relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/[0.05] to-transparent -translate-x-full animate-shimmer" />
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
            {dummyCards.map((_, i) => (
              <SkeletonCard key={i} />
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}

export function BrowseSkeleton() {
  const dummyCards = Array.from({ length: 12 });

  return (
    <div className="min-h-screen text-gray-100 pt-28 pb-16 px-4 md:px-8 max-w-7xl mx-auto flex flex-col gap-8 select-none">
      {/* Title Header */}
      <div className="flex flex-col gap-2">
        <div className="h-9 w-64 bg-white/[0.06] rounded-xl relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/[0.05] to-transparent -translate-x-full animate-shimmer" />
        </div>
        <div className="h-4 w-96 bg-white/[0.04] rounded-lg relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/[0.05] to-transparent -translate-x-full animate-shimmer" />
        </div>
      </div>

      {/* Discovery Filters Control Panel */}
      <div className="glass-panel p-5 rounded-2xl border border-white/5 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex flex-wrap gap-2">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="h-7 w-20 bg-white/[0.06] rounded-lg relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/[0.05] to-transparent -translate-x-full animate-shimmer" />
            </div>
          ))}
        </div>
        <div className="h-9 w-48 bg-white/[0.06] rounded-xl relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/[0.05] to-transparent -translate-x-full animate-shimmer" />
        </div>
      </div>

      {/* Main Grid display area */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
        {dummyCards.map((_, i) => (
          <SkeletonCard key={i} />
        ))}
      </div>
    </div>
  );
}
