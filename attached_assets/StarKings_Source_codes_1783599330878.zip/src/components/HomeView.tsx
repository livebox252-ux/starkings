import { useState, useEffect } from "react";
import { Play, Flame, Star, Film, Tv, Sparkles, AlertCircle, Info, Smile, Shield, Rocket } from "lucide-react";
import { TMDBContent } from "../types";
import { HomeSkeleton } from "./SkeletonCard";
import HorizontalScrollRow from "./HorizontalScrollRow";
import ThreeDCarousel from "./ThreeDCarousel";

interface HomeViewProps {
  onSelectContent: (type: "movie" | "tv", id: string, title?: string) => void;
}

export default function HomeView({ onSelectContent }: HomeViewProps) {
  const [trending, setTrending] = useState<TMDBContent[]>([]);
  const [movies, setMovies] = useState<TMDBContent[]>([]);
  const [tvShows, setTvShows] = useState<TMDBContent[]>([]);
  const [actionMovies, setActionMovies] = useState<TMDBContent[]>([]);
  const [comedyMovies, setComedyMovies] = useState<TMDBContent[]>([]);
  const [scifiMovies, setScifiMovies] = useState<TMDBContent[]>([]);
  const [animeList, setAnimeList] = useState<TMDBContent[]>([]);
  const [hindiList, setHindiList] = useState<TMDBContent[]>([]);
  const [southIndianList, setSouthIndianList] = useState<TMDBContent[]>([]);
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [localKey, setLocalKey] = useState("");

  const handleSaveKey = () => {
    if (localKey.trim()) {
      localStorage.setItem("STARKING_TMDB_KEY", localKey.trim());
      window.location.reload();
    }
  };

  const getYear = (item: any) => {
    const dateStr = item.release_date || item.first_air_date;
    if (!dateStr) return 0;
    return new Date(dateStr).getFullYear();
  };

  const filterLatestOnly = (list: TMDBContent[]) => {
    return list.filter((item: any) => {
      const yr = getYear(item);
      return yr >= 2024; // Show only 2024, 2025, and 2026 data
    });
  };

  useEffect(() => {
    async function loadHomeContent() {
      try {
        setLoading(true);
        setError(null);

        // Concurrent fetching of multi-category layouts
        const [
          trendRes, 
          movieRes, 
          tvRes,
          actionRes,
          comedyRes,
          scifiRes,
          animeRes,
          hindiMovieRes,
          hindiTvRes,
          southIndianMovieRes,
          southIndianTvRes
        ] = await Promise.allSettled([
          fetch("/api/tmdb/trending?type=all"),
          fetch("/api/tmdb/trending?type=movie"),
          fetch("/api/tmdb/trending?type=tv"),
          fetch("/api/tmdb/discover?type=movie&with_genres=28"), // Action
          fetch("/api/tmdb/discover?type=movie&with_genres=35"), // Comedy
          fetch("/api/tmdb/discover?type=movie&with_genres=878"), // Sci-Fi
          fetch("/api/tmdb/anime?type=tv"), // Anime
          fetch("/api/tmdb/discover?type=movie&with_original_language=hi"), // Hindi Movies
          fetch("/api/tmdb/discover?type=tv&with_original_language=hi"), // Hindi Series
          fetch("/api/tmdb/discover?type=movie&with_original_language=ta|te|ml|kn"), // South Indian Movies
          fetch("/api/tmdb/discover?type=tv&with_original_language=ta|te|ml|kn") // South Indian Series
        ]);

        // Key verification check (check if unauthenticated 401)
        if (trendRes.status === "fulfilled" && trendRes.value.status === 401) {
          throw new Error("TMDB_API_KEY_MISSING");
        }

        const trendingData = trendRes.status === "fulfilled" && trendRes.value.ok ? await trendRes.value.json() : { results: [] };
        const moviesData = movieRes.status === "fulfilled" && movieRes.value.ok ? await movieRes.value.json() : { results: [] };
        const tvData = tvRes.status === "fulfilled" && tvRes.value.ok ? await tvRes.value.json() : { results: [] };
        const actionData = actionRes.status === "fulfilled" && actionRes.value.ok ? await actionRes.value.json() : { results: [] };
        const comedyData = comedyRes.status === "fulfilled" && comedyRes.value.ok ? await comedyRes.value.json() : { results: [] };
        const scifiData = scifiRes.status === "fulfilled" && scifiRes.value.ok ? await scifiRes.value.json() : { results: [] };
        const animeData = animeRes.status === "fulfilled" && animeRes.value.ok ? await animeRes.value.json() : { results: [] };
        
        const hindiMovieData = hindiMovieRes.status === "fulfilled" && hindiMovieRes.value.ok ? await hindiMovieRes.value.json() : { results: [] };
        const hindiTvData = hindiTvRes.status === "fulfilled" && hindiTvRes.value.ok ? await hindiTvRes.value.json() : { results: [] };
        const southIndianMovieData = southIndianMovieRes.status === "fulfilled" && southIndianMovieRes.value.ok ? await southIndianMovieRes.value.json() : { results: [] };
        const southIndianTvData = southIndianTvRes.status === "fulfilled" && southIndianTvRes.value.ok ? await southIndianTvRes.value.json() : { results: [] };

        // Process and combine multi-language feeds
        const rawTrending = trendingData.results || [];
        const rawMovies = moviesData.results || [];
        const rawTv = tvData.results || [];
        const rawAction = actionData.results || [];
        const rawComedy = comedyData.results || [];
        const rawScifi = scifiData.results || [];
        const rawAnime = animeData.results || [];
        
        // Combine movie + tv for Hindi & South Indian
        const combinedHindi = [...(hindiMovieData.results || []), ...(hindiTvData.results || [])]
          .sort((a, b) => (b.popularity || 0) - (a.popularity || 0));
        const combinedSouth = [...(southIndianMovieData.results || []), ...(southIndianTvData.results || [])]
          .sort((a, b) => (b.popularity || 0) - (a.popularity || 0));

        // Enforce strict filter to show only latest 2024-2026 releases
        setTrending(filterLatestOnly(rawTrending));
        setMovies(filterLatestOnly(rawMovies));
        setTvShows(filterLatestOnly(rawTv));
        setActionMovies(filterLatestOnly(rawAction));
        setComedyMovies(filterLatestOnly(rawComedy));
        setScifiMovies(filterLatestOnly(rawScifi));
        setAnimeList(filterLatestOnly(rawAnime));
        setHindiList(filterLatestOnly(combinedHindi));
        setSouthIndianList(filterLatestOnly(combinedSouth));

      } catch (err: any) {
        setError(err.message || "Something went wrong.");
      } finally {
        setLoading(false);
      }
    }

    loadHomeContent();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#030712]">
        <HomeSkeleton />
      </div>
    );
  }

  if (error === "TMDB_API_KEY_MISSING") {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center text-center px-4 md:px-8 bg-[#030712]">
        <div className="w-16 h-16 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center mb-4 text-red-500 animate-pulse">
          <AlertCircle className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-black text-white mb-2 font-display uppercase tracking-wider">TMDB API Key Required</h2>
        <p className="text-gray-400 max-w-md mb-6 text-sm leading-relaxed">
          Configure your <b>VITE_TMDB_API_KEY</b> in your hosting platform environment variables, or enter it below to begin stream searching.
        </p>

        <div className="w-full max-w-md bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-md mb-6 text-left">
          <label className="block text-xs font-semibold uppercase tracking-wider text-gray-400 mb-2">
            Client-Side TMDB Override Key
          </label>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Paste your TMDB v3 API Key (e.g. f6d...)"
              value={localKey}
              onChange={(e) => setLocalKey(e.target.value)}
              className="flex-1 px-4 py-2.5 rounded-xl bg-black/40 border border-white/10 focus:border-red-500 text-white text-sm outline-none transition-all placeholder-gray-500 font-mono"
            />
            <button
              onClick={handleSaveKey}
              className="px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-sm font-semibold transition-all shadow-lg hover:shadow-red-600/20 cursor-pointer"
            >
              Save
            </button>
          </div>
          <p className="mt-2 text-[11px] text-gray-500">
            Securely saved in browser cache. Create a key at <a href="https://www.themoviedb.org/" target="_blank" rel="noopener noreferrer" className="text-red-400 hover:underline">themoviedb.org</a>.
          </p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center text-center px-4 bg-[#030712]">
        <div className="w-16 h-16 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center mb-4 text-red-500">
          <AlertCircle className="w-8 h-8 animate-bounce" />
        </div>
        <h2 className="text-xl font-bold text-white mb-2">Feed Connection Offline</h2>
        <p className="text-gray-400 max-w-sm mb-6 text-sm">{error}</p>
        <button 
          onClick={() => window.location.reload()}
          className="px-6 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-sm font-semibold transition-all button-glow cursor-pointer"
        >
          Retry Connection
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-12 pt-24 md:pt-28 pb-24 overflow-x-hidden bg-[#030712]">
      
      {/* 7. PREMIUM 3D HIGHLIGHT CAROUSEL AREA */}
      {trending.length > 0 && (
        <ThreeDCarousel 
          items={trending} 
          onSelect={onSelectContent} 
        />
      )}

      {/* RENDER DYNAMIC CONTENT SECTIONS AND ROWS */}
      <div className="max-w-7xl mx-auto w-full px-6 md:px-12 flex flex-col gap-16">

        <HorizontalScrollRow
          title="Top Rated Movies"
          icon={<Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />}
          items={movies}
          onSelect={onSelectContent}
        />

        {/* Hindi Content Row */}
        {hindiList.length > 0 && (
          <HorizontalScrollRow
            title="Latest Hindi Movies & Series"
            icon={<Film className="w-5 h-5 text-red-500" />}
            items={hindiList}
            onSelect={onSelectContent}
          />
        )}

        {/* Anime Section Row */}
        {animeList.length > 0 && (
          <HorizontalScrollRow
            title="Latest Anime Releases"
            icon={<Sparkles className="w-5 h-5 text-indigo-400" />}
            items={animeList}
            onSelect={onSelectContent}
          />
        )}

        {/* South Indian Content Row */}
        {southIndianList.length > 0 && (
          <HorizontalScrollRow
            title="South Indian Hits (Telugu, Tamil, Malayalam)"
            icon={<Film className="w-5 h-5 text-orange-500" />}
            items={southIndianList}
            onSelect={onSelectContent}
          />
        )}

        <HorizontalScrollRow
          title="Sci-Fi Blockbusters"
          icon={<Rocket className="w-5 h-5 text-cyan-400" />}
          items={scifiMovies}
          onSelect={onSelectContent}
        />

        <HorizontalScrollRow
          title="Popular TV Series"
          icon={<Tv className="w-5 h-5 text-red-500" />}
          items={tvShows}
          onSelect={onSelectContent}
        />

        <HorizontalScrollRow
          title="Action & Adventure"
          icon={<Shield className="w-5 h-5 text-orange-400" />}
          items={actionMovies}
          onSelect={onSelectContent}
        />

        <HorizontalScrollRow
          title="Laugh Out Loud Comedies"
          icon={<Smile className="w-5 h-5 text-yellow-400" />}
          items={comedyMovies}
          onSelect={onSelectContent}
        />

      </div>

    </div>
  );
}
