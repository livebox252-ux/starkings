import { motion } from "motion/react";
import { Send, Bell, Shield, MessageSquare, ArrowLeft, Heart, Sparkles } from "lucide-react";

interface TelegramViewProps {
  onBack: () => void;
}

export default function TelegramView({ onBack }: TelegramViewProps) {
  return (
    <div className="min-h-screen text-gray-100 pt-28 pb-20 px-4 md:px-8 max-w-4xl mx-auto flex flex-col gap-10 selection:bg-blue-500 selection:text-white">
      
      {/* Back button */}
      <div>
        <button 
          onClick={onBack}
          className="group flex items-center gap-2 px-5 py-3 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/5 text-gray-300 hover:text-white transition-all duration-300 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          <span className="text-sm font-semibold">Back to Home</span>
        </button>
      </div>

      {/* Header Banner */}
      <div className="relative rounded-3xl overflow-hidden border border-white/10 bg-gradient-to-b from-gray-900/60 to-gray-950/80 p-8 md:p-14 flex flex-col items-center text-center gap-4 shadow-2xl">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,_var(--tw-gradient-stops))] from-blue-500/10 via-transparent to-transparent pointer-events-none" />
        
        {/* Telegram Icon badge */}
        <div className="w-16 h-16 rounded-2xl bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400 mb-2 shadow-lg shadow-blue-500/5">
          <Send className="w-8 h-8 transform rotate-[15deg]" />
        </div>

        <h1 className="font-display font-black text-3xl md:text-5xl text-white tracking-tight">
          Join FlixHub Telegram
        </h1>
        <p className="text-gray-400 text-sm md:text-base max-w-2xl leading-relaxed">
          Get real-time updates on latest movies, TV series, and new anime drops. If any link is broken or servers go down, we post active backup domains and quick solutions directly in the channel.
        </p>

        {/* Quick stat */}
        <div className="mt-4 flex items-center gap-2 px-4 py-2 rounded-full bg-blue-500/10 border border-blue-500/20 text-xs font-bold text-blue-400 tracking-wide uppercase">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-400"></span>
          </span>
          <span>Official FlixHub Channel</span>
        </div>
      </div>

      {/* Cards Container */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        <div className="glass-panel p-6 rounded-2xl border border-white/5 bg-gray-900/10 flex flex-col gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400">
            <Bell className="w-5 h-5" />
          </div>
          <h3 className="font-display font-bold text-lg text-white">Instant Alerts</h3>
          <p className="text-xs text-gray-400 leading-relaxed">
            Get pinged immediately when hot new theater prints, season finales, or dual-audio dubbed files are added.
          </p>
        </div>

        <div className="glass-panel p-6 rounded-2xl border border-white/5 bg-gray-900/10 flex flex-col gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400">
            <Shield className="w-5 h-5" />
          </div>
          <h3 className="font-display font-bold text-lg text-white">Backup Links</h3>
          <p className="text-xs text-gray-400 leading-relaxed">
            If our website gets blocked or servers change, you can always find our active website address here.
          </p>
        </div>

        <div className="glass-panel p-6 rounded-2xl border border-white/5 bg-gray-900/10 flex flex-col gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400">
            <MessageSquare className="w-5 h-5" />
          </div>
          <h3 className="font-display font-bold text-lg text-white">Direct Chat</h3>
          <p className="text-xs text-gray-400 leading-relaxed">
            Chat with the admins, suggest movies or TV shows, and request subtitle formats directly in our group.
          </p>
        </div>

      </div>

      {/* About Box written by human */}
      <div className="glass-panel p-8 rounded-3xl border border-white/5 bg-gray-900/5 flex flex-col gap-4">
        <h3 className="font-display font-bold text-lg text-white flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-yellow-500" />
          <span>A Note From The Admins</span>
        </h3>
        <p className="text-sm text-gray-300 leading-relaxed">
          FlixHub is fully run and managed by a small team of media enthusiasts. We spend hours sorting out the fastest streaming providers, resolving player bugs, and fetching top metadata so you get a Netflix-grade streaming experience for free. 
        </p>
        <p className="text-sm text-gray-300 leading-relaxed">
          By joining the Telegram channel, you support our work and ensure that we can keep in touch with our active user base even if major external domains undergo migration. We promise to keep it strictly update-focused with zero junk, spam, or annoying ads.
        </p>
      </div>

      {/* CTA Final Box */}
      <div className="relative rounded-3xl overflow-hidden border-2 border-blue-500/20 bg-gradient-to-r from-blue-950/20 via-gray-950 to-blue-950/20 p-8 md:p-14 flex flex-col items-center text-center gap-6 shadow-2xl">
        <div className="absolute inset-0 bg-blue-500/5 pointer-events-none" />
        
        <h2 className="font-display font-black text-2xl md:text-3xl text-white max-w-xl">
          Get FlixHub Updates
        </h2>
        
        <div className="flex flex-col sm:flex-row items-center gap-4 w-full justify-center">
          <a 
            href="https://t.me/starskings" 
            target="_blank" 
            rel="noopener noreferrer"
            className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-blue-500 hover:bg-blue-400 text-white font-bold text-sm flex items-center justify-center gap-2.5 shadow-lg shadow-blue-500/20 hover:scale-[1.02] transition-all duration-300 cursor-pointer"
          >
            <Send className="w-5 h-5" />
            <span>Join Official Channel (@starskings)</span>
          </a>
          <button 
            onClick={onBack}
            className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/5 text-gray-300 hover:text-white font-bold text-sm flex items-center justify-center transition-all duration-300 cursor-pointer"
          >
            Back to Home
          </button>
        </div>
      </div>

    </div>
  );
}
