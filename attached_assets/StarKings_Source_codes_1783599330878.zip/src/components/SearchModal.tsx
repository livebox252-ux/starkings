import { useState, useEffect, useRef } from "react";
import { Search, X, Star, Film, Loader2 } from "lucide-react";
import { motion } from "motion/react";
import { TMDBContent } from "../types";

interface SearchModalProps {
  onClose: () => void;
  onSelectContent: (type: "movie" | "tv", id: string, title?: string) => void;
}

interface SearchCardProps {
  key?: any;
  item: TMDBContent;
  onSelect: (type: "movie" | "tv", id: string, title?: string) => void;
  onClose: () => void;
}

function SearchCard({ item, onSelect, onClose }: SearchCardProps) {
  const [isImageLoaded, setIsImageLoaded] = useState(false);
  const isMovie = item.media_type === "movie";
  const title = isMovie ? (item as any).title : (item as any).name;
  const rating = item.vote_average ? item.vote_average.toFixed(1) : "0.0";
  const date = isMovie ? (item as any).release_date : (item as any).first_air_date;
  const year = date ? new Date(date).getFullYear() : "N/A";

  const posterUrl = item.poster_path 
    ? `https://image.tmdb.org/t/p/w300${item.poster_path}`
    : "https://images.unsplash.com/photo-1594909122845-11baa439b7bf?auto=format&fit=crop&q=80&w=300";

  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: 20 },
        visible: { opacity: 1, y: 0 }
      }}
      whileHover={{ scale: 1.05, y: -5 }}
      whileTap={{ scale: 0.95 }}
      onClick={() => {
        onSelect(isMovie ? "movie" : "tv", String(item.id), title);
        onClose();
      }}
      className="group cursor-pointer flex flex-col gap-2 rounded-2xl overflow-hidden bg-gray-900/30 border border-white/5 hover:border-red-500/30 transition-all duration-300 hover:shadow-xl hover:shadow-red-500/10"
    >
      <div className="aspect-[2/3] w-full bg-gray-950/80 rounded-xl overflow-hidden relative">
        {/* Shimmer skeleton loading pattern */}
        {!isImageLoaded && (
          <div className="absolute inset-0 bg-[#0c0f1d] flex flex-col items-center justify-center overflow-hidden animate-pulse">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full animate-shimmer" />
            <div className="w-10 h-14 rounded bg-white/5" />
          </div>
        )}

        <img
          src={posterUrl}
          alt={title}
          loading="lazy"
          onLoad={() => setIsImageLoaded(true)}
          className={`w-full h-full object-cover transition-all duration-500 ease-out ${
            isImageLoaded ? "opacity-100 scale-100 group-hover:scale-105" : "opacity-0 scale-95"
          }`}
        />
        
        {/* Glossy overlay */}
        {isImageLoaded && (
          <div className="absolute inset-0 bg-gradient-to-tr from-white/0 via-white/5 to-white/0 transform -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-out pointer-events-none" />
        )}

        {isImageLoaded && (
          <div className="absolute top-2 right-2 px-1.5 py-0.5 rounded-lg bg-black/80 backdrop-blur-md text-[10px] font-bold text-yellow-500 flex items-center gap-1 border border-white/10">
            <Star className="w-2.5 h-2.5 fill-yellow-500 text-yellow-500" />
            {rating}
          </div>
        )}

        {isImageLoaded && (
          <div className="absolute top-2 left-2 px-1.5 py-0.5 rounded-lg bg-gradient-to-r from-red-600 to-amber-600 text-[9px] font-bold tracking-wider uppercase text-white shadow-md">
            {isMovie ? "Movie" : "Series"}
          </div>
        )}
      </div>
      
      <div className="p-1 px-2 pb-3">
        <h4 className="font-display font-semibold text-xs text-gray-200 group-hover:text-red-400 line-clamp-1 transition-colors">
          {title}
        </h4>
        <p className="text-[10px] text-gray-500 mt-0.5 font-medium">{year}</p>
      </div>
    </motion.div>
  );
}

export default function SearchModal({ onClose, onSelectContent }: SearchModalProps) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<TMDBContent[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const inputRef = useRef<HTMLInputElement>(null);

  // Focus input automatically on mount
  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, []);

  // Debounced TMDB query fetch via secure API proxy
  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      return;
    }

    const delayId = setTimeout(async () => {
      try {
        setLoading(true);
        setError(null);
        
        const params = new URLSearchParams({
          query: query.trim(),
          page: "1"
        });

        const res = await fetch(`/api/tmdb/search?${params.toString()}`);
        if (!res.ok) throw new Error("Search index offline.");
        
        const data = await res.json();
        // TMDB search multi can return person etc., we want to filter only movies and TV shows
        const filteredResults = (data.results || []).filter(
          (item: any) => item.media_type === "movie" || item.media_type === "tv"
        );
        setResults(filteredResults);
      } catch (err: any) {
        setError(err.message || "Failed to parse query results.");
      } finally {
        setLoading(false);
      }
    }, 500); // 500ms debounce rate

    return () => clearTimeout(delayId);
  }, [query]);

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95, y: 20 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      className="fixed inset-0 z-[100] bg-[#030712]/95 backdrop-blur-3xl flex flex-col p-4 md:p-8 overflow-y-auto"
    >
      
      {/* Top Modal Header */}
      <div className="max-w-4xl mx-auto w-full flex items-center justify-between gap-4 mb-8">
        <div className="flex items-center gap-2">
          <Search className="w-5 h-5 text-red-500 text-glow" />
          <span className="font-display font-bold text-lg text-white">Live Search</span>
        </div>

        <button 
          onClick={onClose}
          className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 text-gray-300 hover:text-white transition-all cursor-pointer shadow-lg hover:rotate-90 duration-300"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Main Search Input field */}
      <div className="max-w-4xl mx-auto w-full mb-8 relative group">
        <input
          ref={inputRef}
          type="text"
          placeholder="Type movie, tv series, anime name..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="w-full bg-gray-950 border-2 border-white/10 hover:border-white/20 focus:border-red-500/50 rounded-2xl px-6 py-4 pl-14 text-base text-white placeholder-gray-500 outline-none transition-all shadow-[0_0_40px_rgba(0,0,0,0.5)] focus:shadow-[0_0_40px_rgba(239,68,68,0.15)]"
        />
        <Search className="w-6 h-6 text-gray-400 absolute left-5 top-4.5 group-focus-within:text-red-500 transition-colors" />
        
        {loading && (
          <div className="absolute right-5 top-4.5">
            <Loader2 className="w-6 h-6 text-red-500 animate-spin" />
          </div>
        )}
      </div>

      {/* Grid of parsed contents */}
      <div className="max-w-4xl mx-auto w-full flex-1">
        {error && (
          <p className="text-center text-red-400 font-medium text-sm py-12">{error}</p>
        )}

        {!query.trim() ? (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-24 text-gray-500 text-sm flex flex-col items-center justify-center"
          >
            <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mb-6 border border-white/10 shadow-inner">
              <Film className="w-8 h-8 text-gray-400" />
            </div>
            <p className="font-display font-semibold text-lg text-gray-300">What are you looking for?</p>
            <p className="text-xs text-gray-600 mt-2">Search across our premium catalog of movies, series, and anime.</p>
          </motion.div>
        ) : !loading && results.length === 0 ? (
          <div className="text-center py-24 text-gray-500 text-sm">
            No active stream matches found for "{query}". Try checking your spelling.
          </div>
        ) : (
          <motion.div 
            initial="hidden"
            animate="visible"
            variants={{
              hidden: { opacity: 0 },
              visible: { opacity: 1, transition: { staggerChildren: 0.05 } }
            }}
            className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6"
          >
            {results.map((item) => (
              <SearchCard 
                key={item.id}
                item={item}
                onSelect={onSelectContent}
                onClose={onClose}
              />
            ))}
          </motion.div>
        )}
      </div>

    </motion.div>
  );
}
