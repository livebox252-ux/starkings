import React, { ErrorInfo, ReactNode } from "react";
import { AlertCircle, RotateCcw } from "lucide-react";

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export default class ErrorBoundary extends React.Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#030712] text-gray-100 flex flex-col items-center justify-center p-6 text-center select-none">
          <div className="max-w-md w-full bg-gray-900/50 border border-red-500/10 rounded-2xl p-8 backdrop-blur-xl shadow-2xl">
            <div className="w-16 h-16 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center mx-auto mb-6 text-red-500 animate-pulse">
              <AlertCircle className="w-8 h-8" />
            </div>
            
            <h1 className="font-display font-bold text-2xl text-white mb-2">Something went wrong</h1>
            <p className="text-gray-400 text-sm mb-6 leading-relaxed">
              An unexpected client-side error occurred inside Star King's application interface.
            </p>

            {this.state.error && (
              <div className="bg-black/40 border border-white/5 rounded-xl p-4 text-left font-mono text-xs text-red-400 mb-6 max-h-32 overflow-y-auto break-all">
                {this.state.error.toString()}
              </div>
            )}

            <button
              id="reload-app-button"
              onClick={() => {
                this.setState({ hasError: false, error: null });
                window.location.reload();
              }}
              className="w-full py-3 px-4 rounded-xl bg-red-600 hover:bg-red-500 text-white font-semibold text-sm flex items-center justify-center gap-2 transition-all cursor-pointer button-glow"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Reload Application</span>
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
