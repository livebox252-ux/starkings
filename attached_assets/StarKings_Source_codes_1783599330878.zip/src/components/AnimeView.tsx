import { useState, useEffect } from "react";
import { Sparkles, ChevronLeft, ChevronRight, Info, Tv, Film } from "lucide-react";
import { TMDBContent } from "../types";
import ContentCard from "./ContentCard";
import { SkeletonCard } from "./SkeletonCard";

interface AnimeViewProps {
  onSelectContent: (type: "movie" | "tv", id: string, title?: string) => void;
}

export default function AnimeView({ onSelectContent }: AnimeViewProps) {
  const [items, setItems] = useState<TMDBContent[]>([]);
  const [animeType, setAnimeType] = useState<"tv" | "movie">("tv"); // default to anime series
  const [page, setPage] = useState<number>(1);
  const [totalPages, setTotalPages] = useState<number>(1);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch Anime discovery lists (Genre 16 & Japanese language filter inside our endpoint)
  useEffect(() => {
    async function fetchAnime() {
      try {
        setLoading(true);
        setError(null);

        const params = new URLSearchParams({
          type: animeType,
          page: String(page)
        });

        const res = await fetch(`/api/tmdb/anime?${params.toString()}`);
        if (!res.ok) throw new Error("Anime registry synchronized failure.");

        const data = await res.json();
        setItems(data.results || []);
        setTotalPages(Math.min(data.total_pages || 1, 100)); // cap at 100 pages to prevent excessive rate hits
      } catch (err: any) {
        setError(err.message || "An unexpected error occurred.");
      } finally {
        setLoading(false);
      }
    }
    
    fetchAnime();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [animeType, page]);

  return (
    <div className="min-h-screen text-gray-100 pt-24 pb-16 px-4 md:px-8 max-w-7xl mx-auto flex flex-col gap-8">
      
      {/* Title Header */}
      <div>
        <h1 className="font-display font-bold text-3xl tracking-tight text-white flex items-center gap-2.5">
          <Sparkles className="w-8 h-8 text-red-500 text-glow" />
          <span>Browse Japanese <span className="text-red-500 text-glow">Anime</span> Hub</span>
        </h1>
        <p className="text-gray-400 text-sm mt-1">
          Stream thousands of legendary Japanese animation titles parsed directly from TMDB catalog streams.
        </p>
      </div>

      {/* Anime Format Selection panel */}
      <div className="glass-panel p-5 rounded-2xl border border-white/5 flex flex-wrap items-center justify-between gap-4">
        
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => {
              setAnimeType("tv");
              setPage(1);
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              animeType === "tv" 
                ? "bg-red-500 text-white shadow-lg shadow-red-500/20" 
                : "bg-white/5 text-gray-400 hover:text-white hover:bg-white/10"
            }`}
          >
            <Tv className="w-4 h-4" />
            <span>Anime Series</span>
          </button>
          
          <button
            onClick={() => {
              setAnimeType("movie");
              setPage(1);
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              animeType === "movie" 
                ? "bg-red-500 text-white shadow-lg shadow-red-500/20" 
                : "bg-white/5 text-gray-400 hover:text-white hover:bg-white/10"
            }`}
          >
            <Film className="w-4 h-4" />
            <span>Anime Movies</span>
          </button>
        </div>

        <div className="text-xs text-gray-400 font-semibold uppercase tracking-wider bg-red-600/10 border border-red-500/10 px-3 py-1.5 rounded-lg flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
          <span>Anime Subbed & Dubbed Configured</span>
        </div>

      </div>

      {/* Grid of anime results */}
      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
          {Array.from({ length: 12 }).map((_, i) => (
            <SkeletonCard key={i} />
          ))}
        </div>
      ) : error ? (
        <div className="text-center py-16 text-gray-400">
          <Info className="w-8 h-8 text-red-500 mx-auto mb-2" />
          <p>{error}</p>
        </div>
      ) : items.length === 0 ? (
        <div className="text-center py-16 text-gray-400">
          No matching anime content found.
        </div>
      ) : (
        <div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
            {items.map((item) => (
              <ContentCard
                key={item.id}
                item={item}
                onClick={() => onSelectContent(animeType, String(item.id), (item as any).name || (item as any).title)}
              />
            ))}
          </div>

          {/* Pagination controls */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-4 mt-12 border-t border-white/5 pt-8">
              <button
                disabled={page === 1}
                onClick={() => setPage(page - 1)}
                className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 text-gray-300 hover:text-white transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              
              <span className="text-xs font-semibold text-gray-400">
                Page <span className="text-white">{page}</span> of <span className="text-white">{totalPages}</span>
              </span>

              <button
                disabled={page === totalPages}
                onClick={() => setPage(page + 1)}
                className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 text-gray-300 hover:text-white transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          )}
        </div>
      )}

    </div>
  );
}
