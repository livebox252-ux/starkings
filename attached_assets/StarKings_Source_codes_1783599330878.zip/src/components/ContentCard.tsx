import { useState } from "react";
import { motion } from "motion/react";
import { Star } from "lucide-react";
import { TMDBContent } from "../types";

interface ContentCardProps {
  key?: any;
  item: TMDBContent;
  onClick: () => void;
}

export default function ContentCard({ item, onClick }: ContentCardProps) {
  const [isImageLoaded, setIsImageLoaded] = useState(false);
  const isMovie = "title" in item;
  const title = isMovie ? (item as any).title : (item as any).name;
  const date = isMovie ? (item as any).release_date : (item as any).first_air_date;
  const year = date ? new Date(date).getFullYear() : "N/A";
  const rating = item.vote_average ? item.vote_average.toFixed(1) : "0.0";
  
  // High quality poster fallback
  const posterUrl = item.poster_path 
    ? `https://image.tmdb.org/t/p/w400${item.poster_path}`
    : "https://images.unsplash.com/photo-1594909122845-11baa439b7bf?auto=format&fit=crop&q=80&w=400";

  return (
    <motion.div 
      id={`content-card-${item.id}`}
      onClick={onClick}
      whileHover={{ y: -8, scale: 1.04 }}
      whileTap={{ scale: 0.96 }}
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
      className="group relative cursor-pointer flex flex-col gap-2 rounded-2xl overflow-hidden bg-gray-900/30 border border-white/5 hover:border-red-500/30 hover:bg-gray-900/50 hover:shadow-[0_20px_40px_rgba(239,68,68,0.12)] transition-all duration-300"
    >
      {/* Poster Image Container */}
      <div className="aspect-[2/3] w-full overflow-hidden rounded-xl bg-gray-950/80 relative">
        
        {/* Shimmer skeleton loading pattern */}
        {!isImageLoaded && (
          <div className="absolute inset-0 bg-[#0c0f1d] flex flex-col items-center justify-center overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full animate-shimmer" />
            <div className="w-12 h-16 rounded-lg border border-white/5 bg-white/5 animate-pulse" />
          </div>
        )}

        <img
          src={posterUrl}
          alt={title}
          loading="lazy"
          onLoad={() => setIsImageLoaded(true)}
          className={`w-full h-full object-cover transition-all duration-700 ease-out ${
            isImageLoaded ? "opacity-100 scale-100 group-hover:scale-110" : "opacity-0 scale-95"
          }`}
        />
        
        {/* Glossy Glare effect on hover */}
        {isImageLoaded && (
          <div className="absolute inset-0 bg-gradient-to-tr from-white/0 via-white/10 to-white/0 transform -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-out pointer-events-none" />
        )}

        {/* Rating overlay */}
        {isImageLoaded && (
          <div className="absolute top-3 right-3 px-2 py-1 rounded-lg bg-gray-950/80 backdrop-blur-md border border-white/10 flex items-center gap-1 text-xs font-bold text-yellow-500">
            <Star className="w-3 h-3 fill-yellow-500 text-yellow-500" />
            {rating}
          </div>
        )}

        {/* Media type indicator */}
        {isImageLoaded && (
          <div className="absolute top-3 left-3 px-2 py-1 rounded-lg bg-gradient-to-r from-red-600 to-amber-600 backdrop-blur-md text-[10px] font-bold tracking-wider uppercase text-white shadow-md">
            {isMovie ? "Movie" : "Series"}
          </div>
        )}

        {/* Fade gradient overlay */}
        {isImageLoaded && (
          <div className="absolute inset-0 bg-gradient-to-t from-gray-950 via-gray-950/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
            <span className="text-white text-xs font-bold bg-gradient-to-r from-red-600 to-red-500 px-3.5 py-2 rounded-xl shadow-lg shadow-red-600/30">
              Watch Now
            </span>
          </div>
        )}
      </div>

      {/* Info Container */}
      <div className="p-1 px-2 pb-3">
        <h3 className="font-display font-semibold text-sm text-gray-100 group-hover:text-red-400 line-clamp-1 transition-colors">
          {title}
        </h3>
        <div className="flex items-center gap-2 text-xs text-gray-400 mt-1">
          <span>{year}</span>
          <span className="w-1 h-1 rounded-full bg-gray-700"></span>
          <span className="text-gray-500">EN</span>
        </div>
      </div>
    </motion.div>
  );
}
