import { Crown } from "lucide-react";

export interface FooterProps {
  onTabChange: (tab: string) => void;
}

export default function Footer({ onTabChange }: FooterProps) {
  const currentYear = new Date().getFullYear();

  const footerLinks = [
    { label: "About Us", id: "about" },
    { label: "Privacy Policy", id: "privacy" },
    { label: "Terms & Conditions", id: "terms" },
    { label: "DMCA Policy", id: "dmca" },
    { label: "Disclaimer", id: "disclaimer" },
    { label: "Telegram Community", id: "telegram" },
  ];

  return (
    <footer className="bg-gray-950/90 border-t border-white/5 py-14 px-4 md:px-8 relative z-10">
      <div className="max-w-7xl mx-auto flex flex-col gap-10">
        
        {/* Main Footer layout */}
        <div className="flex flex-col md:flex-row items-center md:items-start justify-between gap-8">
          
          {/* Brand/Ident */}
          <div className="flex flex-col items-center md:items-start text-center md:text-left gap-3 max-w-sm">
            <div className="flex items-center gap-2.5 cursor-pointer group" onClick={() => onTabChange("home")}>
              <div className="relative w-8 h-8 rounded-lg bg-gradient-to-tr from-yellow-500 via-red-600 to-red-500 flex items-center justify-center shadow-lg text-white">
                <Crown className="w-4 h-4 filter drop-shadow" />
              </div>
              <span className="font-display font-black text-sm tracking-widest text-white leading-none">
                STAR <span className="bg-gradient-to-r from-red-500 via-yellow-500 to-amber-500 bg-clip-text text-transparent">KING</span>
              </span>
            </div>
            <p className="text-xs text-gray-500 leading-relaxed mt-1">
              STAR KING is a premium, lightweight, zero-tracking entertainment portal indexing the world's most popular movies, television series, and anime.
            </p>
          </div>

          {/* Quick legal compliance links */}
          <div className="flex flex-wrap items-center justify-center md:justify-end gap-x-6 gap-y-3 max-w-2xl">
            {footerLinks.map((link) => (
              <button 
                key={link.id}
                onClick={() => {
                  onTabChange(link.id);
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
                className="text-xs font-semibold text-gray-400 hover:text-white hover:underline decoration-red-500/50 underline-offset-4 transition-all duration-300 cursor-pointer"
              >
                {link.label}
              </button>
            ))}
          </div>
        </div>

        {/* Informative legal compliant disclaimer note */}
        <div className="border-t border-white/5 pt-8 text-center md:text-left flex flex-col md:flex-row items-center justify-between gap-6">
          <p className="text-[11px] text-gray-500 max-w-3xl leading-relaxed">
            <b>Copyright Disclaimer:</b> STAR KING operates strictly as an entertainment information index. We do not host, store, download, or re-transmit any media files, movies, TV shows, anime episodes, video records, or stream scripts on our servers. All metadata, rating values, posters, and summaries are parsed via public TMDB APIs. Video streams and player options are referenced dynamically from publicly available independent third-party mirrors.
          </p>
          <div className="flex flex-col items-center md:items-end gap-1.5 whitespace-nowrap">
            <span className="text-[10px] font-mono tracking-widest text-gray-500 uppercase">STAR KING SYSTEM</span>
            <span className="text-xs text-gray-600 font-semibold">&copy; {currentYear} STAR KING. All rights reserved.</span>
          </div>
        </div>

      </div>
    </footer>
  );
}
