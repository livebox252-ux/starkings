export interface Movie {
  id: number;
  title: string;
  original_title?: string;
  overview: string;
  poster_path: string | null;
  backdrop_path: string | null;
  release_date?: string;
  vote_average: number;
  genre_ids: number[];
  media_type?: "movie";
}

export interface TvShow {
  id: number;
  name: string;
  original_name?: string;
  overview: string;
  poster_path: string | null;
  backdrop_path: string | null;
  first_air_date?: string;
  vote_average: number;
  genre_ids: number[];
  media_type?: "tv";
}

export type TMDBContent = Movie | TvShow;

export interface ContentDetail {
  id: number;
  title?: string; // movie
  name?: string;  // tv
  overview: string;
  poster_path: string | null;
  backdrop_path: string | null;
  release_date?: string;
  first_air_date?: string;
  vote_average: number;
  genres: Array<{ id: number; name: string }>;
  runtime?: number; // movie
  episode_run_time?: number[]; // tv
  number_of_seasons?: number; // tv
  number_of_episodes?: number; // tv
  tagline?: string;
  status?: string;
}

export interface CastMember {
  id: number;
  name: string;
  character: string;
  profile_path: string | null;
}

export interface Video {
  id: string;
  key: string;
  name: string;
  site: string;
  type: string;
}

export interface Genre {
  id: number;
  name: string;
}

export interface Season {
  id: number;
  name: string;
  overview: string;
  season_number: number;
  poster_path: string | null;
  air_date: string;
  episodes?: Episode[];
}

export interface Episode {
  id: number;
  name: string;
  overview: string;
  episode_number: number;
  season_number: number;
  air_date: string;
  still_path: string | null;
  vote_average: number;
}

export interface Channel {
  id: string;
  name: string;
  logo: string;
  group: string;
  url: string;
  playlistId: string;
  country?: string;
  language?: string;
  category?: string;
}

export interface LiveTvMeta {
  isTvLoading: boolean;
  tvLoadError: string | null;
  groups: string[];
  categories?: string[];
  countries?: string[];
  languages?: string[];
  failedPlaylistIds?: string[];
  totalLoaded: number;
}
